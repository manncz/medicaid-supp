library(testthat)
library(RItools)

test_check("RItools")
