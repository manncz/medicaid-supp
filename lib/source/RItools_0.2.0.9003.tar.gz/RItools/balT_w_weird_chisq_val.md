# Exploring a funny balT result

This bit of `balT()` strangeness comes out of our mistem investigation.
(Not in results that were reported out, but variants that arose later as
we made follow-up adjustments to underlying code.  Those adjustments would
have reduced matched variation in the variables we're testing balance on, which
might help to drive the phenomenon.)  Based on RItools version 0.2.0.9002,
installed off of branch proj1-balT. 


```r
library("devtools")
library("dplyr")
library("RItools")  ; packageVersion("RItools")
```

```
## [1] '0.2.0.9002'
```

```r
load("balT_w_weird_chisq_val.RData")
thecovars  <-
    bt_strataAligned[[1]]@Covariates %>% colnames() %>%
    setdiff("(_non-null record_)") 
```

The balance test:


```r
bt
```

```
##                                           strata():     match                  
##                                           stat      Treatment  Control adj.diff
## vars                                                                           
## title1                                                1.00000  0.99931  0.00069
## magnet                                                0.00000  0.02650 -0.02650
## frl_count_perc                                        0.92661  0.84291  0.08370
## male_enrollment_perc                                  0.48806  0.50661 -0.01855
## female_enrollment_perc                                0.51194  0.49339  0.01855
## american_indian_enrollment_perc                       0.00399  0.00586 -0.00187
## asian_enrollment_perc                                 0.00749  0.00486  0.00263
## african_american_enrollment_perc                      0.15614  0.15922 -0.00308
## hispanic_enrollment_perc                              0.06786  0.07481 -0.00695
## hawaiian_enrollment_perc                              0.00000  0.00009 -0.00009
## white_enrollment_perc                                 0.67548  0.69048 -0.01500
## economic_disadvantaged_enrollment_perc                0.92661  0.84302  0.08359
## special_education_enrollment_perc                     0.21382  0.16499  0.04884
## english_language_learners_enrollment_perc             0.03743  0.09403 -0.05661
## ---Overall Test---
##       chisquare df      p.value
## match 1.6e-28   1.2e+01 1.0e+00
```

```r
testthat::expect_equivalent(
              balanceTest(bal_fmla, dat,
                          report=c("adj.means", "adj.mean.diffs", "chisquare.test"),
                          inferentials.calculator=HB08,
                          unit.weights=counts),
              bt)
```

Does the other version of the HB08 calculation give a similarly anomalous "overall"
Mahalanobis distance?


```r
testthat::expect_equivalent(
              balanceTest(bal_fmla, dat,
                          report=c("adj.means", "adj.mean.diffs", "chisquare.test"),
                          inferentials.calculator=HB08_2016, 
                          unit.weights=counts),
              bt)
```

--evidently, yes.

The weirdness is driven by an apparent discrepancy between the adjusted
mean differences calculation from the descriptives vs the adjusted mean
differences-like calculation embedded in the inferentials.  (They're supposed
to be about the same only after multiplication through by a constant of proportionality.
But still.)



```r
RItools::HB08(bt_strataAligned[[1]]) %>% .[c("z", "p", "adj.mean.diffs")] %>%
    as.data.frame()
```

```
##                                                   z  p adj.mean.diffs
## title1                                    -1.14e-14  1      -4.17e-17
## magnet                                    -2.73e-17  1      -3.63e-18
## frl_count_perc                             2.44e-15  1       1.13e-16
## male_enrollment_perc                      -3.14e-15  1      -6.28e-17
## female_enrollment_perc                    -3.24e-15  1      -6.49e-17
## american_indian_enrollment_perc           -4.46e-16  1      -1.44e-18
## asian_enrollment_perc                     -3.58e-17  1      -1.42e-19
## african_american_enrollment_perc           3.03e-16  1       5.64e-17
## hispanic_enrollment_perc                  -3.32e-16  1      -8.29e-18
## hawaiian_enrollment_perc                  -2.01e-17  1      -6.56e-21
## white_enrollment_perc                     -4.41e-16  1      -8.59e-17
## economic_disadvantaged_enrollment_perc     1.39e-15  1       6.44e-17
## special_education_enrollment_perc          6.09e-16  1       2.81e-17
## english_language_learners_enrollment_perc  6.75e-17  1       1.21e-17
## (_non-null record_)                              NA NA       0.00e+00
```

## Cluster size

Could it be driven by the (modest) imbalance in school size?



```r
balanceTest(z~counts, dat)
```

```
##        strata():       --      
##        stat      std.diff     z
## vars                           
## counts              -0.42 -0.87
```

Imbalance aside, the size variable is somewhat right-skewed
and quite dispersed. With or without attention to strata.
Dispersion:



```r
lm(counts~match, data=dat) %>% resid() %>% sd()
```

```
## [1] 87
```

```r
with(filter(dat, !is.na(match)), sd(counts))
```

```
## [1] 87.6
```

```r
lm(counts~match, data=dat) %>% resid() %>% mad()
```

```
## [1] 99.3
```

```r
with(filter(dat, !is.na(match)), mad(counts))
```

```
## [1] 97.9
```

Skew:


```r
with(filter(dat, !is.na(match)), stem(counts))
```

```
## 
##   The decimal point is 2 digit(s) to the right of the |
## 
##   0 | 00014
##   0 | 555677779
##   1 | 02444
##   1 | 5666789
##   2 | 0003
##   2 | 8
##   3 | 04
```


## Review of balT internal stratum alignment



```r
balT_aligned_covars  <- bt_strataAligned[[1]]@Covariates[,thecovars]
```

Missings are not part of the story here.


```r
expect_true(all(complete.cases(dat[c(thecovars, "z")])))
```




```r
wlm_aligned_covars0  <-
    lm(as.matrix(dat[thecovars]) ~ dat$match, weights=dat$counts) %>%
    resid() 
```

These two are related in this way. 


```r
all.equal(balT_aligned_covars, wlm_aligned_covars0*dat$counts, check.attributes=FALSE)
```

```
## [1] TRUE
```


## Comparing the 2 calculations of "adjusted mean differences"

First we document precise relationships between `HB08()`'s adjusted mean difference
statistic and adjusted mean difference statistics in that paper. 

Class `CovsAlignedToADesign`'s slot `StrataWeightRatio` is filled with ratios of
normalized stratum weights to the _un_-normalized version of the weighting H-B08
discusses as a default. That weighting being (h_b * m-bar_b), in a notation
mirroring H-B08, which is to say *half* the product of stratum-mean cluster size
and harmonic means of the numbers of treatment and control clusters within the stratum.
In this example the stratum weights were left at their default values, (2 * h_b * m-bar_b),
the sum of which is:


```r
dat %>% filter(!is.na(match)) %>%
    transmute(Tx.grp=z, stratum.code=match, unit.weights=counts) %>%
    RItools:::harmonic_times_mean_weight() %>%
        sum() -> swt_sum
swt_sum
```

```
## [1] 540
```

Sure enough,


```r
expect_equivalent(2/bt_strataAligned[[1]]@StrataWeightRatio, rep(swt_sum, nrow(dat)))
```

Now the reason `CovsAlignedToADesign` carries these ratios (rather than the normalized
or un-normalized weights themselves) is that subsequent calculations are expected to
impose the un-normalized H-B '08 weighting.  Equivalently, they calculate sum statistics
of weighted covariates after stratum centering. To recover these sum statistics without
the weight normalization, we can do e.g.


```r
swt_sum *
    RItools::HB08(bt_strataAligned[[1]])$"adj.mean.diffs"
```

```
##                                    title1 
##                                 -2.25e-14 
##                                    magnet 
##                                 -1.96e-15 
##                            frl_count_perc 
##                                  6.13e-14 
##                      male_enrollment_perc 
##                                 -3.40e-14 
##                    female_enrollment_perc 
##                                 -3.51e-14 
##           american_indian_enrollment_perc 
##                                 -7.78e-16 
##                     asian_enrollment_perc 
##                                 -7.69e-17 
##          african_american_enrollment_perc 
##                                  3.05e-14 
##                  hispanic_enrollment_perc 
##                                 -4.48e-15 
##                  hawaiian_enrollment_perc 
##                                 -3.55e-18 
##                     white_enrollment_perc 
##                                 -4.64e-14 
##    economic_disadvantaged_enrollment_perc 
##                                  3.48e-14 
##         special_education_enrollment_perc 
##                                  1.52e-14 
## english_language_learners_enrollment_perc 
##                                  6.56e-15 
##                       (_non-null record_) 
##                                  0.00e+00
```

Treatment group means of cluster totals of stratum-centered covariates are thus


```r
(swt_sum /sum(bt_strataAligned[[1]]@Z)) *
    RItools::HB08(bt_strataAligned[[1]])$"adj.mean.diffs"
```

```
##                                    title1 
##                                 -5.63e-15 
##                                    magnet 
##                                 -4.91e-16 
##                            frl_count_perc 
##                                  1.53e-14 
##                      male_enrollment_perc 
##                                 -8.49e-15 
##                    female_enrollment_perc 
##                                 -8.77e-15 
##           american_indian_enrollment_perc 
##                                 -1.95e-16 
##                     asian_enrollment_perc 
##                                 -1.92e-17 
##          african_american_enrollment_perc 
##                                  7.62e-15 
##                  hispanic_enrollment_perc 
##                                 -1.12e-15 
##                  hawaiian_enrollment_perc 
##                                 -8.87e-19 
##                     white_enrollment_perc 
##                                 -1.16e-14 
##    economic_disadvantaged_enrollment_perc 
##                                  8.70e-15 
##         special_education_enrollment_perc 
##                                  3.79e-15 
## english_language_learners_enrollment_perc 
##                                  1.64e-15 
##                       (_non-null record_) 
##                                  0.00e+00
```

and weighted means over the treatment group (now a ratio statistic not a sum
statistic!) of stratum-centered covariates are


```r
(swt_sum / sum(dat$z*dat$counts) ) *
    RItools::HB08(bt_strataAligned[[1]])$"adj.mean.diffs"
```

```
##                                    title1 
##                                 -6.18e-17 
##                                    magnet 
##                                 -5.39e-18 
##                            frl_count_perc 
##                                  1.68e-16 
##                      male_enrollment_perc 
##                                 -9.33e-17 
##                    female_enrollment_perc 
##                                 -9.64e-17 
##           american_indian_enrollment_perc 
##                                 -2.14e-18 
##                     asian_enrollment_perc 
##                                 -2.11e-19 
##          african_american_enrollment_perc 
##                                  8.37e-17 
##                  hispanic_enrollment_perc 
##                                 -1.23e-17 
##                  hawaiian_enrollment_perc 
##                                 -9.75e-21 
##                     white_enrollment_perc 
##                                 -1.27e-16 
##    economic_disadvantaged_enrollment_perc 
##                                  9.56e-17 
##         special_education_enrollment_perc 
##                                  4.17e-17 
## english_language_learners_enrollment_perc 
##                                  1.80e-17 
##                       (_non-null record_) 
##                                  0.00e+00
```

Coefficients in a two-way MANOVA predicting cluster totals
from stratum and treatment status.  I expected that this would
agree w/ "adj.mean.diffs" up to a constant of proportionality,
but it doesn't.


```r
lm(I(as.matrix(dat[,thecovars])*dat$counts) ~ z + match, data=dat) %>%
    coef() %>%  .["zTRUE", ] %>% 
(function(x) 
    RItools::HB08(bt_strataAligned[[1]])$"adj.mean.diffs"/x)
```

```
## Warning in RItools::HB08(bt_strataAligned[[1]])$adj.mean.diffs/x: longer
## object length is not a multiple of shorter object length
```

```
##                                    title1 
##                                  9.16e-19 
##                                    magnet 
##                                  1.17e-18 
##                            frl_count_perc 
##                                 -3.34e-18 
##                      male_enrollment_perc 
##                                  2.61e-18 
##                    female_enrollment_perc 
##                                  3.03e-18 
##           american_indian_enrollment_perc 
##                                  4.61e-18 
##                     asian_enrollment_perc 
##                                  1.78e-18 
##          african_american_enrollment_perc 
##                                 -5.96e-18 
##                  hispanic_enrollment_perc 
##                                  2.48e-18 
##                  hawaiian_enrollment_perc 
##                                  6.26e-19 
##                     white_enrollment_perc 
##                                  2.78e-18 
##    economic_disadvantaged_enrollment_perc 
##                                 -1.89e-18 
##         special_education_enrollment_perc 
##                                 -6.11e-18 
## english_language_learners_enrollment_perc 
##                                 -1.45e-18 
##                       (_non-null record_) 
##                                  0.00e+00
```

Rather, preliminary stratum alignment is required. 


```r
lm(I(bt_strataAligned[[1]]@Covariates) ~ z + match, data=dat) %>%
    coef() %>%  .["zTRUE", ] %>%
    all.equal(RItools::HB08(bt_strataAligned[[1]])$"adj.mean.diffs")
```

```
## [1] TRUE
```

