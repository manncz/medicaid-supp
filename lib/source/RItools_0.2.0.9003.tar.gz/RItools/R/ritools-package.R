#' @import methods
#' @importFrom graphics abline axis legend par plot strwidth
#' @importFrom stats as.formula complete.cases formula ftable get_all_vars median model.frame na.omit na.pass pchisq pnorm symnum terms terms.formula update update.formula var
#' @importFrom survival strata cluster
NULL
