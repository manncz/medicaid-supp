##' # Exploring a funny balT result
##'
##' This bit of `balT()` strangeness comes out of our mistem investigation.
##' (Not in results that were reported out, but variants that arose later as
##' we made follow-up adjustments to underlying code.  Those adjustments would
##' have reduced matched variation in the variables we're testing balance on, which
##' might help to drive the phenomenon.)  Based on RItools version 0.2.0.9002,
##' installed off of branch proj1-balT. 
#+
library("devtools")
library("dplyr")
library("RItools")  ; packageVersion("RItools")
load("balT_w_weird_chisq_val.RData")
thecovars  <-
    bt_strataAligned[[1]]@Covariates %>% colnames() %>%
    setdiff("(_non-null record_)") 

#' The balance test:
bt
testthat::expect_equivalent(
              balanceTest(bal_fmla, dat,
                          report=c("adj.means", "adj.mean.diffs", "chisquare.test"),
                          inferentials.calculator=HB08,
                          unit.weights=counts),
              bt)
#' Does the other version of the HB08 calculation give a similarly anomalous "overall"
#' Mahalanobis distance?
testthat::expect_equivalent(
              balanceTest(bal_fmla, dat,
                          report=c("adj.means", "adj.mean.diffs", "chisquare.test"),
                          inferentials.calculator=HB08_2016, 
                          unit.weights=counts),
              bt)
#' --evidently, yes.
#'
#' The weirdness is driven by an apparent discrepancy between the adjusted
#' mean differences calculation from the descriptives vs the adjusted mean
#' differences-like calculation embedded in the inferentials.  (They're supposed
#' to be about the same only after multiplication through by a constant of proportionality.
#' But still.)
#'
RItools::HB08(bt_strataAligned[[1]]) %>% .[c("z", "p", "adj.mean.diffs")] %>%
    as.data.frame()
#' ## Cluster size
#' 
#' Could it be driven by the (modest) imbalance in school size?
#'
balanceTest(z~counts, dat)
#' Imbalance aside, the size variable is somewhat right-skewed
#' and quite dispersed. With or without attention to strata.
#' Dispersion:
#'
lm(counts~match, data=dat) %>% resid() %>% sd()
with(filter(dat, !is.na(match)), sd(counts))
lm(counts~match, data=dat) %>% resid() %>% mad()
with(filter(dat, !is.na(match)), mad(counts))
#' Skew:
with(filter(dat, !is.na(match)), stem(counts))
#'
#' ## Review of balT internal stratum alignment
#'
balT_aligned_covars  <- bt_strataAligned[[1]]@Covariates[,thecovars]
#' Missings are not part of the story here.
expect_true(all(complete.cases(dat[c(thecovars, "z")])))
#' 
wlm_aligned_covars0  <-
    lm(as.matrix(dat[thecovars]) ~ dat$match, weights=dat$counts) %>%
    resid() 
#' These two are related in this way. 
all.equal(balT_aligned_covars, wlm_aligned_covars0*dat$counts, check.attributes=FALSE)
#' 
#' ## Comparing the 2 calculations of "adjusted mean differences"
#' 
#' First we document precise relationships between `HB08()`'s adjusted mean difference
#' statistic and adjusted mean difference statistics in that paper. 
#' 
#' Class `CovsAlignedToADesign`'s slot `StrataWeightRatio` is filled with ratios of
#' normalized stratum weights to the _un_-normalized version of the weighting H-B08
#' discusses as a default. That weighting being (h_b * m-bar_b), in a notation
#' mirroring H-B08, which is to say *half* the product of stratum-mean cluster size
#' and harmonic means of the numbers of treatment and control clusters within the stratum.
#' In this example the stratum weights were left at their default values, (2 * h_b * m-bar_b),
#' the sum of which is:
dat %>% filter(!is.na(match)) %>%
    transmute(Tx.grp=z, stratum.code=match, unit.weights=counts) %>%
    RItools:::harmonic_times_mean_weight() %>%
        sum() -> swt_sum
swt_sum
#' Sure enough,
expect_equivalent(2/bt_strataAligned[[1]]@StrataWeightRatio, rep(swt_sum, nrow(dat)))
#' Now the reason `CovsAlignedToADesign` carries these ratios (rather than the normalized
#' or un-normalized weights themselves) is that subsequent calculations are expected to
#' impose the un-normalized H-B '08 weighting.  Equivalently, they calculate sum statistics
#' of weighted covariates after stratum centering. To recover these sum statistics without
#' the weight normalization, we can do e.g.
swt_sum *
    RItools::HB08(bt_strataAligned[[1]])$"adj.mean.diffs"
#' Treatment group means of cluster totals of stratum-centered covariates are thus
(swt_sum /sum(bt_strataAligned[[1]]@Z)) *
    RItools::HB08(bt_strataAligned[[1]])$"adj.mean.diffs"
#' and weighted means over the treatment group (now a ratio statistic not a sum
#' statistic!) of stratum-centered covariates are
(swt_sum / sum(dat$z*dat$counts) ) *
    RItools::HB08(bt_strataAligned[[1]])$"adj.mean.diffs"
#' Coefficients in a two-way MANOVA predicting cluster totals
#' from stratum and treatment status.  I expected that this would
#' agree w/ "adj.mean.diffs" up to a constant of proportionality,
#' but it doesn't.
lm(I(as.matrix(dat[,thecovars])*dat$counts) ~ z + match, data=dat) %>%
    coef() %>%  .["zTRUE", ] %>% 
(function(x) 
    RItools::HB08(bt_strataAligned[[1]])$"adj.mean.diffs"/x)
#' Rather, preliminary stratum alignment is required. 
lm(I(bt_strataAligned[[1]]@Covariates) ~ z + match, data=dat) %>%
    coef() %>%  .["zTRUE", ] %>%
    all.equal(RItools::HB08(bt_strataAligned[[1]])$"adj.mean.diffs")

