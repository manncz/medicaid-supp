Project bundle for paired index standard errors (PISE), or paired propensity standard errors (PPSE) if the index is a propensity score.  This repo contains code and
notes.  

If you're viewing this on github, take a look at Releases for notes/manuscript
drafts regarding the method. And/or look at the code to do the calculations, 
in R/, and associated tests, in tests/testthat/ .  LaTeX sources of notes and 
manuscripts reside in inst/latex .