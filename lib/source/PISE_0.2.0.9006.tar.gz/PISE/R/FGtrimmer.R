
FGtrimmer <- function(object) {
    stopifnot(is.list(object), 
              all(!is.na(pmatch(c("cov.betahat","betahat", "cov.X"),names(object)))),
              is.numeric(object$cov.betahat),
              is.numeric(object$betahat),
              is.numeric(object$cov.X),
              is.matrix(object$cov.X),
              length(object$betahat)==nrow(object$cov.X),
              length(object$cov.betahat)==1 ||
              length(object$cov.betahat)==length(object$cov.X) 
              )
    
    if (substr(rownames(object$cov.betahat)[1],1,2)!="Q.") 
        stop("A QR-based PISE list was expected, but I think I was given something else.")
    
    se_beta <- if (length(object$cov.betahat)==1) { # this really means dispersion * Identity
                    rep(sqrt(object$cov.betahat), nrow(object$cov.X))
                } else sqrt(diag(object$cov.betahat))
    p <- length(object$betahat)
    totrim <- (abs(object$betahat)/se_beta  <= sqrt(2 * log(p)) )
    cov_beta <- object$cov.betahat[!totrim,!totrim,drop=FALSE]
    betahat <- object$betahat[!totrim]
    cov.X <- object$cov.X[!totrim,!totrim,drop=FALSE]
    list("cov.betahat"=cov_beta, "betahat"=betahat, "cov.X"=cov.X)
        }
