##' RMSE of standard errors associating with paired
##' differences on the provided index score.  All
##' pairs of points used to fit the model figure in
##' this average.  The paired differences are decorrelated
##' from the index itself before their standard errors are
##' computed.
##' 
##' Returns a list including an entry \code{rms_err}, as well as
##' various other quantities contributing to the calculation and
##' to others that can be made with it. This \code{rms_err} is
##' given in the units of \code{object}'s linear predictor.
##'
##' Calculating the PIC SE involves estimation of a matrix
##' matrix of regression coefficients and calculation of
##' corresponding data covariance, both done with respect to
##' the same coordinates. In the process, estimates of those
##' regression coefficients are also obtained, in the same
##' coordinate system. All this is returned along with
##' \code{rms_err}, the square root of the expected mean-square
##' of errors on estimated paired index differences,
##' removing differences on the index itself. 
##' 
##' @title SE of paired differences on a fitted index score
##' @param object fitted index score model, of or inheriting from class \code{glm}
##' @param covariance.estimator which of \code{vcov}, \code{sandwich} to use to estimate model coefficient covariances?
##' @param data a data frame
##' @return \code{pic_se_info}, a list with specific elements. 
##' @author Mark M. Fredrickson, Ben B. Hansen
##' @export
pic_stderr <- function(object, covariance.estimator, data, ...)
    UseMethod("pic_stderr")

#' @method pic_stderr glm
#' @rdname pic_stderr-methods
#' @export
pic_stderr.glm <- function(object, covariance.estimator=c("vcov", "sandwich")[1],
                     data=NULL, coeffs.from.fitted.model=FALSE, ...) 
{
    ppse_via_qr(object, covariance.estimator=covariance.estimator,
                data=data, 
                coeffs.from.fitted.model=coeffs.from.fitted.model,...)
}

#'@method pic_stderr bayesglm
#'@rdname pic_stderr-methods
#' @export
pic_stderr.bayesglm <- function(object, covariance.estimator=c("vcov", "sandwich")[1],
                          data=NULL, coeffs.from.fitted.model=TRUE, ...) 
{
    ppse_via_qr(object, covariance.estimator=covariance.estimator,
                data=data, 
                coeffs.from.fitted.model=coeffs.from.fitted.model,...)
}



##' Easier to read version of pic_stderr function without numerical stabilization
##' 
##' This implements the PIC SE calculation with the design matrix expressed in its
##' original coordinates.  This turns out not to be particulary numerically stable,
##' so this implementation of the calculation has been supplanted, by
##' \code{ppse_via_qr}.
##' 
##' @title SE of propensity-paired differences on a fitted propensity score: version -1
##' @param object as in \code{pic_stderr}
##' @param covariance.estimator as in \code{pic_stderr}
##' @param data as in \code{pic_stderr}
##' @param tt as in \code{pic_stderr}
##' @param simplify return a scalar (\code{simplify==TRUE}, the default) or a list of quantities that can be combined to make that scalar?
##' @param terms.to.sweep.out terms in calling formula that should be swept out
##' @param ... 
##' @return scalar, unless \code{simplify=F}, in which case list with components (\code{cov.betahat}, \code{betahat}, \code{cov.X})
##' @author Mark M. Fredrickson, Ben B Hansen
##' @export
ppse_notstabilized <- function(object, covariance.estimator="vcov",
                         data=model.frame(object), simplify=TRUE,
                         tt=terms(formula(object), specials="strata"),
                         terms.to.sweep.out=survival:::untangle.specials(tt, "strata")$terms,
                         cluster=NULL,...)
    {
        if (is.null(names(coef(object)))) stop("propensity coefficients have to have names")

        data.matrix <- model.matrix(tt, data)
        
        stopifnot(!is.null(colnames(data.matrix)),
                  all(names(coef(object)) %in% colnames(data.matrix)),
                  !is.null(attr(data.matrix, "assign")),
                  covariance.estimator %in% c("vcov", "sandwich"),
                  covariance.estimator=="sandwich" | is.null(cluster),
                  !is.null(cluster) || length(cluster)!=nrow(data)
                  )
        if (!is.null(cluster)) stop("cluster arg not currently supported")
        if (covariance.estimator=="sandwich") stopifnot(require("sandwich"))
        covariance.extractor <- eval(parse(text=covariance.estimator))
        
        coeffs  <- rep(NA_real_, ncol(data.matrix))
        names(coeffs)  <- coeffnames <- colnames(data.matrix)
        coeffs[names(coef(object))]  <- coef(object)
        coeff.NA <- !is.finite(coeffs)

        vnames0 <- coeffnames[!coeff.NA]
        vnames <- coeffnames[!(attr(data.matrix, "assign")==0 | #exclude intercept
                           coeff.NA)]
        coeffs <- coeffs[vnames]

        
        stopifnot(!is.null(dimnames(covb <- covariance.extractor(object))),
                  all(vnames0 %in% dimnames(covb)[[1]]))
        covb <- covb[vnames0, vnames0]
        stopifnot(setequal(dimnames(covb)[[1]], coeffnames[!coeff.NA]))
        
        if (is.null(dimnames(covb)))
          {
            dimnames(covb) <- list(coeffnames[!coeff.NA], coeffnames[!coeff.NA])
          }
        covb <- covb[vnames, vnames]

        covx <- cov(data.matrix)
        covx <- covx[vnames, vnames]

        
        cols.to.sweep.out <- attr(data.matrix, "assign") %in% c(0, terms.to.sweep.out)
	cols.to.sweep.out <- colnames(data.matrix)[cols.to.sweep.out]

        cols.to.keep <- !(vnames %in% cols.to.sweep.out)
        
        covb <- covb[cols.to.keep, cols.to.keep, drop=FALSE]
        coeffs <- coeffs[cols.to.keep]
        
        
        S <- if (sum(cols.to.keep)!=length(vnames)) {
          n <- nrow(data.matrix)
          K <- length(vnames) - sum(cols.to.keep)
          
            (covx[cols.to.keep, cols.to.keep] -
                covx[cols.to.keep,!cols.to.keep, drop=FALSE] %*%
                    solve(covx[!cols.to.keep, !cols.to.keep, drop=FALSE],
                          covx[!cols.to.keep, cols.to.keep, drop=FALSE])
             ) * ((n-1)/(n-K))
             } else covx

        Sperp <- makeSperp(S, betas=coeffs)
        if (simplify) return(sqrt(2 * sum(covb * Sperp)))

        list("cov.betahat"= covb, "betahat"=coeffs, "S"=S)
}
##' Covariance of projections of X onto orthocomplement of X'beta, calculated from Cov(X) and beta
##'
##' A key quantity figuring in paired standard error calculations
##' @title Calculate S-perp from S and betas
##' @param S covariance of X
##' @param betas coefficients
##' @return positive definite matrix
##' @author Ben B Hansen
##' @export 
makeSperp <- function(S, betas) {
    stopifnot(is.matrix(S), nrow(S)==ncol(S), is.numeric(betas), nrow(S)==length(betas))
    Sbetas <- S %*% betas
    varPShat <- crossprod(betas, Sbetas)[1,1] # indexing to turn a 1x1 matrix into a scalar
        if (varPShat <=.Machine$double.eps) {
        warning("Xes already orthogonal to X%*%beta") 
        S } else {
              S - (1/varPShat)*Sbetas %*% t(Sbetas)
              }
}
##' Project X onto orthocomplement of X %*% beta
##'
##' 
##' @title Calculate X-perp from X and betas
##' @param X numeric matrix
##' @param betas coefficients, one for each column of X
##' @return numeric matrix of same dimension as X (ordinarily with rank rank(X)-1)
##' @author Ben Hansen
makeXperp <- function(X, betas) {
    stopifnot(is.matrix(X), is.numeric(betas), ncol(X)==length(betas))
    covx  <- cov(X)
    betas  <- drop(betas)
    xbeta  <- X %*% betas
    var_xbeta  <- crossprod(betas, covx %*% betas)[1,1]
    if (var_xbeta<=.Machine$double.eps) {
        warning("X already orthogonal to X%*%beta") 
        X
    } else {
    simple_reg_coefs  <- crossprod(betas, covx)/var_xbeta
    corr  <- xbeta %*% simple_reg_coefs
    X - corr
    }
}

getglmQweights <- function(eta, prior.weights=NULL, family=binomial())
    {
        nobs <- length(eta)
        if (is.null(prior.weights)) 
            prior.weights <- rep.int(1, nobs)
        good <- prior.weights >0
        variance <- family$variance
        linkinv <- family$linkinv
        if (!is.function(variance) || !is.function(linkinv)) 
            stop("'family' argument seems not to be a valid family object", 
                 call. = FALSE)
        mu.eta <- family$mu.eta
        mu <- linkinv(eta)
        mu.eta.val <- mu.eta(eta)
            if (any(is.na(mu.eta.val[good]))) 
                stop("NAs in d(mu)/d(eta)")
        good <- prior.weights >0 & mu.eta.val !=0
        ifelse(good,prior.weights*mu.eta.val^2/variance(mu),0)
    }
##' Uses backsolve to calculate X %*% R^-1, for R from a QR decomposition
##'
##' 
##' @title Rotate matrix X according to inverse of rotation R
##' @param X numeric matrix 
##' @param QR QR decomposition (for a matrix shaped like X)
##' @return numeric matrix, shaped like X
##' @author Ben Hansen
X_times_Rinv  <- function(X, QR)
{
    stopifnot(is.matrix(X), is.qr(QR),
              ncol(X) == ncol(QR$qr)
              )
    X  <- X[ , QR$pivot]
    xtilde  <- backsolve(qr.R(QR), t(X),
                         k=QR$rank, transpose=T)
    xtilde  <- t(xtilde)
    rownames(xtilde)  <- rownames(X)
    xtilde
    }
ppse_via_qr <-
    function(object, covariance.estimator=c("vcov", "sandwich")[1],
             data=NULL, 
             coeffs.from.fitted.model=FALSE, QR=object$qr, 
             tt=terms(formula(object),specials="strata"),
             terms.to.sweep.out=survival:::untangle.specials(tt, "strata")$terms,
             tol.coeff.alignment=Inf,
             cluster=NULL, ...) 
{      
    stopifnot(inherits(object, "glm"),
              !is.null(QR), 
              as.logical(QR$rank),
              covariance.estimator %in% c("vcov", "sandwich"),
              covariance.estimator=="sandwich" | is.null(cluster), 
              is.null(terms.to.sweep.out) | 
              is.numeric(terms.to.sweep.out) &
              all(as.integer(terms.to.sweep.out)==terms.to.sweep.out))
    terms.to.sweep.out <- unique(terms.to.sweep.out)
    nterms <-  length(attr(tt, "term.labels"))
    if (any(terms.to.sweep.out > nterms)) stop("terms.to.sweep.out values too big")
    if (!is.null(terms.to.sweep.out) && length(terms.to.sweep.out))
    {
        first_non_sweep <- min(setdiff(1L:nterms, terms.to.sweep.out))
        dontsweep <- (terms.to.sweep.out >= first_non_sweep)
        if (first_non_sweep < max(terms.to.sweep.out))
        warning(paste0(sum(dontsweep), 
	" strata() directive(s) ignored. To fix, put at beginning of model formula."))

        terms.to.sweep.out <- terms.to.sweep.out[!dontsweep]
        }


    glm.family.uses.estimated.dispersion <-
        !(substr(object$family$family, 1, 17) %in%  # borrowed from sandwich:::bread.glm
          c("poisson", "binomial", "Negative Binomial"))
    if (is.null(data)) data <- model.frame(object)
    data.matrix <- model.matrix(tt, data)
    fitted.model.coeffs  <- rep(0, ncol(data.matrix))
    names(fitted.model.coeffs)  <- colnames(data.matrix)
    fitted.model.coeffs[names(coef(object))]  <- coef(object)
    fitted.model.coeffs.NA <- is.na(fitted.model.coeffs)
    fitted.model.coeffs[fitted.model.coeffs.NA] <- 0    
    Xcols_to_terms <- attr(data.matrix, "assign")
    Xcols_to_sweep_out <- Xcols_to_terms  %in% c(0,terms.to.sweep.out)
    Qcols_to_keep <- seq_len(QR$rank)
    if (any(Xcols_to_sweep_out))
        {
    Xcols_to_sweep_out <- names(fitted.model.coeffs)[Xcols_to_sweep_out]
    Qcols_to_sweep_out <- match(Xcols_to_sweep_out, colnames(qr.R(QR)))
    Qcols_to_sweep_out <- sort(Qcols_to_sweep_out)
    if (Qcols_to_sweep_out[length(Qcols_to_sweep_out)]>length(Qcols_to_sweep_out))
        {
    Qcols_to_sweep_out <-
        Qcols_to_sweep_out[Qcols_to_sweep_out==seq_along(Qcols_to_sweep_out)]
    warning("Some sweeps not effected as QR appears to have pivotted\n so as to switch strata() & non-strata() cols.")
    }
    Qcols_to_keep <- setdiff(Qcols_to_keep, Qcols_to_sweep_out)
        }

    ## Now we start a bunch of calculations that re-figure 
    ## internal components of the glm fit: z, eta, weights. 
    if (offset  <- is.null(model.offset(data))) # offsets not 
        offset <- rep(0, nrow(data))           # currently tested.
    eta <- object$linear.predictors 

    
    ## refigure weights, since glm.fit doesn't update them after last iteration
    weights <- getglmQweights(eta, 
                              prior.weights=object$prior.weights, 
                              family=object$family)
    stopifnot(length(weights)==nrow(data))
    ## NB: To address discrepancies between coeffs reported w/ model fit
    ## and coeffs constructed from the returned QR decomposition, I tried:
    ## (1) using the weights based on penultimate glm fit,
    ## not the updated weights as figured by my `getglmQweights`.
###    weights <- object$weights
    ## (2) insisting on convergence,
###    stopifnot(object$converged)
    ## Rationale for requiring convergence: Since we don't also have access to
    ## penultimate eta's, we're relying on the convergence being far enough along
    ## that their differences  from the final etas are numerically negligible.
    ## I get the impression that the `glm.fit` convergence criteria are such as to
    ## ensure this.
    ## Neither did what I was hoping for: with the aglm example used in optmatch,
    ## I got differences  in coefficients of order 2e-6 either way. Chalking the
    ## discrepancy up (uneasily) to differences between numerical calcs used within
    ## `C_Cdqrls` and the QR-based method I'm using. 


    w <- sqrt(weights) 
    good <- !is.na(w) & w>0

    data.matrix <- data.matrix[good,]
    eta <- eta[good]
    w <- w[good]
    if (!is.null(cluster)) cluster <- factor(cluster[good])
    ## NB: successful `getglmQweights` confirms that `linkinv` is there and is a function
    linkinv <- object$family$linkinv
    mu <- linkinv(eta)
    y <- model.response(data, type="double")
    twocol_response <- !is.null(dim(y))
    y <- if (twocol_response) {
             y[good, , drop=FALSE]
         } else y[good]
    mu.eta <- object$family$mu.eta
    mu.etaval <- mu.eta(eta)
    resids <- if (twocol_response) {
        object$residuals[good]
              } else (y-mu)/mu.etaval # Roll our own if it's easy enough
    
    z <- (eta -offset) + resids # "z" as in `glm.fit`
    ## End reconstruction of internals of glm-fitting

    qmat <- qr.Q(QR)[good,]
    colnames(qmat) <- qnames <- paste0("Q.",colnames(qr.R(QR)))


    ## NB: `qcoeffs <- qr.qty(QR,z*w)` doesn't work, returns object of length length(z),
    ## not QR$rank.  Likewise for qr.qy(...)

    if (coeffs.from.fitted.model || is.finite(tol.coeff.alignment))
      {
        qcoeffs.from.fitted.model <- drop(qr.R(QR)%*%fitted.model.coeffs[QR$pivot])
        names(qcoeffs.from.fitted.model) <- qnames
        qcoeffs.from.QR <- NULL
        qcoeffs <- qcoeffs.from.fitted.model
      } else qcoeffs.from.QR <- crossprod(qmat, z*w)
    if (!coeffs.from.fitted.model) {
        if (is.null(qcoeffs.from.QR))
                qcoeffs.from.QR <- crossprod(qmat, z*w)
        qcoeffs <- qcoeffs.from.QR
                   }

    ## this is here for testing purposes 
    if (is.finite(tol.coeff.alignment))
    {
        if (is.null(qcoeffs.from.QR)) qcoeffs.from.QR <- crossprod(qmat, z*w)
            qcoeffs.from.QR[!Qcols_to_keep] <- 0
            coeff.diffs <- qcoeffs.from.fitted.model - qcoeffs.from.QR
            if (max(abs(coeff.diffs)) >= tol.coeff.alignment)
            stop(paste("QR/reported coefficients differ by up to", prettyNum(max(abs(coeff.diffs)))))
        }

    qcoeffs <- qcoeffs[Qcols_to_keep]
    qmat <- qmat[,Qcols_to_keep]
    
    ## Figures the rotation of X that expresses it in the same coordinates 
    ## as a Q matrix.  I.e., if diag(w)X = QR, Xtilde = X %*% R^(-1)
    ## First I was calculating this as diag(w^(-1))%*%Q , i.e.
    ## xtilde <- w^(-1) * qmat
    ## but I decided against this when I saw that in easy examples
    ## (cf "aglm" in tests) it was creating an (Intercept) column w/ nonzero variance.
    ## The below instead calculates  X %*% R^(-1) directly.
    ## This requires a little more computing but seemed to avoid the problem w/ the
    ## (Intercept) column.
    xtilde <- X_times_Rinv(data.matrix, QR)
    xtilde  <- xtilde[,Qcols_to_keep]

    ## Center xtilde.
    xtilde  <- if (length(Xcols_to_sweep_out)==0) {
                   scale(xtilde, center=TRUE, scale=FALSE)
                   } else {
                       stratamat  <- SparseM::as.matrix.csr(data.matrix[,Xcols_to_sweep_out, drop=FALSE])
                       slm  <- slm.fit.csr.fixed(x=stratamat, y=xtilde)
                       resid(slm)
                   }
    
    covxtilde <- cov(xtilde) # (scaling factor off if multiple strata; cf. #12)

    ## On to estimating (co)variance of the qcoeffs...
    nobs <- if (twocol_response) {
                sum(y)
            } else sum(good)
    stopifnot((rdf <- nobs - QR$rank)>0) # i.e., fitted.model$df.residual
    
    dispersion <-
        if (glm.family.uses.estimated.dispersion &&
            covariance.estimator=="vcov" #Won't use dispersion in sandwich calc
            )
        {              
            ## Following summary.glm
            df.r <- object$df.residual
            if (df.r>0)
                sum((resids^2* weights)[weights>0])/df.r else NaN
        } else 1
    
    ans <- if (covariance.estimator=="vcov") {
               ## because the Q matrix is orthogonal, corresponding
               ## nominal Cov-hat is dispersion * Identity
               cov_beta  <- dispersion * diag(ncol(xtilde))
               list("cov.betahat"=dispersion, "betahat"=qcoeffs, "X"=xtilde, "y"=y)
           } else { # in this case covariance.estimator=="sandwich"
                   esteqns <- # this calc should be the same as xtilde * weights * resids
                       qmat[1L:length(resids),,drop=FALSE] * # helps w/ bayesglm's
                       (resids * w) 
                   if (!is.null(cluster)) {
                       esteqns <- aggregate(esteqns, by = list(cluster), FUN = sum)[,-1]
                       esteqns <- as.matrix(esteqns)
                   }
                   meatmatrix.unscaled <- # (unscaled bread being the identity)
                        crossprod(esteqns)
                   ## Per KISS principle, no d.f. adjustments. For now.
                   cov_beta  <- meatmatrix.unscaled
                   list("cov.betahat"=cov_beta,
                        "betahat"=qcoeffs, "X"=xtilde, "y"=y) 
               }
    xperp  <- makeXperp(xtilde, qcoeffs)
    Sperp  <- cov(xperp)
    ms_is_diffs  <- 2 * sum(cov_beta * Sperp)

    qr_xperp  <- qr(xperp)
    chol_Sperp  <- qr.R(qr_xperp) *
        (nobs-1)^(-1/2) #improve me: cf #12
    pivot  <- qr_xperp$pivot
    chol_Sperp  <- chol_Sperp[,order(pivot)]
    scaled_cov  <- chol_Sperp %*% tcrossprod(cov_beta, chol_Sperp)
    scaled_cov_2norm  <- 2*norm(scaled_cov, type="2")
    idim  <- ms_is_diffs/scaled_cov_2norm

    if (is.finite(tol.coeff.alignment))
    {
    chol_cov_beta <- chol(cov_beta, pivot=TRUE)
    pivot  <- attr(chol_cov_beta, "pivot")
    chol_cov_beta <- chol_cov_beta[,order(pivot)]
    chol_product  <- sqrt(2) *
        tcrossprod(chol_Sperp, chol_cov_beta)
        ans[["rms_err_alt"]]  <-
            norm(chol_product, type="F")
        }
    ans  <- c(list("rms_err"=sqrt(ms_is_diffs),
                   "idim_scaled_cov"=idim),
              ans)
    class(ans)  <- c("pic_se_info", "list")
    ans
}
##'
##' Returns its first argument, unless passed an optional
##' data argument, in which case it returns the first argument
##' with the following modifications:
##' * `X`, `y` ar whittled down to objects named in that data argument
##' * `rms_err` is re-calculated against this new whittled-down new `X`. 
##' @method pic_stderr pic_se_info
##' @rdname pic_stderr-methods
##' @export
pic_stderr.pic_se_info <- function(object, covariance.estimator=NULL, data=NULL,...)
  {
    stopifnot(all(!is.na(pmatch(c("rms_err", "cov.betahat","betahat", "X"),names(object)))),
              is.numeric(object$cov.betahat),
              is.numeric(object$betahat),
              is.numeric(object$X),
              is.matrix(object$X),
              !is.null(row.names(object$X)),
              length(object$betahat)==ncol(object$X),
              length(object$cov.betahat)==1 ||
              nrow(object$cov.betahat)==ncol(object$X))

    if (is.null(data)) return(object)
    newobj  <- object
    stopifnot(is.data.frame(data) || is.matrix(data) ||
              is.character(data) || is.logical(data) ,
              !is.logical(data) || length(data)==nrow(object$X)
              )
    pos  <- if (is.logical(data)) {
                data
            } else {
                nms  <- if (is.character(data)) {
                            data
                        } else row.names(data)
                match(nms, row.names(object$X))
            }
    if (any(is.na(pos))) stop('rows in data w/o matching rows in object$X')
    newobj$X  <- object$X[pos,,drop=FALSE]

    twocol_response <- !is.null(dim(y))
    newobj$y  <-
        if (twocol_response) {
            object$y[pos, , drop=FALSE]
        } else object$y[pos]
    nobs  <-
        if (twocol_response) {
            nrow(newobj$y)
        } else length(newobj$y)

    xperp  <- makeXperp(newobj$X, newobj$betahat)
    Sperp  <- cov(xperp)
    ms_is_diffs  <- 2 * sum(newobj$cov.betahat * Sperp)
    newobj$rms_err  <- sqrt(ms_is_diffs)

    qr_xperp  <- qr(xperp)
    chol_Sperp  <- qr.R(qr_xperp)  *
        (nobs-1)^(-1/2) #improve me: cf #12
    pivot  <- qr_xperm$pivot
    chol_Sperp  <- chol_Sperp[,order(pivot)]
    scaled_cov  <- chol_Sperp %*% tcrossprod(cov_beta, chol_Sperp)
    scaled_cov_2norm  <- 2*norm(scaled_cov, type="2")
    newobj$idim_scaled_cov  <- ms_is_diffs/scaled_cov_2norm

    newobj
  }
##' @method pic_stderr pic_me_info
##' @rdname pic_stderr-methods
##' @export
pic_stderr.pic_me_info <- function(object, covariance.estimator=NULL, data=NULL,...)
  {
      class(object)  <- c("pic_se_info", class(object))
      pic_stderr(object, covariance.estimator, data, ...)
}
#' @method print pic_se_info
#' @export
print.pic_se_info  <- function(object, digits=getOption('digits')) {
    cat(paste0("pic_se_info object (a list) with `rms_err`= ",
              signif(object[['rms_err']], digits), "\n")
        )
    invisible(object)
}
##' @title Expected max of paired differences between fitted and actual index score
##' @param x Object of class \code{pic_se_info}, \code{glm} or anything else there's a \code{\link{pic_stderr}} method for
##' @param pairings factor giving subclasses, or assumed number of pairs to be made.
##' @param treatment logical defining a dichotomy for bipartite matching
##' @param ... additional arguments passed to \code{\link{pic_stderr}}
##' @return \code{pic_me_info}, a list with elements as in \code{pic_se_info}
##'         except with the addition of \sQuote{\code{max_err}}, a scalar.
##' @author Ben B. Hansen
##' @export
pic_maxerr <- function(pairings=NULL, x, treatment,...)
    UseMethod("pic_maxerr")

##' @describeIn pic_maxerr
##' Estimate max pic error prior to creation of pairs or strata
##' If \code{pairings} is \code{NULL} or unspecified, 
##' the function uses the smaller of the number of \code{TRUE}s and
##' \code{FALSE}s in \code{treatment}.  If \code{treatment} is also
##' unspecified and \code{x} is a binary regression model,
##' \code{treatment} is taken to be \code{x}'s dependent variable.
##' If \code{x} is something other than a binary regression model,
##' it's an error to leave both \code{pairings} and \code{treatment}
##' unspecified. 
##' @method pic_maxerr default
##' @export
pic_maxerr.default  <- function(pairings, x, treatment, ...) {
    pise_  <- pic_stderr(x, ...)
    if (missing(treatment))
    {
        twocol_response  <- !is.null(dim(x$y))

        binary_index_model  <-
            is.logical(x$y) ||
            (is.numeric(x$y) &&
             (twocol_response ||
              all(x$y==0 | x$y==1)
             )
            )
        treatment  <-
            if (binary_index_model) x$y else NULL
        if (binary_index_model & !twocol_response)
            treatment  <- as.logical(treatment)
    } else stopifnot(is.logical(treatment))
    ## Now `treatment` is either a logical or a 
    ## 2-column matrix of success & failure counts

    if (missing(pairings) && is.null(treatment))
        stop(paste("Need to specify target number of pairs\n",
                   "(because index model is non-binary)")
             )
    num_pairs  <-
        if (!missing(pairings))
            pairings else
                         if (is.logical(treatment))
                         {
                             n  <- length(treatment)
                             n_treated  <- sum(treatment)
                             min(n_treated, n-n_treated)
                         } else #If we're here, treatment
                         {      # has to be a 2-column response
                        num_SF  <- colSums(x$y)
                        min(num_SF)
                         }
    
    pic_maxerr_numeric_pic_se_info(pise_, ..., num_pairs=num_pairs)
}

##' @describeIn pic_maxerr Paired index error within levels of given factor
##' Estimates max, rms paired index error within levels of \code{pairings}.
##' Only pairs within a level are considered.  If \code{treatment} is
##' unspecified, all pairs are considered; otherwise pairs with a
##' \code{TRUE} and a \code{FALSE} for \code{treatment} are considered.
##' Max index error estimates result from simultating the index coefficients
##' as MVN's with covariance equal to covariance estimate provided via
##' the \code{x} argument.
##' @method pic_maxerr factor
##' @param nreps Number of Gaussian vectors to simulate when approximating \eqn{\|\{(\vec{x}_j - \vec{x}_j)(\hat\beta - \beta): i \sim j\}\|_\infty}
##' @param ... additional arguments passed to \code{\link{pic_stderr}}
##' @export
pic_maxerr.factor  <- function(pairings, x, treatment, nreps=100, ...)
{
    stopifnot(missing(treatment) ||
              length(pairings)==length(treatment),
              missing(treatment) ||
              is.logical(treatment)
              )

    ans  <- pic_stderr(x, ...)
    stopifnot(nrow(ans[['X']]) == length(pairings))
    X_  <- ans[['X']]
        
ij  <- if (!missing(treatment))
       {
           comparisons_within_strata_of(pairings, treatment)
       } else doubletons_within_strata_of(pairings)

ans[['num_pairs']]  <- nrow(ij)
        all_pair_pts  <- X_[ij[['i']], ] - X_[ij[['j']],]

        index_all_pairs <- all_pair_pts %*% ans[['betahat']]
        ans[['index_l2']] <- sqrt(mean(index_all_pairs^2))
        ans[['index_lInf']] <- max(abs(index_all_pairs))
        
        S_x  <- .5 * crossprod(all_pair_pts)/ans[['num_pairs']]
        cov_beta  <- if (is.null(dim(ans[['cov.betahat']]))) {
                         ans[['cov.betahat']] * # annoying special case
                             diag(length(ans[['betahat']]))
                         } else ans[['cov.betahat']]
        ms_is_diffs  <- 2* sum(S_x * cov_beta)
        ans[['rms_err']]  <- sqrt(ms_is_diffs)

        chol_cov_beta <- chol(cov_beta, pivot=TRUE)
        pivot  <- attr(chol_cov_beta, "pivot")
        chol_cov_beta <- chol_cov_beta[,order(pivot)]

        all_pair_pts  <- tcrossprod(all_pair_pts, chol_cov_beta)

        nvars  <- ncol(all_pair_pts)
        maxes  <- replicate(nreps,
                            max(all_pair_pts %*% rnorm(nvars))
                            )
        ans[['max_err']]  <- mean(maxes)
        ans[['max_err_simerr']]  <- sd(maxes)/sqrt(nreps)
        ans[['nreps']]  <- nreps
        class(ans)  <- c("pic_me_info", "list")
        ans
    }
##' @method pic_maxerr character
##' @rdname pic_maxerr.factor
##' @export
pic_maxerr.character<- function(pairings, x, nreps=100, ...)
    {
        pairings  <- as.factor(pairings)
        pic_maxerr(pairings, x, nreps=nreps, ...)
}
pic_maxerr_numeric_pic_se_info  <- function(x, ..., num_pairs)
    {
        stopifnot(is.numeric(num_pairs), is(x, "pic_se_info"))

        x$num_pairs  <- num_pairs
        p_  <- length(x$betahat)

        x$rms_pic_se  <- x[["rms_err"]]

        max_err_inflator  <-
            sqrt(2 *log(2 * num_pairs))
        x$max_err  <- x[["rms_err"]] *
            max_err_inflator

        pair_SE_lInf_inflator  <-
            1 + sqrt(log(num_pairs)/(p_-1))
        x$max_pic_se_extrdim  <- x[["rms_err"]] *
            pair_SE_lInf_inflator

        pair_SE_lInf_inflator_idim  <-
            1 + sqrt(log(num_pairs)/x[["idim_scaled_cov"]])
        x$max_pic_se_intrdim  <- x[["rms_err"]] *
            pair_SE_lInf_inflator_idim

        x$max_pic_se  <- x$max_pic_se_extrdim
        class(x)  <- c("pic_me_info", "list")
    x
    }
#' @method print pic_me_info
#' @export
print.pic_me_info  <- function(object, digits=getOption('digits')) {
    cat(paste0("pic_me_info object (a list) with `c(max_err, rms_err)`= c(",
              signif(object[['max_err']], digits), ", ",
              signif(object[['rms_err']], digits), ")\n")
        )
    invisible(object)
}

##' Pairwise leverage distances 
##'
##' Use to calculate \sQuote{leverage distances}, i.e.
##' paired Mahalanobis distances normalized using a generalized
##' inverse of X projected onto orthocomplement of X'beta,
##' and additionally scaled by the reciprocal square root
##' of the rank of that matrix.  Averaged across all pairs,
##' these scaled Mahalanobis distances have a mean square
##' of rank(X - Proj(X| X'beta)), by an argument similar
##' to that estabishing the mean
##' of leverages in a linear regression problem to be p/n.
##' The idea of using this orthocomplement matrix is to
##' approximate what you'd have after you matched
##' or stratified so as to remove variation in X'beta while
##' leaving other variation intact, and then stratum-centered X
##' (absorbed stratum fixed effects into it).
##'
##' Another connection to leverage is as follows. Observation-wise
##' leverages associating with the \sQuote{design matrix}
##' X - Proj(X| strata) correspond to squared
##' Mahalanobis distances from the points to stratum centroids.
##' Or rather, squared Mahalanobis distances divided by (n-1),
##' the definition of leverage involving X'X without scaling
##' rather than cov(X) = X'X/(n-1). 
##' Matrix manipulations (involving the cyclic property of the trace)
##' show the mean of these leverages to be rank(X - Proj(X| strata))/n,
##' and thus the mean of squared Mahalanobis distances to be
##' rank( X - Proj(X| strata) )*((n-1)/n). The paired leverage
##' distances calculated
##' here are Mahalanobis distances between counterparts eligible
##' for matching, as opposed to distances between a person and the
##' centroid of her intervention group. 
##' 
##' Returns a list of length 2, the first element of which is
##' a function suitable for use as a first argument to
##' \code{optmatch::match_on()}.  The corresponding \code{data}
##' argument needs to be the \code{X} entry of the same
##' \code{pic_se_info} that was used (by this function) to create
##' that function.  (I.e. the API is a work in progress.)
##' The second element of this list is rank(X - Proj(X |X'beta)).
##'
##' Bear in mind that \code{optmatch::match_on.formula()}
##' unpacks model formulas involving factors differently than
##' \code{glm()} and similar: to set contrasts it uses
##' \code{optmatch:::contr.match_on()}.
##' 
##' @title maker of Mahalanobis distances for treatment-control pairs
##' @param x \code{optmatch} or \code{pic_se_info} as returned by \code{pic_stderr()}
##' @param y (if \code{x} is factor) or \code{NULL}
##' @return list 
##' @author Ben Hansen
##' @export
make_paired_leverage_computor  <- function(x, y=NULL) {
    UseMethod("make_paired_leverage_computor")
}
#' @method make_paired_leverage_computor pic_se_info
#' @rdname make_paired_leverage_computor-methods
#' @export
make_paired_leverage_computor.pic_se_info <- function(x, y)
{
    stopifnot(inherits(x, "pic_se_info"))
    dat  <- makeXperp(x[['X']], x[['betahat']])
    cv  <-  cov(dat)
    dnx  <- dimnames(cv)
    s  <- svd(cv)
    nz  <- (s$d > sqrt(.Machine$double.eps) * s$d[1])
    if (!any(nz)) stop("cov(x[['X']]) has rank <=1")
    colrank_X  <- sum(nz, na.rm=TRUE)
    
    inv.scale.matrix  <- s$v[, nz] %*% (t(s$u[, nz])/s$d[nz])
    dimnames(inv.scale.matrix)  <- dnx[2:1]
    
    list(FUN=function(index, data, z) {
        xperp <- makeXperp(data, x[['betahat']]) # ¿do I want to remove the betahat direction?
        optmatch:::mahalanobisHelper(xperp, index, inv.scale.matrix)
    }, rank=colrank_X, Xperp=dat)
}
#' @method make_paired_leverage_computor factor
#' @rdname make_paired_leverage_computor-methods
#' @export
make_paired_leverage_computor.factor  <- function(x, y) {
    stopifnot(is.factor(x), !is.null(y), is.matrix(y), is.numeric(y),
              length(x)==nrow(y))
    
    S  <- SparseMMFromFactor(x)
    slm  <- slm.fit.csr.fixed(x=S,y=y)
    xperp   <- resid(slm)
    cv  <- cov(xperp)
    dnx  <- dimnames(cv)
    s  <- svd(cv)
    nz  <- (s$d > sqrt(.Machine$double.eps) * s$d[1])
    if (!any(nz)) stop("cov(x[['X']]) has rank <=1")
    colrank_X  <- sum(nz, na.rm=TRUE)
    
    inv.scale.matrix  <- s$v[, nz] %*% (t(s$u[, nz])/s$d[nz])
    dimnames(inv.scale.matrix)  <- dnx[2:1]

    list(FUN=function(index, data, z) {
        optmatch:::mahalanobisHelper(data, index, inv.scale.matrix)
    }, rank=colrank_X, Xperp=xperp)
    }
    
