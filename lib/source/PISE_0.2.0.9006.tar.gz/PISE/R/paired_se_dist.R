##' @param object fitted model, inheriting from lm
##' @param covariance.estimator character string 
##' @param data data frame or matrix
##' @importFrom sandwich vcovHC
##' @export
paired_se_dist <-
    function(object, covariance.estimator=c("vcov", "sandwich")[1],
             data=NULL)
{
    stopifnot(inherits(object, "lm"))
    vcov_type  <- match.arg(covariance.estimator, c("vcov", "sandwich"))
    vcov_  <- if (vcov_type=="vcov" || inherits(object, "svyglm")) {
                  vcov(object)
              } else sandwich::vcovHC(object, type="HC0")
    which_vars  <- names(coef(object))[!is.na(coef(object))]
    which_vars  <- Filter(function(x) {x!="(Intercept)"},
                          which_vars)
    vcov_  <- vcov_[which_vars, which_vars]
    mframe  <- if (is.null(data)) {
                   model.frame(object, xlev = object$xlevels)
               } else model.frame(terms(object), data=data,
                                  xlev = object$xlevels)
    covs  <- model.matrix(object, data=mframe, contrasts.arg=object$contrasts)
    covs  <- covs[, which_vars, drop=FALSE]
    compute_pses_for_this_model  <-
        function(index, data, z) {
            optmatch:::mahalanobisHelper(data, index, vcov_)
            }
    optmatch:::match_on.function(compute_pses_for_this_model, data=covs,
                                z=model.response(mframe))
    }
