##' ---
##' output:
##'     html_document: 
##'         keep_md: true
##'     md_document:
##'         variant: gfm
##' ---
##' # Setup
##' 
##+ setup, echo=FALSE, warning=FALSE, message=FALSE
knitr::opts_chunk$set(warning=FALSE, message=FALSE, error=FALSE, echo=TRUE)
libloc <- file.path("..", "..", ".local", 
                    R.Version()$platform, 
                    paste(R.Version()$major,
                          strsplit(R.Version()$minor, ".", 
                                   fixed=T)[[1]][1],
                          sep=".")
                    )
unloadNamespace("optmatch")
unloadNamespace("RItools")
library("RItools", lib.loc=libloc)
withr::with_libpaths(libloc, library("PISE"),
                     action="prefix")
library("optmatch")
stopifnot(packageVersion("optmatch") >= '0.9.16',#avoid breaking `stepAIC()` as applied to svyglms
          packageVersion("RItools") >= '0.2.0.9004',
          packageVersion("PISE") >= '0.1.0.9005')
library("survey")
library("tidyverse")
if (!exists("regenerate_stratifications"))
    regenerate_stratifications  <- FALSE
## The county data excluding year-specific mortality rates. 
##+ datasetup, cache=2
counties <- read_csv(file.path("..", "extdata", "base_cnty0.csv")) %>%
    mutate(mass_cnty = (stateFIPS == "25")) %>%
    mutate_at(c("adjcnt_White_M", "adjcnt_White_F", "adjcnt_Black_M", "adjcnt_Black_F", "adjcnt_other_M", "adjcnt_other_F"), ~ 100 * .x / adjcnt_a20_64)
##' Private resources: county data w/ year specific mortality.
##+ 
base_cnty <- read_csv(file.path("..", "extdata", "base_cnty.csv")) %>%
    mutate(mass_cnty = (stateFIPS == "25"),
           a20_44=a20_34+a35_44,
           a45_64=a45_54+a55_64) %>%
    mutate_at(c("adjcnt_White_M", "adjcnt_White_F", "adjcnt_Black_M", "adjcnt_Black_F", "adjcnt_other_M", "adjcnt_other_F"), ~ 100 * .x / adjcnt_a20_64) %>%
    mutate(mortAC01_03=mortAC2001+mortAC2002+mortAC2003,
           mortAC04_06=mortAC2004+mortAC2005+mortAC2006,
           mortAC02_04=mortAC2002+mortAC2003+mortAC2004,
           mortAC03_05=mortAC2003+mortAC2004+mortAC2005,
           mortAC01_02=mortAC2001+mortAC2002,
           mortAC03_04=mortAC2003+mortAC2004,
           mortAC05_06=mortAC2005+mortAC2006)
base_cnty_svydesign  <-
    survey::svydesign(id=~1, weights=~a20_64_cnt, data=base_cnty)
##'
##' Names of MA counties, per
##' https://en.wikipedia.org/wiki/List_of_counties_in_Massachusetts
##+
mass_counties  <-
    readr::read_tsv("../extdata/mass_cnty_fips.tsv",
                    col_types="ccc")
##' My abbreviations of MA county names
##+
mass_counties %>%
    mutate(cnty_abbrev=abbreviate(cnty_name, 2, method="both.sides")
           ) -> mass_counties
##'
##' # Propensity scores
##' 
##' ## SLB propensity score
##' 
##' One private resource that we've loaded in is a near-reproduction of the
##' SLB propensity score.  The only difference, I think, has to do with the
##' origin of the `latino` variable: they took theirs from the AHRF, but the
##' more recent AHRF I was able to obtain didn't carry that variable in these 
##' years, so instead I took it from the county-level population data that NCHS
##' maintains alongside of the mortality data. 
##+ 
sglm0  <-
    survey::svyglm(mass_cnty~a20_34+a35_44+a45_54+a55_64+
                       male+white_race+black_race+other_race+latino+
                       pov+inc+unemp+unins+
                       mortAC2001+mortAC2002+mortAC2003+
                       mortAC2004+mortAC2005+mortAC2006,
                   design=base_cnty_svydesign, data=base_cnty,
                   model=TRUE, # FALSE caused svyglm to choke
                   family=quasibinomial)

counties$ppty0 <- sglm0$linear.predictors
##' The PIC SE value of this score is:
##+ eval=TRUE
(pie_sglm0 <- pic_maxerr(x=sglm0, 
                    covariance.estimator = "sandwich")
  )
##' The pooled s.d. of this score, calculated with weighting for county size:
##+
counties %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
  PISE:::standardization_scale(counties$ppty0, counties$mass_cnty, 
                               PISE:::svy_sd, .) -> s_p_sglm0 
s_p_sglm0
##' quite a bit smaller than the PIC SE.  It reflects within-group
##' propensity dispersion as follows.
##' Ranges and medians of both groups:
counties %>% group_by(mass_cnty) %>%
    dplyr::select(ppty0) %>%
        summarise(min=min(ppty0), med=median(ppty0), max=max(ppty0))
##' Treatment group mean and s.d. (weighted):
counties %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    subset(!!mass_cnty) %>% survey::svymean(~ppty0, .) %>% 
  .[["ppty0"]]
counties %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    subset(!!mass_cnty) %>% survey::svyvar(~ppty0, .) %>% 
  .[["ppty0"]] %>% sqrt()

##' Comparison reservoir mean and s.d. (weighted):
counties %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    subset(!mass_cnty) %>% survey::svymean(~ppty0, .) %>% 
  .[["ppty0"]]
counties %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    subset(!mass_cnty) %>% survey::svyvar(~ppty0, .) %>% 
  .[["ppty0"]] %>% sqrt()
##' Unweighted root-mean square of paired PS differences:
with(counties, sqrt(2*var(ppty0)))
##' ... or, as a multiple of the pooled s.d., 
with(counties, sqrt(2*var(ppty0))/s_p_sglm0)
##' 
##' ### SLB propensity score subsetting
##' 
##' Per SLB,
##' 
##' > we used propensity scores to define a control group of counties
##' > in nonreform states that were most similar to prereform
##' > Massachusetts counties. We estimated propensity scores...
##' > The quartile of counties with the highest propensity scores,
##' > indicating the closest match to the overall population of
##' > Massachusetts's 14 counties, was used as the control group
##' > in the mortality analysis.
##'
##' I take this to mean the following.  
counties %>% dplyr::filter(mass_cnty==0) %>% 
    survey::svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    survey::svyquantile(~ppty0,.,quantiles=0.75) %>%
    .[[1]] %>% .[1] -> 
    cutoff 
counties <- mutate(counties, 
                   ps0_trim = mass_cnty | (!mass_cnty & ppty0 >= cutoff)
                   ) %>% mutate(ps0_trim=factor(ifelse(ps0_trim, 'in', NA)))
##'
##' Whereas SLB wound up with 513 controls for MA's 14 counties, this
##' yields:
##'
counties %>% dplyr::filter(!is.na(ps0_trim)) %>% with(table(mass_cnty))
optmatch::effectiveSampleSize(counties$ps0_trim, counties$mass_cnty)
##' Trimmed comparison reservoir mean and s.d. (weighted):
counties %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    subset(!mass_cnty&!is.na(ps0_trim)) %>% 
    survey::svymean(~ppty0, .) %>% 
    .[["ppty0"]] 
counties %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    subset(!mass_cnty&!is.na(ps0_trim)) %>% 
    survey::svyvar(~ppty0, .) %>% 
    .[["ppty0"]] %>% sqrt()
##' Unweighted root mean square of paired PS differences:
counties %>% dplyr::filter(!is.na(ps0_trim)) %>%
    with(sqrt(2*var(ppty0)))
##' ... and as a multiple of the pooled s.d., 
counties %>% dplyr::filter(!is.na(ps0_trim)) %>%
    with(sqrt(2*var(ppty0))/s_p_sglm0)
##'
##' How did MA counties fall in relation to the cutoff?
##+
counties %>% dplyr::filter(!is.na(ps0_trim)) %>%
    with(table(mass_cnty, ppty0>=cutoff))
cutoff
##' 
##' The two below-cutoff counties are Dukes County,
##' the combination of Martha's Vineyard & Naushon Island,
##' and Nantucket Island.  (Which are also left-outliers population-wise.)
##+

counties %>% dplyr::filter(mass_cnty, ppty0<cutoff) %>%
    dplyr::select(ppty0, a20_64_cnt)
counties %>% dplyr::filter(ppty0>=cutoff) %>%
    group_by(mass_cnty) %>% 
    dplyr::select(ppty0, a20_64_cnt) %>%
        summarise_all(range)
##' 
##' Scatter of log population by `ppty0` and log pop, excluding upper and lower .05%
##' on either variable. (In terms of both propensity score and population, MA counties
##' fall within the middle 99.9%. The scatterplot's easier to read if 
##' you trim the lower and upper twentieth of a percent.)  
##+ pop_by_ppty0_scatter0, echo=FALSE, eval=TRUE

counties %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    svyquantile(~ppty0+log10(a20_64_cnt), ., c(.0005, .9995)) ->
    qtiles0
if (is(qtiles0, "newsvyquantile"))
    qtiles0 <-
        sapply(qtiles0, function(x) x[,1, drop=TRUE], simplify=FALSE) %>%
        do.call(rbind, .) 
counties %>% #dplyr::filter(mass_cnty==0) %>% 
    survey::svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
        survey::svyquantile(~ppty0, ., quantiles=.5) %>%
        .[[1]] %>% .[1] -> ppty0_median
counties %>% #dplyr::filter(mass_cnty==0) %>% 
    survey::svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
        survey::svyquantile(~log10(a20_64_cnt), ., quantiles=.42) %>%
        .[[1]] %>% .[1] -> logpop_median
counties %>% #dplyr::filter(mass_cnty==0) %>% 
    survey::svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
        survey::svyquantile(~log10(a20_64_cnt), ., quantiles=.1) %>%
        .[[1]] %>% .[1] -> logpop_1stdecile
counties %>% filter(mass_cnty) %>%
    transmute(ppty0, logpop=log10(a20_64_cnt)) %>%
    sapply(range) %>% t() ->
    mass_range0
colnames(mass_range0)  <- c("min", "max")

pop_by_ppty0_scatter  <- function()
    {
plot(log10(a20_64_cnt) ~ ppty0, type="n",
     xlim=c(min(qtiles0["ppty0",1], mass_range0["ppty0",1]),
            max(qtiles0["ppty0",2], mass_range0["ppty0",2]+pie_sglm0$rms_err)
            ),
     ylim=c(min(qtiles0["log10(a20_64_cnt)", 1], mass_range0["logpop", 1]),
            max(qtiles0["log10(a20_64_cnt)", 2], mass_range0["logpop", 2])
            ),
     data=counties,
     main="US Counties",
     xlab=expression(paste("SLB\'s ", bold(x), hat(beta))),
     ylab="log10(pop. aged 20-64)")
counties %>% filter(stateFIPS!=25, ppty0>=cutoff) %>%
    with(points(ppty0, log10(a20_64_cnt), pty=2, col="red", cex=0.1))
counties %>% filter(stateFIPS!=25, ppty0<cutoff) %>%
    with(points(ppty0, log10(a20_64_cnt), pty=2, col="lightgray", cex=0.1))
counties %>% filter(stateFIPS==25) %>%
    left_join(mass_counties, by=c("stateFIPS", "cntyFIPS")) %>% 
    with(text(ppty0, log10(a20_64_cnt),
              labels=cnty_abbrev, adj=0.5, cex=0.75, col="blue")
         )
legend("topleft", with(mass_counties, paste(cnty_abbrev, cnty_name)),
       text.col="blue", cex=0.5, 
       bty="o", box.col="lightgray",
       inset=0.05, title.col="blue", title=expression(underline("Massachusetts"))
       )
    }
pop_by_ppty0_scatter()
##'
##' Again with more structure on the plot. The horizontal lines are at
##' the first decile and at the 42nd percentile of logged population, the
##' 42nd percentile being chosen because it was close to the median and
##' close to half way between two groups of blue (MA) counties.  The vertical
##' lines are at the median propensity score and ± `sqrt(2*log(2*min(n_t, n_c)))`
##' PIC SE's above and below that median.
##+ pop_by_ppty0_scatter2
pop_by_ppty0_scatter()
abline(h=logpop_median, col="lightgray")
abline(h=logpop_1stdecile, col="lightgray")
abline(v=ppty0_median, col="lightgray")
abline(v=(ppty0_median-pie_sglm0$max_err), col="lightgray")
abline(v=(ppty0_median+pie_sglm0$max_err), col="lightgray")
##'
##' ### Subclassifications based on SLB PS
##+
counties %>% #dplyr::filter(mass_cnty==0) %>% 
    survey::svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
        survey::svyquantile(~ppty0, ., quantiles=.5) %>%
        .[[1]] %>% .[1] -> ppty0_median
counties %>% #dplyr::filter(mass_cnty==0) %>% 
    survey::svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
        survey::svyquantile(~log10(a20_64_cnt), ., quantiles=.42) %>%
        .[[1]] %>% .[1] -> logpop_median
counties %>% #dplyr::filter(mass_cnty==0) %>% 
    survey::svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
        survey::svyquantile(~log10(a20_64_cnt), ., quantiles=.1) %>%
        .[[1]] %>% .[1] -> logpop_1stdecile

counties$ps0_strat0  <- cut(counties$ppty0,
                            c(ppty0_median-pie_sglm0$max_err,
                              ppty0_median,
                              ppty0_median+pie_sglm0$max_err),
                            include.lowest=T)
counties$ps0_strat1  <- cut(log10(counties$a20_64_cnt),
                            c(0, logpop_1stdecile, 10)
                            ) %>% factor(labels=c("tiny", "_")) %>%
    interaction(counties$ps0_strat0, .)
with(counties, table(mass_cnty, ps0_strat1))

counties$ps0_strat2  <- cut(log10(counties$a20_64_cnt),
                            c(0, logpop_median, logpop_1stdecile, 10)
                            ) %>% factor(labels=c("sm", "med", "lg")) %>%
    interaction(counties$ps0_strat0, .)
with(counties, table(mass_cnty, ps0_strat2))
##' For each subclassification, identify subclasses that are "concordant", i.e. either
##' have no treatment group members or no controls; then set their subclass status to NA
##' (to encode leaving these observations out of the analysis).
##+ echo=2:4
concordant_to_NA  <- function(fac_nm) {
    stopifnot(any(fac_nm==colnames(counties)),
              is.factor(counties[[fac_nm]]),
              any('mass_cnty'==colnames(counties)
                  )
              )
    actives  <- tapply(counties$mass_cnty,
                       counties[[fac_nm]],
                       var) > 0
    actives  <- levels(counties[[fac_nm]])[actives]
    factor(counties[[fac_nm]], levels=actives)
    }
counties["ps0_strat0"]  <- concordant_to_NA("ps0_strat0")
counties["ps0_strat1"]  <- concordant_to_NA("ps0_strat1")
counties["ps0_strat2"]  <- concordant_to_NA("ps0_strat2")
##' 
##' 
##' ## Two new PS models
##'
##' First a model replacing year-specific all-cause mortality with 3
##' year aggregates. (The aggregation should mean that the underlying
##' data sets can be more readily shared.) Then a stepwise-selected
##' model with access to these and other covariates.  
##' 
##' ### Variant of SLM model using 3-year aggregated mortality
##' 
##+ 
sglm1  <-
    survey::svyglm(mass_cnty~a20_34+a35_44+a45_54+a55_64+
                       male+white_race+black_race+other_race+latino+
                       pov+inc+unemp+unins+
                       mortAC01_03+mortAC02_04+
                       mortAC03_05+mortAC04_06,
                   design=base_cnty_svydesign, data=base_cnty,
                   model=TRUE, # FALSE caused svyglm to choke
                   family=quasibinomial)
##'
##+ 
counties$ppty1  <- sglm1$linear.predictors
counties %>% dplyr::filter(mass_cnty==0) %>% 
    survey::svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    survey::svyquantile(~ppty1,.,quantiles=.75) %>%
    .[[1]] %>% .[1]  -> cutoff1
cutoff1
counties %>% with(table(mass_cnty, ppty1> cutoff1))
counties$ps1_trim  <- factor(ifelse(counties$ppty1>=cutoff1 |
                                     counties$mass_cnty,
                                     1, NA)
                              )
##' A standard deviation and a standard error for this score:
##+
counties %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
  PISE:::standardization_scale(counties$ppty1, counties$mass_cnty, 
                               PISE:::svy_sd, .) -> s_p_sglm1 
s_p_sglm1
pie_sglm1 <- pic_maxerr(x=sglm1, covariance.estimator = "sandwich")
pie_sglm1
##' ### Variant of SLM model selected via AIC
##'
##' A variant trimming elsewhere than prior all-cause mortality,
##' using stepwise selection
##' guided by Lumley & Scott's (2015) adaptation of AIC.
##+ stepsearch, cache=TRUE
sglm2  <- MASS::stepAIC(sglm1, ~ . + mortAC2001 + mortAC2006 + a20_44 + a45_64, trace=F)
sglm2
counties$ppty2  <- sglm2$linear.predictors

##' <!-- Temporary workaround, should I inadvertently break stepAIC again.
##'      Code suppressed from output. --> 
##+  eval=FALSE, echo=FALSE
sglm2 <- svyglm(mass_cnty ~ a45_54 + male + black_race +
                    unins + mortAC02_04 + mortAC04_06,
                design=base_cnty_svydesign, data=base_cnty,
                model=TRUE, family=quasibinomial)
sglm2
counties$ppty2  <- sglm2$linear.predictors
##' Sample trimming in the manner of SLB, but using the trimmed
##' propensity score model.
counties %>% dplyr::filter(mass_cnty==0) %>% 
    survey::svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    survey::svyquantile(~ppty2,.,quantiles=.75) %>%
    .[[1]] %>% .[1]  -> cutoff2
counties$ps2_trim  <- factor(ifelse(counties$ppty2>=cutoff2 |
                                     counties$mass_cnty,
                                     1, NA)
                              )
##' A standard deviation and a standard error for this score:
##+
counties %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
  PISE:::standardization_scale(counties$ppty2, counties$mass_cnty, 
                               PISE:::svy_sd, .) -> s_p_sglm2 
s_p_sglm2
( pie_sglm2  <- pic_maxerr(x=sglm2, covariance.estimator = "sandwich") )
counties %>% dplyr::filter(mass_cnty, ppty2<cutoff2) %>%
    dplyr::select(stateFIPS, cntyFIPS, ppty2) %>%
  dplyr::mutate(sds_below=(cutoff2-ppty2)/s_p_sglm2,
                pic_ses_below=(cutoff2-ppty2)/pie_sglm2$rms_err
                )
##' Cut points for a subclassification on ppty2.
##+

mass_range2  <- counties %>% filter(mass_cnty) %>%
    transmute(ppty2, logpop=log10(a20_64_cnt)) %>%
    sapply(range) %>% t()

ppty2_cutpoints  <- seq(mass_range2["ppty2",1]-pie_sglm2$rms_err,
                        mass_range2["ppty2",2]+pie_sglm2$rms_err,
                        length=5)
##' The distance between consecutive cut points is
##' `r diff(ppty2_cutpoints)[1]/pie_sglm2$max_err` of the estimated max PIC error. 
##' 
##' Scatter of log population by `ppty2`, excluding upper and lower .05%
##' on either variable and showing the propensity subclassification cut
##' points.
##+ pop_by_ppty2_scatter, echo=FALSE
counties %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    svyquantile(~ppty2+log10(a20_64_cnt), ., c(.0005, .9995)) ->
    qtiles2
if (is(qtiles2, "newsvyquantile")) {
        sapply(qtiles2, function(x) x[,1, drop=TRUE], simplify=FALSE) %>%
            do.call(rbind, .) ->
            qtiles2 }
plot(log10(a20_64_cnt) ~ ppty2, type="n",
     xlim=c(min(qtiles2["ppty2",1], mass_range2["ppty2",1]),
            max(qtiles2["ppty2",2], mass_range2["ppty2",2])
            ),
     ylim=c(min(qtiles2["log10(a20_64_cnt)", 1], mass_range2["logpop", 1]),
            max(qtiles2["log10(a20_64_cnt)", 2], mass_range2["logpop", 2])
            ),
     data=counties,
     main="US Counties", xlab="trimmed propensity (ppty2)",  ylab="log10(pop. aged 20-64)")
counties %>% filter(stateFIPS!=25) %>%
    with(points(ppty2, log10(a20_64_cnt), pty=2, col="red", cex=0.1))
counties %>% filter(stateFIPS==25) %>%
    left_join(mass_counties, by=c("stateFIPS", "cntyFIPS")) %>% 
    with(text(ppty0, log10(a20_64_cnt),
              labels=cnty_abbrev, adj=0.5, cex=0.75, col="blue")
         )
legend("topleft", with(mass_counties, paste(cnty_abbrev, cnty_name)),
       text.col="blue", cex=0.5, 
       bty="o", box.col="lightgray",
       inset=0.05, title.col="blue", title=expression(underline("Massachusetts"))
       )
abline(v=ppty2_cutpoints, col="lightgray")
abline(h=logpop_median, col="lightgray")
abline(h=logpop_1stdecile, col="lightgray")

##' ### Balance after SLB-style trimming on the 3 scores in turn
##' 
##' Balance of samples trimmed in the manner of SLB, but using
##' each  of the three propensity score variants in turn. 
covariates_SLB <-
    c("a20_34", "a35_44", "a45_54", "a55_64",
      "male", "white_race", "black_race", "other_race", "latino",
      "pov", "inc", "unemp", "unins", "mortAC_20_64")
covariates_SLB %>% 
    paste(collapse="+") %>%
    paste("mass_cnty ~", ., "-1+strata(ps0_trim)+strata(ps1_trim)+strata(ps2_trim)") %>%
    as.formula() %>%
    balanceTest(counties, unit.weights=a20_64_cnt) |>
                print(which.stats=c("adj.diff", "Treatment", "Control"))
##' Balance following sample trimming differs only slightly by
##' propensity score variant.
##'
##' ### AIC and other comparisons of the 3 PS models
##' 
##' Model comparisons, using the Lumley & Scott (2014, 2015)
##' adaptation of AIC.
##+
AIC(sglm0,sglm1, sglm2)
##' There is also the Rao-Scott (1984) adaptation of the LRT,
##' and a Lumley-Scott BIC variant as well. Their `survey`
##' implementations require symbolic nesting of models,
##' so we first fit (invisibly) a variant `sglm0b` that
##' should be equivalent up to numerical differences to `sglm0`,
##' but uses the 3-year mortality aggregate variables.
##+ echo=2:4
sglm0b  <-
    survey::svyglm(mass_cnty~a20_34+a35_44+a45_54+a55_64+
                       male+white_race+black_race+other_race+latino+
                       pov+inc+unemp+unins+
                       mortAC2001+mortAC01_03+mortAC02_04+
                       mortAC03_05+mortAC04_06+mortAC2006,
                   design=base_cnty_svydesign, data=base_cnty,
                   model=TRUE,
                   family=quasibinomial)
anova(sglm0b, sglm1, method="LRT")
anova(sglm1, sglm2, method="LRT")
BIC(sglm0b,sglm1, sglm2, maximal=sglm0b)
##'
##' ## Subclassification on AIC-trimmed propensity score
##'
##' A propensity score stratification with widths of
##' `sqrt(2*log(min(n_t, n_c))) * pie_sglm2$rms_err`, going one PIC SE
##' above and below the MA max and min.  Plus a variant of same the segregates v. small counties. 
##+
diff(ppty2_cutpoints)/pie_sglm2$rms_err
counties$ps2_strat0  <- cut(counties$ppty2,
                           ppty2_cutpoints,
                           include.lowest=T)
with(counties, table(mass_cnty, ps2_strat0))
counties["ps2_strat0"]  <- concordant_to_NA("ps2_strat0")
cut(log10(counties$a20_64_cnt), c(0, logpop_1stdecile, 10), include.lowest=T) %>%
    factor(labels=c("tiny", "_")) %>%
    interaction(counties$ps2_strat0, .) -> counties$ps2_strat1
with(counties, table(mass_cnty, ps2_strat1))
counties["ps2_strat1"]  <- concordant_to_NA("ps2_strat1")
with(counties, table(mass_cnty, ps2_strat1))
cut(log10(counties$a20_64_cnt), c(0, logpop_median, logpop_1stdecile, 10), include.lowest=T) %>%
    factor(labels=c("sm", "med", "lg")) %>%
    interaction(counties$ps2_strat0, .) -> counties$ps2_strat2
counties["ps2_strat2"]  <- concordant_to_NA("ps2_strat2")
with(counties, table(mass_cnty, ps2_strat2))
with(counties, effectiveSampleSize(ps2_strat2, mass_cnty))
##' corresp balance calcs
##+
covariates_SLB %>% 
    paste(collapse="+") %>%
    paste("mass_cnty ~", ., "-1+strata(ps2_trim)+strata(ps2_strat0)+strata(ps2_strat1)+strata(ps2_strat2)") %>%
    as.formula() %>%
    balanceTest(counties, unit.weights=a20_64_cnt) |>
                print(which.stats=c("Treatment", "Control"))

##' I.e., with `ps2_strat2` we at last escape rejection at 0.05 level. 
##'
##' ## Paired SE  distances within trimmed sample/subclasses
##'
##' First within ppty0 trimmed sample and subclasses
##+
paired_se_sglm0  <- paired_se_dist(sglm0, covariance.estimator="sandwich")
paired_se_sglm0  <- paired_se_sglm0/pie_sglm0$rms_err
summary(as.numeric(paired_se_sglm0))
(paired_se_sglm0 +
        exactMatch(mass_cnty ~ factor(ps0_trim, exclude=NULL), data=counties)
) %>% as.numeric() %>%
    floor() %>% table()
(paired_se_sglm0 +
        exactMatch(mass_cnty ~ factor(ps0_strat2, exclude=NULL), data=counties)
) %>% as.numeric() %>%
    floor() %>% table()
##' Now within ppty2 trimmed sample/subclasses
##+
paired_se_sglm2  <- paired_se_dist(sglm2, covariance.estimator="sandwich")
paired_se_sglm2  <- paired_se_sglm2/pie_sglm2$rms_err
summary(as.numeric(paired_se_sglm2))
(paired_se_sglm2 +
        exactMatch(mass_cnty ~ factor(ps2_trim, exclude=NULL), data=counties)
) %>% as.numeric() %>%
    floor() %>% table()
(paired_se_sglm2 +
        exactMatch(mass_cnty ~ factor(ps2_strat2, exclude=NULL), data=counties)
) %>% as.numeric() %>%
    (function(x) x[x>=2]) %>% sort() #floor() %>% table()
##' 
##' # Propensity score pair matches
##'
##' Convenience function
##+
lInf_and_l2 <- function(x) c(`lInf`=max(abs(x)), `l2`=sqrt(mean(x^2)))
##' ## Matching on a single index
##' 
ppty0_dist  <- 
    match_on(counties$ppty0, z=counties$mass_cnty,
             data=counties)
counties$pm_ppty0  <- pairmatch(ppty0_dist, data=counties)
counties$pm_ppty0 %>% matched.distances(ppty0_dist) %>%
    unlist() %>% lInf_and_l2()
counties$pm_ppty0 %>% matched.distances(ppty0_dist) %>%
    unlist() %>% lInf_and_l2()
##' To interpret, recall that
##+ 
s_p_sglm0 ; pie_sglm0
##' How closely have we matched on the other score?
ppty2_dist  <- 
    match_on(counties$ppty2, z=counties$mass_cnty,
             data=counties)
counties$pm_ppty0 %>% matched.distances(ppty2_dist) %>%
    unlist() %>% lInf_and_l2()
s_p_sglm2 ; pie_sglm2
##' Dramatically farther away on that score than on the one
##' we had matched on. 
##' Now reversing the roles of the 2 scores, i.e.
##' pair matching based on `ppty2`:
counties$pm_ppty2  <- pairmatch(ppty2_dist, data=counties)
counties$pm_ppty2 %>% matched.distances(ppty2_dist) %>%
    unlist() %>% lInf_and_l2()
counties$pm_ppty2 %>% matched.distances(ppty0_dist) %>%
    unlist() %>% lInf_and_l2()
##' (Hmm, still not great... for an attempted remedy see
##' Ancillary explorations: Mahalanobis matches, below.)
##'
##' Adding this match to the plot:
##+ pop_by_ppty0_scatter3
pop_by_ppty0_scatter()
counties %>% filter(stateFIPS!=25, !is.na(pm_ppty0)) %>%
    with(points(ppty0, log10(a20_64_cnt), pch=21, col="red", bg="red"))

##'
##' ## Matching on index plus paired index SE
##'
##' 
ppty0_pse_dist  <- paired_se_dist(sglm0)
summary(ppty0_pse_dist)
ppty0_pse_dist  <- # ISM type persists better across arith ops
    as.InfinitySparseMatrix(ppty0_pse_dist)
##' 
##' 
##+
npairs_target  <- pie_sglm0$num_pairs
mean(ppty0_pse_dist > pie_sglm0$max_pic_se)
##' Now figure the sum distance.
##' Before they're combined with estimated index difference
##' distances, standard error distances need to be scaled up
##' to reflect expected max paired index contrast error.
##+
ppty0_sum_dist  <- ppty0_dist +
    ppty0_pse_dist * sqrt(2* log(2 * npairs_target))
mean(ppty0_sum_dist <= 0.25*s_p_sglm0)
##' I.e., imposing sums of conventional width calipers
##' on the propensity score and paired propensity SE
##' simultaneously would cause significant loss of sample:
ppty0_sum_dist %>%
    match_on(caliper=0.5*s_p_sglm0) %>% summary()
##' This stands in contrast to matching
##' on the propensity score without attention to
##' variability: 
ppty0_dist %>% match_on(caliper=0.25*s_p_sglm0) %>% summary()
##' As a caliper width for the sum distance, we add our
##' lowball estimates of the expected max pic error and expected max
##' pic SE (w/ suitable upscaling on part of the latter).
##+
(ppty0_sum_cal  <-
     with(pie_sglm0, max_err +
                     sqrt(2* log(2 * npairs_target)) *
                     max_pic_se
          )
)
ppty0_sum_dist |> match_on(caliper=ppty0_sum_cal) |>
    summary()
##' Every treated county has eligible matches.  In fact,
mean(ppty0_sum_dist > ppty0_sum_cal)
ppty0_sum_dist |> match_on(caliper=ppty0_sum_cal) |>
    pairmatch(data=counties, controls=100) |> summary()
##' I didn't explore much past this.
##' Here is variant of this distance that addresses large SEs
##' only, by tallying SE contributions only when they exceed
##' the expected max SE (for pairs that are well matched on the
##' underlying index, with the optimistic assumptions of Normal
##' covariates and extrinsic not intrinsic dimension). Here are
##' the pair SEs that exceed that mark:
##+
ppty0_dist_e  <-
    pmax(ppty0_pse_dist, pie_sglm0$max_pic_se) -
    pie_sglm0$max_pic_se
mean(as.vector(ppty0_dist_e)>0)
summary(as.vector(ppty0_dist_e)[as.vector(ppty0_dist_e)>0])
##' ...but that's not the distance for matching on; this is:
ppty0_dist_e  <- ppty0_dist +
    ppty0_dist_e * sqrt(2* log(2 * npairs_target))
mean(ppty0_dist_e > pie_sglm0$max_err)
ppty0_dist_e |> match_on(caliper=pie_sglm0$max_err) |>
    pairmatch(data=counties, controls=100) |> summary()
##' (Before matching, let's see how frequently/how badly
##' the more parsimonious propensity score sd's exceed
##' their "expected max".
##+
mean(paired_se_dist(sglm2) > pie_sglm2$max_pic_se)
paired_se_dist(sglm2) |>
(\(x) x[x>pie_sglm2$max_pic_se])() |> summary()
##' ...no better than with the original score, it seems.)
##' 
##' Pair match on ppty0 distance, within calipers of
##' the PIC SE enhanced ppty0 distance immediately above, and also
##' ± 1 in log base 10 of population.
ppty0_dist_twocaliper  <-
    ( caliper(ppty0_dist_e, width=pie_sglm0$max_err) +
      caliper(match_on(mass_cnty ~ log10(a20_64_cnt),
                           method="euclidean",
                           data=counties),
                  width=1
                  ) + 
      match_on(ppty0_dist, data=counties)
    )
###' Fraction of pairs that this excludes:
1 - length(ppty0_dist_twocaliper)/prod(dim(ppty0_dist_twocaliper))

counties$pm_ppty0_e  <-
    pairmatch(ppty0_dist_twocaliper, data=counties)
counties$pm_ppty0_e %>%
    matched.distances(ppty0_dist) %>%
    lInf_and_l2()
counties$pm_ppty0_e %>%
    matched.distances(ppty0_pse_dist) %>%
    lInf_and_l2()

##' Full matching on ppty0 within calipers
##' on `ppty0`, on corresponding pair-specific sglm0 SE's,
##' and logpop. 
counties$fm_ppty0_e <- fullmatch(ppty0_dist_twocaliper, data=counties) 
##' Info about this match:
summary(counties$fm_ppty0_e)
##' Treatment group members matched only to a single control:
##+
counties |> filter(stateFIPS==25, fm_ppty0_e%in%c("1.11", "1.3", "1.9")) |> left_join(mass_counties, by=c("stateFIPS", "cntyFIPS")) |> select(ppty0, cnty_name, cnty_abbrev)
##' (Middlesex and Norfolk contain Boston suburbs, Cambridge in
##' Middlesex and Quincy/Braintree/Brookline in Norfolk.) 
##' stock match quality info
counties$fm_ppty0_e %>%
    matched.distances(ppty0_dist) %>%
    unlist() %>% lInf_and_l2()
counties$fm_ppty0_e %>%
    matched.distances(ppty0_pse_dist) %>%
    unlist() %>% lInf_and_l2()
covariates_SLB %>% 
    paste(collapse="+") %>%
    paste("mass_cnty ~", ., "-1+strata(pm_ppty0)+strata(pm_ppty0_e)+strata(fm_ppty0_e)") %>%
    as.formula() %>%
    balanceTest(counties, unit.weights=a20_64_cnt)|>
                print(which.stats=c("Treatment", "Control"))
##' (Covariate-level imbalances are made better or worse, depending on the covariate.  The p-value increases, but this is plausibly a function of the decrease in effective sample size.)
##' 
##' # Wrapup
##' Store generated artifacts for use elsewhere
##+ eval=regenerate_stratifications
stratifications  <- counties %>%
    dplyr::select(stateFIPS, cntyFIPS, mass_cnty, a20_64_cnt,
           ppty0, ppty1, ppty2,
           ps0_trim, ps0_strat2,
           ps2_trim, ps2_strat2,
           pm_ppty0, pm_ppty2,
           pm_ppty0_e, fm_ppty0_e)
save(sglm0, pie_sglm0,
     sglm2, pie_sglm2,
     stratifications,  file="SLB_PS_variants.RData")
##' 
##' # Ancillary explorations
##' ## Full matching not pair matching
##'
##' Optimal full matching on each score, excluding counties as necessary to 
##' ensure close matching everywhere. 
##+

fullmatch(ppty0_dist + caliper(ppty0_dist, width=0.25 * s_p_sglm0),
          data=counties, 
          ) -> counties$fm_ppty0
fullmatch(ppty2_dist + caliper(ppty2_dist, width=0.25 * s_p_sglm2), 
          data=counties, 
          ) -> counties$fm_ppty2
##'
##' Excludes treatment group counties?
##+
summary(counties$fm_ppty0)
summary(counties$fm_ppty2)
##' Considering `fm_ppty2` a bit further:
##+
counties$fm_ppty2 %>% matched.distances(ppty2_dist) %>%
    unlist() %>% lInf_and_l2()
##' How close a caliper is possible without dropping treatment group members? It depends
##' on which score of course. The answer for `sglm0`:
##+
( ppty0_dist_summ  <- summary(ppty0_dist) )
ppty0_dist_summ$distances['Max.']/s_p_sglm0
ppty0_dist %>% match_on(caliper= 0.05 * s_p_sglm0) %>%
    fullmatch( data=counties ) %>% summary()
ppty0_dist %>% match_on(caliper= 0.06 * s_p_sglm0) %>%
    fullmatch( data=counties ) %>% summary()
ppty0_dist %>% match_on(caliper= 0.06 * s_p_sglm0) %>%
    fullmatch( data=counties ) -> counties$fm_ppty0  
##'
##' Answer for `sglm2`:
##+
( ppty2_dist_summ  <- summary(ppty2_dist) )
ppty2_dist_summ$distances['Max.']/s_p_sglm2
ppty2_dist %>% match_on(caliper= 0.10 * s_p_sglm2) %>%
    fullmatch( data=counties ) %>% summary()
ppty2_dist %>% match_on(caliper= 0.11 * s_p_sglm2) %>%
    fullmatch( data=counties ) %>% summary()
ppty2_dist %>% match_on(caliper= 0.11 * s_p_sglm2) %>%
    fullmatch( data=counties ) -> counties$fm_ppty2  
##'
##' Full matching within calipers included relatively
##' little of the control group (see ancillary explorations
##' below), obviating its advantage over pairs.
##'
##'
##' ## Mahalanobis matching to address poor matches on `ppty0`/`ppty2` when calipering on `ppty2`/`ppty0`.
##'
##' Let's look at pair matching
##' on a Mahalanobis distance, within propensity calipers.
##+
mh0_dist  <- 
    match_on(formula(sglm0),
             data=base_cnty
             ) 
counties$pm_mh0  <-
    pairmatch(mh0_dist +
              caliper(ppty0_dist, width=.2*s_p_sglm0),
              data=counties)
counties$pm_mh0 %>% matched.distances(ppty0_dist) %>%
    unlist() %>% lInf_and_l2()
counties$pm_mh0 %>% matched.distances(ppty2_dist) %>%
    unlist() %>% lInf_and_l2()
##' The caliper on `ppty0` now gets you closer on `ppty2`
##' than it did without Mahalanobis matching, but it's still
##' not super close.
##' 
