##' ---
##' output:
##'     html_document: 
##'         keep_md: true
##'     md_document:
##'         variant: gfm
##' ---
##' # Setup
##' 
##+ setup, echo=FALSE, warning=FALSE, message=FALSE
knitr::opts_chunk$set(warning=FALSE, message=FALSE, error=FALSE, echo=TRUE)
libloc <- file.path("..", "..", ".local", 
                    R.Version()$platform, 
                    paste(R.Version()$major,
                          strsplit(R.Version()$minor, ".", 
                                   fixed=T)[[1]][1],
                          sep=".")
                    )
unloadNamespace("optmatch")
unloadNamespace("RItools")
library("RItools", lib.loc=libloc)
withr::with_libpaths(libloc, library("PISE"),
                     action="prefix")
library(optmatch)
stopifnot(packageVersion("RItools") >= '0.2.0.9004',
          packageVersion("PISE") >= '0.1.0.9005')
library(survey)
library(tidyverse)

##' Repetitions of simulation, when `pic_maxerr()` is applied to a factor
##+ simsetup
if (!exists('nreps')) nreps <-100
nreps

## The county data excluding year-specific mortality rates. 
##+ datasetup, cache=TRUE
counties <- read_csv(file.path("..", "extdata", "base_cnty0.csv")) %>%
    mutate(mass_cnty = (stateFIPS == "25")) %>%
    mutate_at(c("adjcnt_White_M", "adjcnt_White_F", "adjcnt_Black_M", "adjcnt_Black_F", "adjcnt_other_M", "adjcnt_other_F"), ~ 100 * .x / adjcnt_a20_64)
##' Artifacts from script `SLB_PS_mod_variants.R`, some based on
##' restricted-use data resources.
##+ 
(load("SLB_PS_variants.RData"))
stopifnot(all.equal(counties$stateFIPS, stratifications$stateFIPS),
          all.equal(counties$cntyFIPS, stratifications$cntyFIPS)
          )
##'
##' Names of MA counties, per
##' https://en.wikipedia.org/wiki/List_of_counties_in_Massachusetts
##+
mass_counties  <-
    readr::read_tsv("../extdata/mass_cnty_fips.tsv",
                    col_types="ccc")
##' My abbreviations of MA county names
##+
mass_counties %>%
    mutate(cnty_abbrev=abbreviate(cnty_name, 2, method="both.sides")
           ) -> mass_counties
##' 
##' # Propensity scores
##' 
##' ## SLB propensity score
##' 
##' One private resource that we've loaded in is a near-reproduction of the
##' SLB propensity score, `sglm0`.  The only difference, I think, has to do with the
##' origin of the `latino` variable: they took theirs from the AHRF, but the
##' more recent AHRF I was able to obtain didn't carry that variable in these 
##' years, so instead I took it from the county-level population data that NCHS
##' maintains alongside of the mortality data. 
##+ 
counties$ppty0 <- sglm0$linear.predictors
##' The PIC SE value of this score is:
##+ eval=TRUE
pie_sglm0
##' The pooled s.d. of this score, calculated with weighting for county size:
##+
counties %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
  PISE:::standardization_scale(counties$ppty0, counties$mass_cnty, 
                               PISE:::svy_sd, .) -> s_p_sglm0 
s_p_sglm0
##' quite a bit smaller than the PIC SE.  It reflects within-group
##' propensity dispersion as follows.
##' Ranges and medians of both groups:
counties %>% group_by(mass_cnty) %>%
    dplyr::select(ppty0) %>%
        summarise(min=min(ppty0), med=median(ppty0), max=max(ppty0))
##' Treatment group mean and s.d. (weighted):
counties %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    subset(!!mass_cnty) %>% survey::svymean(~ppty0, .) %>% 
  .[["ppty0"]]
counties %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    subset(!!mass_cnty) %>% survey::svyvar(~ppty0, .) %>% 
  .[["ppty0"]] %>% sqrt()

##' Comparison reservoir mean and s.d. (weighted):
counties %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    subset(!mass_cnty) %>% survey::svymean(~ppty0, .) %>% 
  .[["ppty0"]]
counties %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    subset(!mass_cnty) %>% survey::svyvar(~ppty0, .) %>% 
  .[["ppty0"]] %>% sqrt()
##' Unweighted root-mean square of paired PS differences:
with(counties, c(max_err=diff(range(ppty0)) , rms_err=sqrt(2*var(ppty0)))
)
##' 
##' ... or, as a multiple of the pooled s.d., 
with(counties, sqrt(2*var(ppty0))/s_p_sglm0)
##'  RMS and max of paired index error, simulated
##+ pie_ps0__sglm0, cache=TRUE
( pie_ps0__sglm0  <-
      pic_maxerr(character(nrow(counties)), x=pie_sglm0, nreps=nreps) )
##'
##' ### SLB propensity score subsetting
##' 
##' Per SLB,
##' 
##' > we used propensity scores to define a control group of counties
##' > in nonreform states that were most similar to prereform
##' > Massachusetts counties. We estimated propensity scores...
##' > The quartile of counties with the highest propensity scores,
##' > indicating the closest match to the overall population of
##' > Massachusetts's 14 counties, was used as the control group
##' > in the mortality analysis.
##'
##' I take this to mean the following.
counties %>% dplyr::filter(mass_cnty==0) %>% 
    survey::svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    survey::svyquantile(~ppty0,.,quantiles=0.75) %>%
    .[[1]] %>% .[1] -> 
    cutoff 
##' `ps0_trim` combines treatment counties with controls
##' falling above the cutoff.
counties$ps0_trim  <- stratifications$ps0_trim
##' RMS and max of paired index error, simulated
##+ pie_ps0_trim_sglm0, cache=TRUE
( pie_ps0_trim_sglm0  <-
      pic_maxerr(counties$ps0_trim, x=pie_sglm0, nreps=nreps) )

##' 
##' ### Balance check for SLB trim, and associated subclassifications
##'
##' The subclassifications:
##+ echo=-(1:7)
counties %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    svyquantile(~ppty0+log10(a20_64_cnt), ., c(.0005, .9995)) ->
    qtiles0
if (is(qtiles0, "newsvyquantile"))
    qtiles0 <-
        sapply(qtiles0, function(x) x[,1, drop=TRUE], simplify=FALSE) %>%
        do.call(rbind, .) 
counties %>% #dplyr::filter(mass_cnty==0) %>% 
    survey::svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
        survey::svyquantile(~ppty0, ., quantiles=.5) %>%
        .[[1]] %>% .[1] -> ppty0_median
counties %>% #dplyr::filter(mass_cnty==0) %>% 
    survey::svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
        survey::svyquantile(~log10(a20_64_cnt), ., quantiles=.42) %>%
        .[[1]] %>% .[1] -> logpop_median
counties %>% #dplyr::filter(mass_cnty==0) %>% 
    survey::svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
        survey::svyquantile(~log10(a20_64_cnt), ., quantiles=.1) %>%
        .[[1]] %>% .[1] -> logpop_1stdecile
counties %>% filter(mass_cnty) %>%
    transmute(ppty0, logpop=log10(a20_64_cnt)) %>%
    sapply(range) %>% t() ->
    mass_range0
colnames(mass_range0)  <- c("min", "max")
counties$ps0_strat0  <- cut(counties$ppty0,
                            c(ppty0_median-pie_sglm0$max_err,
                              ppty0_median,
                              ppty0_median+pie_sglm0$max_err),
                            include.lowest=T)
counties$ps0_strat1  <- cut(log10(counties$a20_64_cnt),
                            c(0, logpop_1stdecile, 10)
                            ) %>% factor(labels=c("tiny", "_")) %>%
    interaction(counties$ps0_strat0, .)
with(counties, table(mass_cnty, ps0_strat1))

counties$ps0_strat2  <- cut(log10(counties$a20_64_cnt),
                            c(0, logpop_median, logpop_1stdecile, 10)
                            ) %>% factor(labels=c("sm", "med", "lg")) %>%
    interaction(counties$ps0_strat0, .)
with(counties, table(mass_cnty, ps0_strat2))
##' For each subclassification, identify subclasses that are "concordant", i.e. either
##' have no treatment group members or no controls; then set their subclass status to NA
##' (to encode leaving these observations out of the analysis).
##+ echo=2:4
concordant_to_NA  <- function(fac_nm) {
    stopifnot(any(fac_nm==colnames(counties)),
              is.factor(counties[[fac_nm]]),
              any('mass_cnty'==colnames(counties)
                  )
              )
    actives  <- tapply(counties$mass_cnty,
                       counties[[fac_nm]],
                       var) > 0
    actives  <- levels(counties[[fac_nm]])[actives]
    factor(counties[[fac_nm]], levels=actives)
    }
counties["ps0_strat0"]  <- concordant_to_NA("ps0_strat0")
counties["ps0_strat1"]  <- concordant_to_NA("ps0_strat1")
counties["ps0_strat2"]  <- concordant_to_NA("ps0_strat2")
stopifnot(all.equal(counties$ps0_strat2, stratifications$ps0_strat2))
##' 
##' The balance check.  
covariates_SLB <-
    c("a20_34", "a35_44", "a45_54", "a55_64",
      "male", "white_race", "black_race", "other_race", "latino",
      "pov", "inc", "unemp", "unins", "mortAC_20_64")
covariates_SLB %>% 
    paste(collapse="+") %>% paste("mass_cnty ~", ., "-1+strata(ps0_trim)+strata(ps0_strat0)+strata(ps0_strat1)+strata(ps0_strat2)") %>%
    as.formula() %>%
    balanceTest(counties, unit.weights=a20_64_cnt) |>
                print(which.stats=c("Treatment", "Control"))
##' Differences of means as they appear here are consistent with what SLB
##' had reported, and are relatively small. Nonetheless, balance as the
##' *hypothesis* of indistinguishable propensity scores is squarely rejected. 
##'
##' The overall test results are to be interpreted in light of that test's
##' also paying indirect attention to county population size, which is out
##' of balance. 
##' 
##+
counties %>% dplyr::filter(!is.na(ps0_trim)) %>% 
  group_by(mass_cnty) %>% summarise(mean(a20_64_cnt))
##' But as we've seen, paying basic attention to size helps but doesn't
##' fix the balance problem. Accordingly we'll consider some variations
##' on their propensity model as well.  But first, bring one more
##' factor into the stratification.
##'
##' ### sglm0 stratifications with PC1 of dilated cov matrix
##'
##' The dilated cov matrix being $X \tilde{C}^{1/2}$, where
##' $\tilde{C}^{1/2}$ is a Cholesky factor of $\hat{C}_{\hat\beta}$.
##'
##+
pie_sglm0$chol_cov_beta  <- chol(pie_sglm0$cov.betahat, pivot=TRUE)
pie_sglm0$chol_cov_beta  <-
    pie_sglm0$chol_cov_beta[,order(attr(pie_sglm0$chol_cov_beta, "pivot"))]
pie_sglm0$svd_dilated_X  <- with(pie_sglm0, svd(tcrossprod(X, chol_cov_beta)))
counties$ps0_pc1  <- pie_sglm0$svd_dilated_X$u[,1]
##'
##' New subclassifications:
##'
##' - 3_t is built on ps0_trim
##' - 3_0 is built on ps0_strat0 (trim + 2 ps subclasses)
##' - 3_2 is built on ps0_strat2 (ps0_strat0 crossed w/ 3 size levels)
##+ ps0_pc1_strat_, cache=TRUE
mass_range0  <- counties %>%
    filter(mass_cnty) %>%
    with(range(ps0_pc1)) %>%
    rbind(mass_range0, ps0_pc1=.)
ps0_pc1_cutpoints  <-
    seq(from=mass_range0["ps0_pc1", "min"]-0.0015,
            to=mass_range0["ps0_pc1", "max"]+0.0015,
            length.out=4)
counties$ps0_pc1_strat_  <-
    cut(counties$ps0_pc1,
       ps0_pc1_cutpoints,
       include.lowest=TRUE)
counties$ps0_strat3_t  <-  
    interaction(counties$ps0_trim, counties$ps0_pc1_strat_ )
counties$ps0_strat3_0  <-  
    interaction(counties$ps0_strat0, counties$ps0_pc1_strat_ )
counties$ps0_strat3_2  <-  
    interaction(counties$ps0_strat2, counties$ps0_pc1_strat_ )
##' 
#+ pc1_by_ppty0_scatter, echo=FALSE, results="hide"

tmp  <- counties %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    svyquantile(~ps0_pc1, ., c(.0005, .9995)) 

if (is(tmp, "newsvyquantile")) tmp <- tmp[["ps0_pc1"]][,1L]
    
qtiles0 <- rbind(qtiles0, ps0_pc1=tmp)
plot(log10(a20_64_cnt) ~ ppty0, type="n",
     xlim=c(min(qtiles0["ppty0",1], mass_range0["ppty0",1]),
            max(qtiles0["ppty0",2], mass_range0["ppty0",2]+pie_sglm0$rms_err)
            ),
     ylim=c(min(qtiles0["ps0_pc1", 1], mass_range0["ps0_pc1", 1]),
            max(qtiles0["ps0_pc1", 2], mass_range0["ps0_pc1", 2])
            ),
     data=counties,
     main="US Counties", xlab="SLB's propensity (ppty0)",  ylab="PC1 of dilated covars")
counties %>% filter(stateFIPS!=25, ppty0>=cutoff) %>%
    with(points(ppty0, ps0_pc1, pty=2, col="red", cex=0.1))
counties %>% filter(stateFIPS!=25, ppty0<cutoff) %>%
    with(points(ppty0, ps0_pc1, pty=2, col="lightgray", cex=0.1))
counties %>% filter(stateFIPS==25) %>%
    left_join(mass_counties, by=c("stateFIPS", "cntyFIPS")) %>% 
    with(text(ppty0, ps0_pc1,
              labels=cnty_abbrev, adj=0.5, cex=0.75, col="blue")
         )
legend("topleft", with(mass_counties, paste(cnty_abbrev, cnty_name)),
       text.col="blue", cex=0.5, 
       bty="o", box.col="lightgray",
       inset=0.05, title.col="blue", title=expression(underline("Massachusetts"))
       )
lapply(ps0_pc1_cutpoints,
       function(p) segments(y0=p,
                            x0=mass_range0["ppty0", "min"],
                            x1=qtiles0["ppty0", 2],
                            col="lightgray")
       )
###segments(x0=ppty0_median,
###       y0=min(ps0_pc1_cutpoints), y1=max(ps0_pc1_cutpoints), col="lightgray")
###segments(x0=(ppty0_median-pie_sglm0$max_err),
###       y0=min(ps0_pc1_cutpoints), y1=max(ps0_pc1_cutpoints), col="lightgray")
###segments(x0=(ppty0_median+pie_sglm0$max_err),
###       y0=min(ps0_pc1_cutpoints), y1=max(ps0_pc1_cutpoints), col="lightgray")

##'
##'  RMS and max index errors for these stratifications.
##+ cache=TRUE, dependson=c("ps0_pc1_strat_")
( pie_ps0_strat3_t_sglm0  <-
      pic_maxerr(counties$ps0_strat3_t, x=pie_sglm0, nreps=nreps) )
( pie_ps0_strat3_0_sglm0  <-
      pic_maxerr(counties$ps0_strat3_0, x=pie_sglm0, nreps=nreps) )
( pie_ps0_strat3_2_sglm0  <-
      pic_maxerr(counties$ps0_strat3_2, x=pie_sglm0, nreps=nreps) )
##' For comparison purposes, RMS and max index errors for the
##' stratification those were built upon.
##+ cache=TRUE, dependson=c("pie_ps0_trim_sglm0")
pie_ps0_trim_sglm0
( pie_ps0_strat0_sglm0 <-
      pic_maxerr(counties$ps0_strat0, x=pie_sglm0, nreps=nreps) )
( pie_ps0_strat2_sglm0 <-
      pic_maxerr(counties$ps0_strat2, x=pie_sglm0, nreps=nreps) )
##'
##' Balance for the new stratifications
##+
covariates_SLB %>% 
    paste(collapse="+") %>%
    paste("mass_cnty ~", .,
          "-1+strata(ps0_trim)+strata(ps0_strat3_t)+strata(ps0_strat3_0)+strata(ps0_strat3_2)"
          ) %>%
    as.formula() %>%
    balanceTest(counties, unit.weights=a20_64_cnt) |>
                print(which.stats=c("Treatment", "Control"))

##' 
##' # Propensity score pair matches
##'
##' Convenience function
##+
lInf_and_l2 <- function(x) c(`lInf`=max(abs(x)), `l2`=sqrt(mean(x^2)))
##' ## Matching on a single index
##'
##' `pm_ppty0` is a pair match on the following distance.
ppty0_dist  <- 
    match_on(counties$ppty0, z=counties$mass_cnty,
             data=counties)
counties$pm_ppty0  <- stratifications$pm_ppty0
counties$pm_ppty0 %>% matched.distances(ppty0_dist) %>% unlist() %>% 
  lInf_and_l2()
##' To interpret, recall that
##+ 
s_p_sglm0 ; pie_sglm0
##'
##+
( pie_pm_ppty0  <- pic_maxerr(counties$pm_ppty0, x=pie_sglm0, nreps=nreps) )
##' ## Matching on index plus paired index SE
##'
##' Pair match on ppty0, within calipers of
##' a PIC SE enhanced ppty0 distance, and also
##' ± 1 in log base 10 of population.
counties$pm_ppty0_e  <- stratifications$pm_ppty0_e
counties$pm_ppty0_e %>%
    matched.distances(ppty0_dist) %>%
    lInf_and_l2()
( pie_pm_ppty0_e  <- pic_maxerr(counties$pm_ppty0_e, x=pie_sglm0, nreps=nreps) )

##' Full matching on ppty0 within calipers
##' on `ppty0`, on corresponding pair-specific sglm0 SE's,
##' and logpop. 
counties$fm_ppty0_e <- stratifications$fm_ppty0_e
##' Info about this match (NB: lInf and l2 are understated, 
##' only consider T-C pairs):
summary(counties$fm_ppty0_e)
counties$fm_ppty0_e %>%
    matched.distances(ppty0_dist) %>% unlist() %>%
    lInf_and_l2()
( pie_fm_ppty0_e  <- pic_maxerr(counties$fm_ppty0_e, x=pie_sglm0, nreps=nreps) )
##' Balance:
covariates_SLB %>% 
    paste(collapse="+") %>%
    paste("mass_cnty ~", ., "-1+strata(pm_ppty0_e)+strata(fm_ppty0_e)") %>%
    as.formula() %>%
    balanceTest(counties, unit.weights=a20_64_cnt) |>
                print(which.stats=c("Treatment", "Control"))
##' (Covariate-level imbalances are made better or worse, depending on the covariate.  The p-value increases, but this is plausibly a function of the decrease in effective sample size.)
##' 
##' # Wrapup
##' Store generated artifacts for use elsewhere
##+ eval=TRUE
stratifications  <- counties %>%
    dplyr::select(stateFIPS, cntyFIPS, mass_cnty, a20_64_cnt,
           ppty0, 
           ps0_trim, ps0_strat2,
           ps0_strat3_t,
           ps0_strat3_0,
           ps0_strat3_2,
           pm_ppty0, 
           pm_ppty0_e, fm_ppty0_e)
save(sglm0, pie_sglm0,
     pie_ps0_strat3_t_sglm0,
     pie_ps0_strat3_0_sglm0,
     pie_ps0_strat3_2_sglm0,
     stratifications,  file="SLB_PS_repro+pc1.RData")
##'
##+
sessionInfo()
##' 
##' # Ancillary explorations
##' ## Full matching not pair matching
##'
##' Optimal full matching, excluding counties as necessary to 
##' ensure close matching everywhere. 
##+

fullmatch(ppty0_dist + caliper(ppty0_dist, width=0.25 * s_p_sglm0),
          data=counties, 
          ) -> counties$fm_ppty0
##'
##' Excludes treatment group counties?
##+
summary(counties$fm_ppty0)
##' How close a caliper is possible without dropping treatment group members? It depends
##' on which score of course. The answer for `sglm0`:
##+
( ppty0_dist_summ  <- summary(ppty0_dist) )
ppty0_dist_summ$distances['Max.']/s_p_sglm0
ppty0_dist %>% match_on(caliper= 0.05 * s_p_sglm0) %>%
    fullmatch( data=counties ) %>% summary()
ppty0_dist %>% match_on(caliper= 0.06 * s_p_sglm0) %>%
    fullmatch( data=counties ) %>% summary()
ppty0_dist %>% match_on(caliper= 0.06 * s_p_sglm0) %>%
    fullmatch( data=counties ) -> counties$fm_ppty0  
