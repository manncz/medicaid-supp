---
output:
    html_document: 
        keep_md: true
    md_document:
        variant: gfm
---
# Setup




```r
counties <- read_csv(file.path("..", "extdata", "base_cnty0.csv")) %>%
    mutate(mass_cnty = (stateFIPS == "25")) %>%
    mutate_at(c("adjcnt_White_M", "adjcnt_White_F", "adjcnt_Black_M", "adjcnt_Black_F", "adjcnt_other_M", "adjcnt_other_F"), ~ 100 * .x / adjcnt_a20_64)
```

Private resources: county data w/ year specific mortality.


```r
base_cnty <- read_csv(file.path("..", "extdata", "base_cnty.csv")) %>%
    mutate(mass_cnty = (stateFIPS == "25"),
           a20_44=a20_34+a35_44,
           a45_64=a45_54+a55_64) %>%
    mutate_at(c("adjcnt_White_M", "adjcnt_White_F", "adjcnt_Black_M", "adjcnt_Black_F", "adjcnt_other_M", "adjcnt_other_F"), ~ 100 * .x / adjcnt_a20_64) %>%
    mutate(mortAC01_03=mortAC2001+mortAC2002+mortAC2003,
           mortAC04_06=mortAC2004+mortAC2005+mortAC2006,
           mortAC02_04=mortAC2002+mortAC2003+mortAC2004,
           mortAC03_05=mortAC2003+mortAC2004+mortAC2005,
           mortAC01_02=mortAC2001+mortAC2002,
           mortAC03_04=mortAC2003+mortAC2004,
           mortAC05_06=mortAC2005+mortAC2006)
base_cnty_svydesign  <-
    survey::svydesign(id=~1, weights=~a20_64_cnt, data=base_cnty)
```


Names of MA counties, per
https://en.wikipedia.org/wiki/List_of_counties_in_Massachusetts


```r
mass_counties  <-
    readr::read_tsv("../extdata/mass_cnty_fips.tsv",
                    col_types="ccc")
```

My abbreviations of MA county names


```r
mass_counties %>%
    mutate(cnty_abbrev=abbreviate(cnty_name, 2, method="both.sides")
           ) -> mass_counties
```


# Propensity scores

## SLB propensity score

One private resource that we've loaded in is a near-reproduction of the
SLB propensity score.  The only difference, I think, has to do with the
origin of the `latino` variable: they took theirs from the AHRF, but the
more recent AHRF I was able to obtain didn't carry that variable in these 
years, so instead I took it from the county-level population data that NCHS
maintains alongside of the mortality data. 


```r
sglm0  <-
    survey::svyglm(mass_cnty~a20_34+a35_44+a45_54+a55_64+
                       male+white_race+black_race+other_race+latino+
                       pov+inc+unemp+unins+
                       mortAC2001+mortAC2002+mortAC2003+
                       mortAC2004+mortAC2005+mortAC2006,
                   design=base_cnty_svydesign, data=base_cnty,
                   model=TRUE, # FALSE caused svyglm to choke
                   family=quasibinomial)

counties$ppty0 <- sglm0$linear.predictors
```

The PIC SE value of this score is:


```r
(pie_sglm0 <- pic_maxerr(x=sglm0, 
                    covariance.estimator = "sandwich")
  )
```

```
## pic_me_info object (a list) with `c(max_err, rms_err)`= c(8.57, 3.32)
```

The pooled s.d. of this score, calculated with weighting for county size:


```r
counties %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
  PISE:::standardization_scale(counties$ppty0, counties$mass_cnty, 
                               PISE:::svy_sd, .) -> s_p_sglm0 
s_p_sglm0
```

```
## [1] 2.37
```

quite a bit smaller than the PIC SE.  It reflects within-group
propensity dispersion as follows.
Ranges and medians of both groups:


```r
counties %>% group_by(mass_cnty) %>%
    dplyr::select(ppty0) %>%
        summarise(min=min(ppty0), med=median(ppty0), max=max(ppty0))
```

```
## # A tibble: 2 × 4
##   mass_cnty   min   med   max
##   <lgl>     <dbl> <dbl> <dbl>
## 1 FALSE     -61.8 -8.84 7.62 
## 2 TRUE      -13.6 -2.09 0.908
```

Treatment group mean and s.d. (weighted):


```r
counties %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    subset(!!mass_cnty) %>% survey::svymean(~ppty0, .) %>% 
  .[["ppty0"]]
```

```
## [1] -1.66
```

```r
counties %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    subset(!!mass_cnty) %>% survey::svyvar(~ppty0, .) %>% 
  .[["ppty0"]] %>% sqrt()
```

```
## [1] 1.42
```

Comparison reservoir mean and s.d. (weighted):


```r
counties %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    subset(!mass_cnty) %>% survey::svymean(~ppty0, .) %>% 
  .[["ppty0"]]
```

```
## [1] -7.76
```

```r
counties %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    subset(!mass_cnty) %>% survey::svyvar(~ppty0, .) %>% 
  .[["ppty0"]] %>% sqrt()
```

```
## [1] 4.4
```

Unweighted root-mean square of paired PS differences:


```r
with(counties, sqrt(2*var(ppty0)))
```

```
## [1] 9.96
```

... or, as a multiple of the pooled s.d., 


```r
with(counties, sqrt(2*var(ppty0))/s_p_sglm0)
```

```
## [1] 4.21
```


### SLB propensity score subsetting

Per SLB,

> we used propensity scores to define a control group of counties
> in nonreform states that were most similar to prereform
> Massachusetts counties. We estimated propensity scores...
> The quartile of counties with the highest propensity scores,
> indicating the closest match to the overall population of
> Massachusetts's 14 counties, was used as the control group
> in the mortality analysis.

I take this to mean the following.  


```r
counties %>% dplyr::filter(mass_cnty==0) %>% 
    survey::svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    survey::svyquantile(~ppty0,.,quantiles=0.75) %>%
    .[[1]] %>% .[1] -> 
    cutoff 
counties <- mutate(counties, 
                   ps0_trim = mass_cnty | (!mass_cnty & ppty0 >= cutoff)
                   ) %>% mutate(ps0_trim=factor(ifelse(ps0_trim, 'in', NA)))
```


Whereas SLB wound up with 513 controls for MA's 14 counties, this
yields:



```r
counties %>% dplyr::filter(!is.na(ps0_trim)) %>% with(table(mass_cnty))
```

```
## mass_cnty
## FALSE  TRUE 
##   512    14
```

```r
optmatch::effectiveSampleSize(counties$ps0_trim, counties$mass_cnty)
```

```
## [1] 27.3
```

Trimmed comparison reservoir mean and s.d. (weighted):


```r
counties %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    subset(!mass_cnty&!is.na(ps0_trim)) %>% 
    survey::svymean(~ppty0, .) %>% 
    .[["ppty0"]] 
```

```
## [1] -3.25
```

```r
counties %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    subset(!mass_cnty&!is.na(ps0_trim)) %>% 
    survey::svyvar(~ppty0, .) %>% 
    .[["ppty0"]] %>% sqrt()
```

```
## [1] 1.16
```

Unweighted root mean square of paired PS differences:


```r
counties %>% dplyr::filter(!is.na(ps0_trim)) %>%
    with(sqrt(2*var(ppty0)))
```

```
## [1] 2.2
```

... and as a multiple of the pooled s.d., 


```r
counties %>% dplyr::filter(!is.na(ps0_trim)) %>%
    with(sqrt(2*var(ppty0))/s_p_sglm0)
```

```
## [1] 0.929
```


How did MA counties fall in relation to the cutoff?


```r
counties %>% dplyr::filter(!is.na(ps0_trim)) %>%
    with(table(mass_cnty, ppty0>=cutoff))
```

```
##          
## mass_cnty FALSE TRUE
##     FALSE     0  512
##     TRUE      2   12
```

```r
cutoff
```

```
## [1] -4.63
```


The two below-cutoff counties are Dukes County,
the combination of Martha's Vineyard & Naushon Island,
and Nantucket Island.  (Which are also left-outliers population-wise.)


```r
counties %>% dplyr::filter(mass_cnty, ppty0<cutoff) %>%
    dplyr::select(ppty0, a20_64_cnt)
```

```
## # A tibble: 2 × 2
##   ppty0 a20_64_cnt
##   <dbl>      <dbl>
## 1 -11.2      9774.
## 2 -13.6      6498.
```

```r
counties %>% dplyr::filter(ppty0>=cutoff) %>%
    group_by(mass_cnty) %>% 
    dplyr::select(ppty0, a20_64_cnt) %>%
        summarise_all(range)
```

```
## # A tibble: 4 × 3
## # Groups:   mass_cnty [2]
##   mass_cnty  ppty0 a20_64_cnt
##   <lgl>      <dbl>      <dbl>
## 1 FALSE     -4.63        82.8
## 2 FALSE      7.62   1479186. 
## 3 TRUE      -3.97     44144. 
## 4 TRUE       0.908   911249.
```


Scatter of log population by `ppty0` and log pop, excluding upper and lower .05%
on either variable. (In terms of both propensity score and population, MA counties
fall within the middle 99.9%. The scatterplot's easier to read if 
you trim the lower and upper twentieth of a percent.)  

![](SLB_PS_variants_files/figure-html/pop_by_ppty0_scatter0-1.png)<!-- -->


Again with more structure on the plot. The horizontal lines are at
the first decile and at the 42nd percentile of logged population, the
42nd percentile being chosen because it was close to the median and
close to half way between two groups of blue (MA) counties.  The vertical
lines are at the median propensity score and ± `sqrt(2*log(2*min(n_t, n_c)))`
PIC SE's above and below that median.


```r
pop_by_ppty0_scatter()
abline(h=logpop_median, col="lightgray")
abline(h=logpop_1stdecile, col="lightgray")
abline(v=ppty0_median, col="lightgray")
abline(v=(ppty0_median-pie_sglm0$max_err), col="lightgray")
abline(v=(ppty0_median+pie_sglm0$max_err), col="lightgray")
```

![](SLB_PS_variants_files/figure-html/pop_by_ppty0_scatter2-1.png)<!-- -->


### Subclassifications based on SLB PS


```r
counties %>% #dplyr::filter(mass_cnty==0) %>% 
    survey::svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
        survey::svyquantile(~ppty0, ., quantiles=.5) %>%
        .[[1]] %>% .[1] -> ppty0_median
counties %>% #dplyr::filter(mass_cnty==0) %>% 
    survey::svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
        survey::svyquantile(~log10(a20_64_cnt), ., quantiles=.42) %>%
        .[[1]] %>% .[1] -> logpop_median
counties %>% #dplyr::filter(mass_cnty==0) %>% 
    survey::svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
        survey::svyquantile(~log10(a20_64_cnt), ., quantiles=.1) %>%
        .[[1]] %>% .[1] -> logpop_1stdecile

counties$ps0_strat0  <- cut(counties$ppty0,
                            c(ppty0_median-pie_sglm0$max_err,
                              ppty0_median,
                              ppty0_median+pie_sglm0$max_err),
                            include.lowest=T)
counties$ps0_strat1  <- cut(log10(counties$a20_64_cnt),
                            c(0, logpop_1stdecile, 10)
                            ) %>% factor(labels=c("tiny", "_")) %>%
    interaction(counties$ps0_strat0, .)
with(counties, table(mass_cnty, ps0_strat1))
```

```
##          ps0_strat1
## mass_cnty [-15.7,-7.15].tiny (-7.15,1.41].tiny [-15.7,-7.15]._ (-7.15,1.41]._
##     FALSE                983               539             523            605
##     TRUE                   2                 0               0             12
```

```r
counties$ps0_strat2  <- cut(log10(counties$a20_64_cnt),
                            c(0, logpop_median, logpop_1stdecile, 10)
                            ) %>% factor(labels=c("sm", "med", "lg")) %>%
    interaction(counties$ps0_strat0, .)
with(counties, table(mass_cnty, ps0_strat2))
```

```
##          ps0_strat2
## mass_cnty [-15.7,-7.15].sm (-7.15,1.41].sm [-15.7,-7.15].med (-7.15,1.41].med
##     FALSE              983             539               438              492
##     TRUE                 2               0                 0                4
##          ps0_strat2
## mass_cnty [-15.7,-7.15].lg (-7.15,1.41].lg
##     FALSE               85             113
##     TRUE                 0               8
```

For each subclassification, identify subclasses that are "concordant", i.e. either
have no treatment group members or no controls; then set their subclass status to NA
(to encode leaving these observations out of the analysis).


```r
counties["ps0_strat0"]  <- concordant_to_NA("ps0_strat0")
counties["ps0_strat1"]  <- concordant_to_NA("ps0_strat1")
counties["ps0_strat2"]  <- concordant_to_NA("ps0_strat2")
```



## Two new PS models

First a model replacing year-specific all-cause mortality with 3
year aggregates. (The aggregation should mean that the underlying
data sets can be more readily shared.) Then a stepwise-selected
model with access to these and other covariates.  

### Variant of SLM model using 3-year aggregated mortality



```r
sglm1  <-
    survey::svyglm(mass_cnty~a20_34+a35_44+a45_54+a55_64+
                       male+white_race+black_race+other_race+latino+
                       pov+inc+unemp+unins+
                       mortAC01_03+mortAC02_04+
                       mortAC03_05+mortAC04_06,
                   design=base_cnty_svydesign, data=base_cnty,
                   model=TRUE, # FALSE caused svyglm to choke
                   family=quasibinomial)
```




```r
counties$ppty1  <- sglm1$linear.predictors
counties %>% dplyr::filter(mass_cnty==0) %>% 
    survey::svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    survey::svyquantile(~ppty1,.,quantiles=.75) %>%
    .[[1]] %>% .[1]  -> cutoff1
cutoff1
```

```
## [1] -4.63
```

```r
counties %>% with(table(mass_cnty, ppty1> cutoff1))
```

```
##          
## mass_cnty FALSE TRUE
##     FALSE  2616  511
##     TRUE      2   12
```

```r
counties$ps1_trim  <- factor(ifelse(counties$ppty1>=cutoff1 |
                                     counties$mass_cnty,
                                     1, NA)
                              )
```

A standard deviation and a standard error for this score:


```r
counties %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
  PISE:::standardization_scale(counties$ppty1, counties$mass_cnty, 
                               PISE:::svy_sd, .) -> s_p_sglm1 
s_p_sglm1
```

```
## [1] 2.37
```

```r
pie_sglm1 <- pic_maxerr(x=sglm1, covariance.estimator = "sandwich")
pie_sglm1
```

```
## pic_me_info object (a list) with `c(max_err, rms_err)`= c(7.46, 2.89)
```

### Variant of SLM model selected via AIC

A variant trimming elsewhere than prior all-cause mortality,
using stepwise selection
guided by Lumley & Scott's (2015) adaptation of AIC.


```r
sglm2  <- MASS::stepAIC(sglm1, ~ . + mortAC2001 + mortAC2006 + a20_44 + a45_64, trace=F)
sglm2
```

```
## Independent Sampling design (with replacement)
## survey::svydesign(id = ~1, weights = ~a20_64_cnt, data = base_cnty)
## 
## Call:  svyglm(formula = mass_cnty ~ a45_54 + male + black_race + unins + 
##     mortAC02_04 + mortAC04_06, design = base_cnty_svydesign, 
##     family = quasibinomial, data = base_cnty, model = TRUE)
## 
## Coefficients:
## (Intercept)       a45_54         male   black_race        unins  mortAC02_04  
##    105.2467      -0.3953      -1.8345      -0.1761      -0.3906       0.0119  
## mortAC04_06  
##     -0.0138  
## 
## Degrees of Freedom: 3140 Total (i.e. Null);  3134 Residual
## Null Deviance:	    673 
## Residual Deviance: 417 	AIC: NA
```

```r
counties$ppty2  <- sglm2$linear.predictors
```

<!-- Temporary workaround, should I inadvertently break stepAIC again.
     Code suppressed from output. --> 



Sample trimming in the manner of SLB, but using the trimmed
propensity score model.


```r
counties %>% dplyr::filter(mass_cnty==0) %>% 
    survey::svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    survey::svyquantile(~ppty2,.,quantiles=.75) %>%
    .[[1]] %>% .[1]  -> cutoff2
counties$ps2_trim  <- factor(ifelse(counties$ppty2>=cutoff2 |
                                     counties$mass_cnty,
                                     1, NA)
                              )
```

A standard deviation and a standard error for this score:


```r
counties %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
  PISE:::standardization_scale(counties$ppty2, counties$mass_cnty, 
                               PISE:::svy_sd, .) -> s_p_sglm2 
s_p_sglm2
```

```
## [1] 2
```

```r
( pie_sglm2  <- pic_maxerr(x=sglm2, covariance.estimator = "sandwich") )
```

```
## pic_me_info object (a list) with `c(max_err, rms_err)`= c(4.62, 1.79)
```

```r
counties %>% dplyr::filter(mass_cnty, ppty2<cutoff2) %>%
    dplyr::select(stateFIPS, cntyFIPS, ppty2) %>%
  dplyr::mutate(sds_below=(cutoff2-ppty2)/s_p_sglm2,
                pic_ses_below=(cutoff2-ppty2)/pie_sglm2$rms_err
                )
```

```
## # A tibble: 2 × 5
##   stateFIPS cntyFIPS ppty2 sds_below pic_ses_below
##   <chr>     <chr>    <dbl>     <dbl>         <dbl>
## 1 25        007      -10.2      2.77          3.10
## 2 25        019      -12.4      3.87          4.33
```

Cut points for a subclassification on ppty2.


```r
mass_range2  <- counties %>% filter(mass_cnty) %>%
    transmute(ppty2, logpop=log10(a20_64_cnt)) %>%
    sapply(range) %>% t()

ppty2_cutpoints  <- seq(mass_range2["ppty2",1]-pie_sglm2$rms_err,
                        mass_range2["ppty2",2]+pie_sglm2$rms_err,
                        length=5)
```

The distance between consecutive cut points is
0.953 of the estimated max PIC error. 

Scatter of log population by `ppty2`, excluding upper and lower .05%
on either variable and showing the propensity subclassification cut
points.

![](SLB_PS_variants_files/figure-html/pop_by_ppty2_scatter-1.png)<!-- -->

### Balance after SLB-style trimming on the 3 scores in turn

Balance of samples trimmed in the manner of SLB, but using
each  of the three propensity score variants in turn. 


```r
covariates_SLB <-
    c("a20_34", "a35_44", "a45_54", "a55_64",
      "male", "white_race", "black_race", "other_race", "latino",
      "pov", "inc", "unemp", "unins", "mortAC_20_64")
covariates_SLB %>% 
    paste(collapse="+") %>%
    paste("mass_cnty ~", ., "-1+strata(ps0_trim)+strata(ps1_trim)+strata(ps2_trim)") %>%
    as.formula() %>%
    balanceTest(counties, unit.weights=a20_64_cnt) |>
                print(which.stats=c("adj.diff", "Treatment", "Control"))
```

```
##              strata():  ps0_trim                   ps1_trim                   ps2_trim                 
##              stat      Treatment Control adj.diff Treatment Control adj.diff Treatment Control adj.diff
## vars                                                                                                   
## a20_34                    33      33        0.066    33      33        0.065    33      33        0.416
## a35_44                    26      26        0.42     26      26        0.42     26      26        0.33 
## a45_54                    24      24       -0.30     24      24       -0.30     24      25       -0.48 
## a55_64                    16      17       -0.19     16      17       -0.18     16      17       -0.27 
## male                      49      49       -0.24     49      49       -0.24     49      49       -0.27 
## white_race                87      85        2.21     87      85        2.20     87      87        0.59 
## black_race                7.0     9.0      -2.01     7.0     9.0      -2.01     7.0     7.9      -0.98 
## other_race                5.6     5.8      -0.19     5.6     5.8      -0.19     5.6     5.2       0.39 
## latino                    7.3     7.5      -0.18     7.3     7.4      -0.17     7.3     6.7       0.52 
## pov                        9.6    10.3     -0.715     9.6    10.3     -0.716     9.6     9.7     -0.072
## inc                       63290   59317     3973     63290   59312     3978     63290   60715     2575 
## unemp                     5.0     5.1      -0.14     5.0     5.1      -0.14     5.0     4.7       0.23 
## unins                     14      14       -0.80     14      14       -0.80     14      14       -0.77 
## mortAC_20_64              283     299      -16       283     299      -16       283     298      -14   
## ---Overall Test---
##          chisquare df p.value
## ps0_trim        86 13 8.7e-13
## ps1_trim        86 13 8.7e-13
## ps2_trim        94 13 2.3e-14
```

Balance following sample trimming differs only slightly by
propensity score variant.

### AIC and other comparisons of the 3 PS models

Model comparisons, using the Lumley & Scott (2014, 2015)
adaptation of AIC.


```r
AIC(sglm0,sglm1, sglm2)
```

```
##      eff.p AIC deltabar
## [1,]  53.2 508     3.13
## [2,]  49.0 500     3.27
## [3,]  28.2 474     4.69
```

There is also the Rao-Scott (1984) adaptation of the LRT,
and a Lumley-Scott BIC variant as well. Their `survey`
implementations require symbolic nesting of models,
so we first fit (invisibly) a variant `sglm0b` that
should be equivalent up to numerical differences to `sglm0`,
but uses the 3-year mortality aggregate variables.


```r
anova(sglm0b, sglm1, method="LRT")
```

```
## Working (Rao-Scott+F) LRT for mortAC2001 mortAC2006
##  in svyglm(formula = mass_cnty ~ a20_34 + a35_44 + a45_54 + a55_64 + 
##     male + white_race + black_race + other_race + latino + pov + 
##     inc + unemp + unins + mortAC2001 + mortAC01_03 + mortAC02_04 + 
##     mortAC03_05 + mortAC04_06 + mortAC2006, design = base_cnty_svydesign, 
##     family = quasibinomial, data = base_cnty, model = TRUE)
## Working 2logLR =  0.00243 p= 1 
## (scale factors:  1.5 0.49 );  denominator df= 3123
```

```r
anova(sglm1, sglm2, method="LRT")
```

```
## Working (Rao-Scott+F) LRT for a20_34 a35_44 a55_64 white_race other_race latino pov inc unemp mortAC01_03 mortAC03_05
##  in svyglm(formula = mass_cnty ~ a20_34 + a35_44 + a45_54 + a55_64 + 
##     male + white_race + black_race + other_race + latino + pov + 
##     inc + unemp + unins + mortAC01_03 + mortAC02_04 + mortAC03_05 + 
##     mortAC04_06, design = base_cnty_svydesign, family = quasibinomial, 
##     data = base_cnty, model = TRUE)
## Working 2logLR =  6.76 p= 0.5 
## (scale factors:  4.7 1.8 0.72 0.47 0.45 0.33 0.21 0.19 0.14 );  denominator df= 3125
```

```r
BIC(sglm0b,sglm1, sglm2, maximal=sglm0b)
```

```
##       p BIC neff
## [1,] 18 547  NaN
## [2,] 16 532 1750
## [3,]  7 485 2915
```


## Subclassification on AIC-trimmed propensity score

A propensity score stratification with widths of
`sqrt(2*log(min(n_t, n_c))) * pie_sglm2$rms_err`, going one PIC SE
above and below the MA max and min.  Plus a variant of same the segregates v. small counties. 


```r
diff(ppty2_cutpoints)/pie_sglm2$rms_err
```

```
## [1] 2.46 2.46 2.46 2.46
```

```r
counties$ps2_strat0  <- cut(counties$ppty2,
                           ppty2_cutpoints,
                           include.lowest=T)
with(counties, table(mass_cnty, ps2_strat0))
```

```
##          ps2_strat0
## mass_cnty [-14.2,-9.76] (-9.76,-5.36] (-5.36,-0.958] (-0.958,3.44]
##     FALSE           688          1159            722            38
##     TRUE              2             0              9             3
```

```r
counties["ps2_strat0"]  <- concordant_to_NA("ps2_strat0")
cut(log10(counties$a20_64_cnt), c(0, logpop_1stdecile, 10), include.lowest=T) %>%
    factor(labels=c("tiny", "_")) %>%
    interaction(counties$ps2_strat0, .) -> counties$ps2_strat1
with(counties, table(mass_cnty, ps2_strat1))
```

```
##          ps2_strat1
## mass_cnty [-14.2,-9.76].tiny (-5.36,-0.958].tiny (-0.958,3.44].tiny
##     FALSE                485                 308                 20
##     TRUE                   2                   0                  0
##          ps2_strat1
## mass_cnty [-14.2,-9.76]._ (-5.36,-0.958]._ (-0.958,3.44]._
##     FALSE             203              414              18
##     TRUE                0                9               3
```

```r
counties["ps2_strat1"]  <- concordant_to_NA("ps2_strat1")
with(counties, table(mass_cnty, ps2_strat1))
```

```
##          ps2_strat1
## mass_cnty [-14.2,-9.76].tiny (-5.36,-0.958]._ (-0.958,3.44]._
##     FALSE                485              414              18
##     TRUE                   2                9               3
```

```r
cut(log10(counties$a20_64_cnt), c(0, logpop_median, logpop_1stdecile, 10), include.lowest=T) %>%
    factor(labels=c("sm", "med", "lg")) %>%
    interaction(counties$ps2_strat0, .) -> counties$ps2_strat2
counties["ps2_strat2"]  <- concordant_to_NA("ps2_strat2")
with(counties, table(mass_cnty, ps2_strat2))
```

```
##          ps2_strat2
## mass_cnty [-14.2,-9.76].sm (-5.36,-0.958].med (-0.958,3.44].med
##     FALSE              485                328                15
##     TRUE                 2                  3                 1
##          ps2_strat2
## mass_cnty (-5.36,-0.958].lg (-0.958,3.44].lg
##     FALSE                86                3
##     TRUE                  6                2
```

```r
with(counties, effectiveSampleSize(ps2_strat2, mass_cnty))
```

```
## [1] 25.4
```

corresp balance calcs


```r
covariates_SLB %>% 
    paste(collapse="+") %>%
    paste("mass_cnty ~", ., "-1+strata(ps2_trim)+strata(ps2_strat0)+strata(ps2_strat1)+strata(ps2_strat2)") %>%
    as.formula() %>%
    balanceTest(counties, unit.weights=a20_64_cnt) |>
                print(which.stats=c("Treatment", "Control"))
```

```
##              strata():  ps2_trim         ps2_strat0         ps2_strat1         ps2_strat2        
##              stat      Treatment Control  Treatment Control  Treatment Control  Treatment Control
## vars                                                                                             
## a20_34                     33      33         33      33         33      33         33      34   
## a35_44                     26      26         26      26         26      26         26      26   
## a45_54                     24      25         24      24         24      24         24      24   
## a55_64                     16      17         16      16         16      16         16      16   
## male                       49      49         49      49         49      49         49      49   
## white_race                 87      87         87      85         87      85         87      82   
## black_race                  7.0     7.9        7.0     9.6        7.0     8.9        7.0    11.1 
## other_race                 5.6     5.2        5.6     5.4        5.6     5.6        5.6     6.8  
## latino                     7.3     6.7        7.3     7.5        7.3     6.9        7.3     8.4  
## pov                         9.6     9.7        9.6    10.2        9.6     9.6        9.6     9.8 
## inc                        63290   60715      63290   60195      63290   62657      63290   63498
## unemp                      5.0     4.7        5.0     4.9        5.0     4.7        5.0     4.8  
## unins                      14      14         14      15         14      14         14      14   
## mortAC_20_64               283     298        283     303        283     289        283     287  
## ---Overall Test---
##            chisquare df p.value
## ps2_trim          94 13 2.3e-14
## ps2_strat0        87 13 4.7e-13
## ps2_strat1        58 13 1.2e-07
## ps2_strat2        21 13 6.8e-02
```

I.e., with `ps2_strat2` we at last escape rejection at 0.05 level. 

## Paired SE  distances within trimmed sample/subclasses

First within ppty0 trimmed sample and subclasses


```r
paired_se_sglm0  <- paired_se_dist(sglm0, covariance.estimator="sandwich")
paired_se_sglm0  <- paired_se_sglm0/pie_sglm0$rms_err
summary(as.numeric(paired_se_sglm0))
```

```
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
##    0.08    0.50    0.71    0.84    1.01    6.79
```

```r
(paired_se_sglm0 +
        exactMatch(mass_cnty ~ factor(ps0_trim, exclude=NULL), data=counties)
) %>% as.numeric() %>%
    floor() %>% table()
```

```
## .
##    0    1    2    3    5    6 
## 6556  561   35    2    5    9
```

```r
(paired_se_sglm0 +
        exactMatch(mass_cnty ~ factor(ps0_strat2, exclude=NULL), data=counties)
) %>% as.numeric() %>%
    floor() %>% table()
```

```
## .
##    0    1    2    3    4 
## 4214  604   18    1    1
```

Now within ppty2 trimmed sample/subclasses


```r
paired_se_sglm2  <- paired_se_dist(sglm2, covariance.estimator="sandwich")
paired_se_sglm2  <- paired_se_sglm2/pie_sglm2$rms_err
summary(as.numeric(paired_se_sglm2))
```

```
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
##    0.07    0.63    0.92    1.11    1.29    8.66
```

```r
(paired_se_sglm2 +
        exactMatch(mass_cnty ~ factor(ps2_trim, exclude=NULL), data=counties)
) %>% as.numeric() %>%
    floor() %>% table()
```

```
## .
##    0    1    2 
## 6171 1475   54
```

```r
(paired_se_sglm2 +
        exactMatch(mass_cnty ~ factor(ps2_strat2, exclude=NULL), data=counties)
) %>% as.numeric() %>%
    (function(x) x[x>=2]) %>% sort() #floor() %>% table()
```

```
##  [1] 2.00 2.01 2.02 2.03 2.04 2.06 2.10 2.10 2.11 2.12 2.12 2.18 2.23 2.30 2.32
## [16] 2.32 2.35 2.42 2.50 2.55 2.56 2.61
```


# Propensity score pair matches

Convenience function


```r
lInf_and_l2 <- function(x) c(`lInf`=max(abs(x)), `l2`=sqrt(mean(x^2)))
```

## Matching on a single index



```r
ppty0_dist  <- 
    match_on(counties$ppty0, z=counties$mass_cnty,
             data=counties)
counties$pm_ppty0  <- pairmatch(ppty0_dist, data=counties)
counties$pm_ppty0 %>% matched.distances(ppty0_dist) %>%
    unlist() %>% lInf_and_l2()
```

```
##   lInf     l2 
## 0.1278 0.0487
```

```r
counties$pm_ppty0 %>% matched.distances(ppty0_dist) %>%
    unlist() %>% lInf_and_l2()
```

```
##   lInf     l2 
## 0.1278 0.0487
```

To interpret, recall that


```r
s_p_sglm0 ; pie_sglm0
```

```
## [1] 2.37
```

```
## pic_me_info object (a list) with `c(max_err, rms_err)`= c(8.57, 3.32)
```

How closely have we matched on the other score?


```r
ppty2_dist  <- 
    match_on(counties$ppty2, z=counties$mass_cnty,
             data=counties)
counties$pm_ppty0 %>% matched.distances(ppty2_dist) %>%
    unlist() %>% lInf_and_l2()
```

```
## lInf   l2 
## 3.38 1.26
```

```r
s_p_sglm2 ; pie_sglm2
```

```
## [1] 2
```

```
## pic_me_info object (a list) with `c(max_err, rms_err)`= c(4.62, 1.79)
```

Dramatically farther away on that score than on the one
we had matched on. 
Now reversing the roles of the 2 scores, i.e.
pair matching based on `ppty2`:


```r
counties$pm_ppty2  <- pairmatch(ppty2_dist, data=counties)
counties$pm_ppty2 %>% matched.distances(ppty2_dist) %>%
    unlist() %>% lInf_and_l2()
```

```
##   lInf     l2 
## 0.2077 0.0571
```

```r
counties$pm_ppty2 %>% matched.distances(ppty0_dist) %>%
    unlist() %>% lInf_and_l2()
```

```
## lInf   l2 
## 2.14 1.02
```

(Hmm, still not great... for an attempted remedy see
Ancillary explorations: Mahalanobis matches, below.)

Adding this match to the plot:


```r
pop_by_ppty0_scatter()
counties %>% filter(stateFIPS!=25, !is.na(pm_ppty0)) %>%
    with(points(ppty0, log10(a20_64_cnt), pch=21, col="red", bg="red"))
```

![](SLB_PS_variants_files/figure-html/pop_by_ppty0_scatter3-1.png)<!-- -->


## Matching on index plus paired index SE




```r
ppty0_pse_dist  <- paired_se_dist(sglm0)
summary(ppty0_pse_dist)
```

```
## Membership: 14 treatment, 3127 control
## Total eligible potential matches: 43778 
## Total ineligible potential matches: 0 
## 
## Summary of minimum matchable distance per treatment member:
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
##   0.250   0.390   0.461   0.471   0.575   0.710
```

```r
ppty0_pse_dist  <- # ISM type persists better across arith ops
    as.InfinitySparseMatrix(ppty0_pse_dist)
```





```r
npairs_target  <- pie_sglm0$num_pairs
mean(ppty0_pse_dist > pie_sglm0$max_pic_se)
```

```
## [1] 0.107
```

Now figure the sum distance.
Before they're combined with estimated index difference
distances, standard error distances need to be scaled up
to reflect expected max paired index contrast error.


```r
ppty0_sum_dist  <- ppty0_dist +
    ppty0_pse_dist * sqrt(2* log(2 * npairs_target))
mean(ppty0_sum_dist <= 0.25*s_p_sglm0)
```

```
## [1] 0
```

I.e., imposing sums of conventional width calipers
on the propensity score and paired propensity SE
simultaneously would cause significant loss of sample:


```r
ppty0_sum_dist %>%
    match_on(caliper=0.5*s_p_sglm0) %>% summary()
```

```
## Membership: 14 treatment, 3127 control
## Total eligible potential matches: 1 
## Total ineligible potential matches: 43777 
## 
## 13 unmatchable treatment members:
## 	1216, 1217, 1218, 1219, 1220, ...
## See summary(.)$unmatchable$treatment for a complete list.
## 
## 3126 unmatchable control members:
## 	1, 2, 3, 4, 5, ...
## See summary(.)$unmatchable$control for a complete list.
## 
## Summary of minimum matchable distance per treatment member:
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
##   0.676   0.676   0.676   0.676   0.676   0.676
```

This stands in contrast to matching
on the propensity score without attention to
variability: 


```r
ppty0_dist %>% match_on(caliper=0.25*s_p_sglm0) %>% summary()
```

```
## Membership: 14 treatment, 3127 control
## Total eligible potential matches: 1410 
## Total ineligible potential matches: 42368 
## 
## 2309 unmatchable control members:
## 	1, 2, 3, 4, 5, ...
## See summary(.)$unmatchable$control for a complete list.
## 
## Summary of minimum matchable distance per treatment member:
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
##  0.0000  0.0032  0.0113  0.0271  0.0233  0.1278
```

As a caliper width for the sum distance, we add our
lowball estimates of the expected max pic error and expected max
pic SE (w/ suitable upscaling on part of the latter).


```r
(ppty0_sum_cal  <-
     with(pie_sglm0, max_err +
                     sqrt(2* log(2 * npairs_target)) *
                     max_pic_se
          )
)
```

```
## [1] 20.6
```

```r
ppty0_sum_dist |> match_on(caliper=ppty0_sum_cal) |>
    summary()
```

```
## Membership: 14 treatment, 3127 control
## Total eligible potential matches: 34878 
## Total ineligible potential matches: 8900 
## 
## 142 unmatchable control members:
## 	3, 6, 68, 69, 81, ...
## See summary(match_on(ppty0_sum_dist, caliper = ppty0_sum_cal))$unmatchable$control for a complete list.
## 
## Summary of minimum matchable distance per treatment member:
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
##   0.676   1.244   1.587   1.678   2.170   2.445
```

Every treated county has eligible matches.  In fact,


```r
mean(ppty0_sum_dist > ppty0_sum_cal)
```

```
## [1] 0.203
```

```r
ppty0_sum_dist |> match_on(caliper=ppty0_sum_cal) |>
    pairmatch(data=counties, controls=100) |> summary()
```

```
## Structure of matched sets:
## 1:5+  0:1 
##   14 1727 
## Effective Sample Size:  27.7 
## (equivalent number of matched pairs).
```

I didn't explore much past this.
Here is variant of this distance that addresses large SEs
only, by tallying SE contributions only when they exceed
the expected max SE (for pairs that are well matched on the
underlying index, with the optimistic assumptions of Normal
covariates and extrinsic not intrinsic dimension). Here are
the pair SEs that exceed that mark:


```r
ppty0_dist_e  <-
    pmax(ppty0_pse_dist, pie_sglm0$max_pic_se) -
    pie_sglm0$max_pic_se
mean(as.vector(ppty0_dist_e)>0)
```

```
## [1] 0.107
```

```r
summary(as.vector(ppty0_dist_e)[as.vector(ppty0_dist_e)>0])
```

```
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
##    0.00    0.43    1.21    2.11    2.78   17.86
```

...but that's not the distance for matching on; this is:


```r
ppty0_dist_e  <- ppty0_dist +
    ppty0_dist_e * sqrt(2* log(2 * npairs_target))
mean(ppty0_dist_e > pie_sglm0$max_err)
```

```
## [1] 0.389
```

```r
ppty0_dist_e |> match_on(caliper=pie_sglm0$max_err) |>
    pairmatch(data=counties, controls=100) |> summary()
```

```
## Structure of matched sets:
## 1:5+  0:1 
##   14 1727 
## Effective Sample Size:  27.7 
## (equivalent number of matched pairs).
```

(Before matching, let's see how frequently/how badly
the more parsimonious propensity score sd's exceed
their "expected max".


```r
mean(paired_se_dist(sglm2) > pie_sglm2$max_pic_se)
```

```
## [1] 0.12
```

```r
paired_se_dist(sglm2) |>
(\(x) x[x>pie_sglm2$max_pic_se])() |> summary()
```

```
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
##    3.09    3.48    4.15    5.02    5.75   15.50
```

...no better than with the original score, it seems.)

Pair match on ppty0 distance, within calipers of
the PIC SE enhanced ppty0 distance immediately above, and also
± 1 in log base 10 of population.


```r
ppty0_dist_twocaliper  <-
    ( caliper(ppty0_dist_e, width=pie_sglm0$max_err) +
      caliper(match_on(mass_cnty ~ log10(a20_64_cnt),
                           method="euclidean",
                           data=counties),
                  width=1
                  ) + 
      match_on(ppty0_dist, data=counties)
    )
```

Fraction of pairs that this excludes:


```r
1 - length(ppty0_dist_twocaliper)/prod(dim(ppty0_dist_twocaliper))
```

```
## [1] 0.668
```

```r
counties$pm_ppty0_e  <-
    pairmatch(ppty0_dist_twocaliper, data=counties)
counties$pm_ppty0_e %>%
    matched.distances(ppty0_dist) %>%
    lInf_and_l2()
```

```
##  lInf    l2 
## 0.245 0.104
```

```r
counties$pm_ppty0_e %>%
    matched.distances(ppty0_pse_dist) %>%
    lInf_and_l2()
```

```
## lInf   l2 
## 2.66 1.47
```

Full matching on ppty0 within calipers
on `ppty0`, on corresponding pair-specific sglm0 SE's,
and logpop. 


```r
counties$fm_ppty0_e <- fullmatch(ppty0_dist_twocaliper, data=counties) 
```

Info about this match:


```r
summary(counties$fm_ppty0_e)
```

```
## Structure of matched sets:
##  1:1  1:2 1:5+  0:1 
##    2    1   11  250 
## Effective Sample Size:  24.5 
## (equivalent number of matched pairs).
```

Treatment group members matched only to a single control:


```r
counties |> filter(stateFIPS==25, fm_ppty0_e%in%c("1.11", "1.3", "1.9")) |> left_join(mass_counties, by=c("stateFIPS", "cntyFIPS")) |> select(ppty0, cnty_name, cnty_abbrev)
```

```
## # A tibble: 3 × 3
##     ppty0 cnty_name cnty_abbrev
##     <dbl> <chr>     <chr>      
## 1  0.0623 Bristol   Bl         
## 2 -1.74   Middlesex Md         
## 3  0.219  Norfolk   Nr
```

(Middlesex and Norfolk contain Boston suburbs, Cambridge in
Middlesex and Quincy/Braintree/Brookline in Norfolk.) 
stock match quality info


```r
counties$fm_ppty0_e %>%
    matched.distances(ppty0_dist) %>%
    unlist() %>% lInf_and_l2()
```

```
## lInf   l2 
## 8.51 2.67
```

```r
counties$fm_ppty0_e %>%
    matched.distances(ppty0_pse_dist) %>%
    unlist() %>% lInf_and_l2()
```

```
## lInf   l2 
## 7.60 2.62
```

```r
covariates_SLB %>% 
    paste(collapse="+") %>%
    paste("mass_cnty ~", ., "-1+strata(pm_ppty0)+strata(pm_ppty0_e)+strata(fm_ppty0_e)") %>%
    as.formula() %>%
    balanceTest(counties, unit.weights=a20_64_cnt)|>
                print(which.stats=c("Treatment", "Control"))
```

```
##              strata():  pm_ppty0         pm_ppty0_e         fm_ppty0_e        
##              stat      Treatment Control  Treatment Control  Treatment Control
## vars                                                                          
## a20_34                     33      34         33      33         33      37   
## a35_44                     26      25         26      27         26      26   
## a45_54                     24      24         24      24         24      22   
## a55_64                     16      17         16      16         16      15   
## male                       49      49         49      49         49      50   
## white_race                 87      85         87      91         87      77   
## black_race                  7.0    11.3        7.0     4.9        7.0    10.0 
## other_race                  5.6     3.8        5.6     4.4        5.6    13.1 
## latino                      7.3     8.9        7.3     6.4        7.3    32.4 
## pov                         9.6    13.5        9.6     8.7        9.6    14.5 
## inc                        63290   47506      63290   64198      63290   54670
## unemp                      5.0     4.9        5.0     4.7        5.0     5.7  
## unins                      14      17         14      12         14      24   
## mortAC_20_64               283     346        283     262        283     279  
## ---Overall Test---
##            chisquare df p.value
## pm_ppty0          13 13    0.42
## pm_ppty0_e        13 13    0.43
## fm_ppty0_e        19 13    0.13
```

(Covariate-level imbalances are made better or worse, depending on the covariate.  The p-value increases, but this is plausibly a function of the decrease in effective sample size.)

# Wrapup
Store generated artifacts for use elsewhere


```r
stratifications  <- counties %>%
    dplyr::select(stateFIPS, cntyFIPS, mass_cnty, a20_64_cnt,
           ppty0, ppty1, ppty2,
           ps0_trim, ps0_strat2,
           ps2_trim, ps2_strat2,
           pm_ppty0, pm_ppty2,
           pm_ppty0_e, fm_ppty0_e)
save(sglm0, pie_sglm0,
     sglm2, pie_sglm2,
     stratifications,  file="SLB_PS_variants.RData")
```


# Ancillary explorations
## Full matching not pair matching

Optimal full matching on each score, excluding counties as necessary to 
ensure close matching everywhere. 


```r
fullmatch(ppty0_dist + caliper(ppty0_dist, width=0.25 * s_p_sglm0),
          data=counties, 
          ) -> counties$fm_ppty0
fullmatch(ppty2_dist + caliper(ppty2_dist, width=0.25 * s_p_sglm2), 
          data=counties, 
          ) -> counties$fm_ppty2
```


Excludes treatment group counties?


```r
summary(counties$fm_ppty0)
```

```
## Structure of matched sets:
##  1:1  1:2 1:5+  0:1 
##    1    1   12 2309 
## Effective Sample Size:  24.8 
## (equivalent number of matched pairs).
```

```r
summary(counties$fm_ppty2)
```

```
## Structure of matched sets:
##  1:2  1:3  1:4 1:5+  0:1 
##    1    1    1   11 2324 
## Effective Sample Size:  25.4 
## (equivalent number of matched pairs).
```

Considering `fm_ppty2` a bit further:


```r
counties$fm_ppty2 %>% matched.distances(ppty2_dist) %>%
    unlist() %>% lInf_and_l2()
```

```
##  lInf    l2 
## 0.498 0.251
```

How close a caliper is possible without dropping treatment group members? It depends
on which score of course. The answer for `sglm0`:


```r
( ppty0_dist_summ  <- summary(ppty0_dist) )
```

```
## Membership: 14 treatment, 3127 control
## Total eligible potential matches: 43778 
## Total ineligible potential matches: 0 
## 
## Summary of minimum matchable distance per treatment member:
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
##  0.0000  0.0032  0.0113  0.0271  0.0233  0.1278
```

```r
ppty0_dist_summ$distances['Max.']/s_p_sglm0
```

```
##   Max. 
## 0.0539
```

```r
ppty0_dist %>% match_on(caliper= 0.05 * s_p_sglm0) %>%
    fullmatch( data=counties ) %>% summary()
```

```
## Structure of matched sets:
##  1:0  1:1  1:3  1:4 1:5+  0:1 
##    2    1    1    1    9 2889 
## Effective Sample Size:  21.1 
## (equivalent number of matched pairs).
```

```r
ppty0_dist %>% match_on(caliper= 0.06 * s_p_sglm0) %>%
    fullmatch( data=counties ) %>% summary()
```

```
## Structure of matched sets:
##  1:1  1:3  1:4 1:5+  0:1 
##    3    1    1    9 2855 
## Effective Sample Size:  23.1 
## (equivalent number of matched pairs).
```

```r
ppty0_dist %>% match_on(caliper= 0.06 * s_p_sglm0) %>%
    fullmatch( data=counties ) -> counties$fm_ppty0  
```


Answer for `sglm2`:


```r
( ppty2_dist_summ  <- summary(ppty2_dist) )
```

```
## Membership: 14 treatment, 3127 control
## Total eligible potential matches: 43778 
## Total ineligible potential matches: 0 
## 
## Summary of minimum matchable distance per treatment member:
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
##  0.0003  0.0020  0.0047  0.0221  0.0089  0.2077
```

```r
ppty2_dist_summ$distances['Max.']/s_p_sglm2
```

```
##  Max. 
## 0.104
```

```r
ppty2_dist %>% match_on(caliper= 0.10 * s_p_sglm2) %>%
    fullmatch( data=counties ) %>% summary()
```

```
## Structure of matched sets:
##  1:0  1:2  1:3 1:5+  0:1 
##    1    1    1   11 2712 
## Effective Sample Size:  23.4 
## (equivalent number of matched pairs).
```

```r
ppty2_dist %>% match_on(caliper= 0.11 * s_p_sglm2) %>%
    fullmatch( data=counties ) %>% summary()
```

```
## Structure of matched sets:
##  1:1  1:2  1:4 1:5+  0:1 
##    1    1    1   11 2663 
## Effective Sample Size:  24.5 
## (equivalent number of matched pairs).
```

```r
ppty2_dist %>% match_on(caliper= 0.11 * s_p_sglm2) %>%
    fullmatch( data=counties ) -> counties$fm_ppty2  
```


Full matching within calipers included relatively
little of the control group (see ancillary explorations
below), obviating its advantage over pairs.


## Mahalanobis matching to address poor matches on `ppty0`/`ppty2` when calipering on `ppty2`/`ppty0`.

Let's look at pair matching
on a Mahalanobis distance, within propensity calipers.


```r
mh0_dist  <- 
    match_on(formula(sglm0),
             data=base_cnty
             ) 
counties$pm_mh0  <-
    pairmatch(mh0_dist +
              caliper(ppty0_dist, width=.2*s_p_sglm0),
              data=counties)
counties$pm_mh0 %>% matched.distances(ppty0_dist) %>%
    unlist() %>% lInf_and_l2()
```

```
##  lInf    l2 
## 0.462 0.310
```

```r
counties$pm_mh0 %>% matched.distances(ppty2_dist) %>%
    unlist() %>% lInf_and_l2()
```

```
## lInf   l2 
## 1.41 0.55
```

The caliper on `ppty0` now gets you closer on `ppty2`
than it did without Mahalanobis matching, but it's still
not super close.



---
title: SLB_PS_variants.R
author: bbh
date: '2022-11-16'

---
