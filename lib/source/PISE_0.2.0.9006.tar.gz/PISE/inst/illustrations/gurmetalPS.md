---
title: PISEs for Gurm et al 2013 study
author: BH
output:
    html_document:
        keep_md: true
    md_document:
        variant: gfm
---

## Preliminaries





## data setup

Flag subjects lacking treatment data or age data.



```r
msng_tx_or_age <- !cdat.has.txinfo | is.na(cdat_red$AgeCat)
table(msng_tx_or_age)
```

```
## msng_tx_or_age
## FALSE  TRUE 
## 85048     2
```


Impute missings on remaining covariates.  Most of the missingness appears to be height,
weight and similar. 


```r
psdata <- optmatch::fill.NAs(pr_vcd~. -(AgeCat + hosp.code + ih_v_c+ih_tx+ih_death), 
                          data = cdat_red[!msng_tx_or_age,])
psdata <- data.frame(psdata, cdat_red[!msng_tx_or_age,][c("AgeCat", "hosp.code")])
formula_psdata = formula(psdata)
psdata$pi_race1 <- with(psdata, (pi_race2+pi_race3+ pi_race4+ pi_race5+ pi_race9)==0)

round(
sapply(grep(".NA", names(psdata), fixed=TRUE, value=TRUE), 
       function(nm) mean(psdata[[nm]])
       ), 
      3)
```

```
##          wt_kg.NA          ht_cm.NA        pi_race.NA       mi_lytic.NA 
##             0.025             0.017             0.006             0.000 
## mi_1st_ecg_pos.NA       l_pre_cr.NA      l_pre_hgb.NA            gfr.NA 
##             0.000             0.014             0.016             0.040 
##      caf_ndv_b.NA         pr_n_v.NA         pr_flt.NA          pr_tc.NA 
##             0.000             0.000             0.007             0.006 
##        pr_shth.NA         pr_dur.NA 
##             0.002             0.007
```



Variables that lead author identified as most important for propensity adjustment:


```r
main_PSvars <- pr_vcd ~ Age + gender1 + wt_kg + bmi_catLean + 
  pi_race1 + pi_race2+
hx_smk + hx_hyp + hx_iddm + hx_niddm + hx_chf + hx_pvd + hx_copd +
  hx_cva + hx_rfd + l_pre_cr + l_pre_hgb + gfr + ci_ang + ci_ua +
  ci_tdsrg+ci_stgd+mi_pptca + mi_present + mi_lytic + hep_pre +
  nitr_pre + vaso_pre + vaso_dur + 
  coum_pre + reo_pre + int_pre + plvx_pre + angi_dur +
  intg_pre + intg_dur + dur_2b3a + caf_lmst + caf_ef + caf_ndv_b +
  pr_n_v + pr_flt + pr_tc + pr_shth + calc_1 + thrm_1 + cto_1 + 
  pr_st_1 + dissection_yn_1
```


Subclasses selected to facilitate subgroup analyses:


```r
psdata$prognostic.subclasses <- 
    with(psdata, 
       interaction(gender1, 
                   bmi_catLean,
                   mi_present, inhib, 
                   angi_dur, 
                   hx_pvd,
                   drop=TRUE)
       )
```




## Procedure volume at treating hospitals

Divide patients according to whether they were treated at hospitals with high, medium or low volume of indicated procedures.


```r
tb <- sort(table(psdata$hosp.code))
 sum(tb)/3
```

```
## [1] 28349
```

```r
sum( cumsum(tb)<(sum(tb)/3) )
```

```
## [1] 18
```

```r
cumsum(tb)[sum(cumsum(tb)<(sum(tb)/3)) + -2:2]
```

```
##    15     2    41     3    36 
## 21279 23763 26262 28980 31831
```

```r
volgroups <- list()
volgroups$i <- c(0, sum( cumsum(tb)<(sum(tb)/3) ), sum( cumsum(tb)<(2*sum(tb)/3) ), length(tb))
volgroups <- within(volgroups, 
                    {low = names(tb)[(i[1]+1):i[2] ]
                    med = names(tb)[(i[2]+1):i[3] ]
                    high = names(tb)[(i[3]+1):i[4] ]
                   }
                    ) 
volgroups <- volgroups[names(volgroups)!="i"]
psdata$hosp.volume <- factor(numeric(nrow(psdata)), levels=c("low", "med", "high"))
for (nm in names(volgroups)) psdata$hosp.volume[psdata$hosp.code %in% volgroups[[nm]] ] <- nm
table(psdata$hosp.volume)
```

```
## 
##   low   med  high 
## 26262 27875 30911
```

```r
with(psdata, setequal(levels(hosp.code[hosp.volume=="low", drop=TRUE]), volgroups$low))
```

```
## [1] TRUE
```


## Propensity scores

the statistical appendix of Gurm et al refers to the PS below as ``Matching within hospital groups, on inclusive score only''.



```r
ps_big <- 
  glm(update(formula_psdata, 
             pr_vcd~interaction(prognostic.subclasses, hosp.volume)+.-hosp.code),
      family=binomial, data=psdata)
```


(I forget how Gurm et al referenced this smaller model.)



```r
ps_small <- glm(update(main_PSvars, 
                       .~interaction(prognostic.subclasses, hosp.volume)+.),
            family=binomial, data=psdata
               )
```


# The PISEs 

## 2015 edition



```r
ppse_big_unstabilized <- ppse_notstabilized(ps_big, covariance.estimator='sandwich', simplify=T) 
ppse_big_unstabilized
```

```
## [1] 0.217
```

## 2017 edition

Calcs using these data appeared in a presentation from 2016, not
2017.  Since the calculations have seen some QA, and I've gone
back and forth on whether to factor out strata columns.  Present
calculations do not, as I believe I did not in the 2016 presentation.
(Perhaps inadvertently: there were strata
columns, but declared at end rather than beginning of model formula.
Or maybe the code I was using then pulled them out, but incorrectly.)



```r
pie_ps_big <-
    pie_max(ps_big, covariance.estimator = 'sandwich')
pie_ps_big
```

```
## pie_max_info object (a list) with `c(pair_lInf, pair_l2)`= c(1.25, 0.217)
```

Corresponding d.f.:


```r
length(pie_ps_big$betahat)
```

```
## [1] 387
```


If the two above were to differ greatly, I'd take the latter one.
(The former one tries to take into account our intention to match
exactly within \texttt{hosp.volume} classes.)

These answers are expressed in the units of the linear predictor (here,
logits).  The matching function also expects them to be expressed in
terms of the linear predictor (as opposed to on the probability scale)
but in standard units, ie as multiples of a pooled sd. Accordingly, 



```r
ppse_big_unstabilized/optmatch:::szn.scale(predict(ps_big), ps_big$y, standardizer=sd) 
```

```
## [1] 0.326
```





```r
pie_ps_small <-
    pie_max(ps_small, covariance.estimator = 'sandwich')
psscale_sm <- optmatch:::szn.scale(predict(ps_small), ps_small$y, standardizer=mad) 
pie_ps_small
```

```
## pie_max_info object (a list) with `c(pair_lInf, pair_l2)`= c(1.03, 0.17)
```

Corresponding d.f.:


```r
length(pie_ps_small$betahat)
```

```
## [1] 235
```

Expressed as a multiple of pooled s.d.:


```r
unlist(pie_ps_small[c('pair_lInf', 'pair_l2')])/psscale_sm
```

```
## pair_lInf   pair_l2 
##     2.174     0.358
```


Save it. 


```r
save(ps_big, ps_small, pie_ps_big, ppse_big_unstabilized, pie_ps_small, 
     file="~/Documents/caches/Gurm-pci2007/gurmetalPS.RData")
```


## What's the effect of regularization?

Non-regularized propensity model fit.


```r
calls <- list(ps_small_bayesglm=ps_small$call,
              ps_big_bayesglm=ps_big$call)
calls[['ps_small_bayesglm']][[1L]]  <- quote(arm::bayesglm)
calls[['ps_big_bayesglm']][[1L]]  <- quote(arm::bayesglm)
ps_small_bayesglm_mod  <- eval(calls$ps_small_bayesglm)
ps_big_bayesglm_mod  <- eval(calls$ps_big_bayesglm)
pie_ps_small_bayesglm  <- pie_max(ps_small_bayesglm_mod)
pie_ps_big_bayesglm  <- pie_max(ps_big_bayesglm_mod)
```

L2 regularization done another way.


```r
calls  <- c(calls, list(ps_small_brglm=ps_small$call))
calls[['ps_small_brglm']][[1L]]  <- quote(brglm::brglm)
ps_small_brglm_mod  <- eval(calls$ps_small_brglm)
pie_ps_small_brglm  <- pie_max(ps_small_brglm_mod)
```


scale


```r
pooled_sds  <-
    list(glm_sm=optmatch:::szn.scale(predict(ps_small),
                                  ps_small$y, standardizer=sd), 
         bayesglm_sm=optmatch:::szn.scale(predict(ps_small_bayesglm_mod),
                                       ps_small_bayesglm_mod$y,
                                       standardizer=sd),
         brglm=optmatch:::szn.scale(predict(ps_small_brglm_mod),
                                    ps_small_brglm_mod$y,
                                    standardizer=sd),
         glm_big=optmatch:::szn.scale(predict(ps_big),
                                  ps_big$y, standardizer=sd), 
         bayesglm_big=optmatch:::szn.scale(predict(ps_big_bayesglm_mod),
                                       ps_big_bayesglm_mod$y,
                                       standardizer=sd)         
         ) %>% unlist()
pooled_mads  <-
    list(glm_sm=psscale_sm, 
         bayesglm_sm=optmatch:::szn.scale(predict(ps_small_bayesglm_mod),
                                       ps_small_bayesglm_mod$y,
                                       standardizer=mad),
         brglm=optmatch:::szn.scale(predict(ps_small_brglm_mod),
                                    ps_small_brglm_mod$y,
                                    standardizer=mad),
         glm_big=optmatch:::szn.scale(predict(ps_big),
                                  ps_big$y, standardizer=mad), 
         bayesglm_big=optmatch:::szn.scale(predict(ps_big_bayesglm_mod),
                                       ps_big_bayesglm_mod$y,
                                       standardizer=mad)
         ) %>% unlist()
```

Condition numbers, with and without regularization.


```r
data.frame(fitter=c('glm_sm', 'bayesglm_sm', 'brglm', 'glm_big', 'bayesglm_big'),
           kappa=sapply(list(ps_small, ps_small_bayesglm_mod,
                                   ps_small_brglm_mod, ps_big,
                                   ps_big_bayesglm_mod),
                         function(x) kappa(x$qr)),
           pie_rms=sapply(list(pie_ps_small, pie_ps_small_bayesglm,
                            pie_ps_small_brglm, pie_ps_big,
                            pie_ps_big_bayesglm),
                        getElement, name="pair_l2"),
           pie_max=sapply(list(pie_ps_small, pie_ps_small_bayesglm,
                            pie_ps_small_brglm, pie_ps_big,
                            pie_ps_big_bayesglm),
                        getElement, name="pair_lInf")
           
           ) %>%
    mutate(`rms/mad`=pie_rms/pooled_mads,
           `rms/s_p`=pie_rms/pooled_sds,
           `max/s_p`=pie_max/pooled_sds) %>%
    relocate(pie_max, .after=`rms/s_p`) %>% 
    knitr::kable(digits=3)
```



|fitter       |    kappa|  pie_rms|  rms/mad| rms/s_p|  pie_max| max/s_p|
|:------------|--------:|--------:|--------:|-------:|--------:|-------:|
|glm_sm       | 1.84e+20| 1.70e-01| 3.58e-01|   0.315| 1.03e+00|    1.91|
|bayesglm_sm  | 2.48e+05| 1.68e-01| 3.53e-01|   0.316| 1.00e+00|    1.88|
|brglm        | 1.88e+20| 3.25e+05| 6.87e+05|   0.000| 5.12e+06|    0.00|
|glm_big      |      Inf| 2.17e-01| 3.59e-01|   0.326| 1.25e+00|    1.88|
|bayesglm_big | 2.39e+05| 2.14e-01| 3.56e-01|   0.335| 1.22e+00|    1.91|

# Wrapup



```r
sessionInfo()
```

```
## R version 4.0.5 (2021-03-31)
## Platform: x86_64-pc-linux-gnu (64-bit)
## Running under: Red Hat Enterprise Linux Workstation 7.9 (Maipo)
## 
## Matrix products: default
## BLAS/LAPACK: /usr/lib64/libopenblasp-r0.3.3.so
## 
## locale:
##  [1] LC_CTYPE=en_US.UTF-8       LC_NUMERIC=C              
##  [3] LC_TIME=en_US.UTF-8        LC_COLLATE=en_US.UTF-8    
##  [5] LC_MONETARY=en_US.UTF-8    LC_MESSAGES=en_US.UTF-8   
##  [7] LC_PAPER=en_US.UTF-8       LC_NAME=C                 
##  [9] LC_ADDRESS=C               LC_TELEPHONE=C            
## [11] LC_MEASUREMENT=en_US.UTF-8 LC_IDENTIFICATION=C       
## 
## attached base packages:
## [1] grid      stats     graphics  grDevices utils     datasets  methods  
## [8] base     
## 
## other attached packages:
##  [1] sandwich_3.0-1  MASS_7.3-53.1   forcats_0.5.1   stringr_1.4.0  
##  [5] purrr_0.3.4     readr_1.4.0     tidyr_1.1.3     tibble_3.1.2   
##  [9] ggplot2_3.3.5   tidyverse_1.3.1 survey_4.0      Matrix_1.3-2   
## [13] PISE_0.1.0.9006 testthat_3.0.4  optmatch_0.9-14 survival_3.2-10
## [17] RItools_0.1-17  SparseM_1.81    dplyr_1.0.7    
## 
## loaded via a namespace (and not attached):
##  [1] minqa_1.2.4         colorspace_2.0-2    ellipsis_0.3.2     
##  [4] rprojroot_2.0.2     htmlTable_2.2.1     base64enc_0.1-3    
##  [7] fs_1.5.0            rstudioapi_0.13     remotes_2.4.0      
## [10] fansi_0.5.0         lubridate_1.7.10    xml2_1.3.2         
## [13] codetools_0.2-18    splines_4.0.5       cachem_1.0.5       
## [16] brglm_0.7.2         knitr_1.33          pkgload_1.2.1      
## [19] Formula_1.2-4       jsonlite_1.7.2      nloptr_1.2.2.2     
## [22] broom_0.7.8         cluster_2.1.1       dbplyr_2.1.1       
## [25] png_0.1-7           compiler_4.0.5      httr_1.4.2         
## [28] backports_1.2.1     assertthat_0.2.1    fastmap_1.1.0      
## [31] profileModel_0.6.1  cli_3.0.0           htmltools_0.5.1.1  
## [34] prettyunits_1.1.1   tools_4.0.5         coda_0.19-4        
## [37] gtable_0.3.0        glue_1.4.2          Rcpp_1.0.7         
## [40] cellranger_1.1.0    vctrs_0.3.8         nlme_3.1-152       
## [43] xfun_0.24           ps_1.6.0            rvest_1.0.0        
## [46] lme4_1.1-27.1       lifecycle_1.0.0     devtools_2.4.2     
## [49] zoo_1.8-9           scales_1.1.1        hms_1.1.0          
## [52] RColorBrewer_1.1-2  yaml_2.2.1          memoise_2.0.0      
## [55] gridExtra_2.3       rpart_4.1-15        latticeExtra_0.6-29
## [58] stringi_1.7.3       highr_0.9           desc_1.3.0         
## [61] checkmate_2.0.0     boot_1.3-27         pkgbuild_1.2.0     
## [64] rlang_0.4.11        pkgconfig_2.0.3     arm_1.11-2         
## [67] evaluate_0.14       lattice_0.20-41     htmlwidgets_1.5.3  
## [70] processx_3.5.2      tidyselect_1.1.1    magrittr_2.0.1     
## [73] R6_2.5.0            generics_0.1.0      Hmisc_4.5-0        
## [76] DBI_1.1.1           pillar_1.6.1        haven_2.4.1        
## [79] foreign_0.8-81      withr_2.4.2         abind_1.4-5        
## [82] nnet_7.3-15         modelr_0.1.8        crayon_1.4.1       
## [85] utf8_1.2.1          rmarkdown_2.9       jpeg_0.1-8.1       
## [88] usethis_2.0.1       readxl_1.3.1        data.table_1.14.0  
## [91] callr_3.7.0         reprex_2.0.0        digest_0.6.27      
## [94] svd_0.5             xtable_1.8-4        munsell_0.5.0      
## [97] mitools_2.4         sessioninfo_1.1.1
```



---
date: '2021-08-02'

---
