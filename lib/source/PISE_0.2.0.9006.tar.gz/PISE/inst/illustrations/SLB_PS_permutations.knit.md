---
output:
    html_document:
        keep_md: true
    md_document:
        variant: gfm
---
# Setup







```r
set.seed(202103)
bootfuns  <- list()
refit_nbmods  <- TRUE
```

How many replicates?


```r
if (!exists('nreps')) nreps  <- 3
if (!exists('ncores')) ncores  <- 3
c(nreps=nreps, ncores=ncores)
```

```
##  nreps ncores 
##      3      3
```

```r
perms  <- perms1step  <- list()
```

Data readin (hidden in output)...




Function to make the function performing the calculations to be
permuted.  (That generated function will have to require its
first argument `dat` to have been stripped in advance of rows
that are NA for the stratifying variable.)


```r
make_negbin_null_estfun_statistic_fn  <- function(strat)
{
    stopifnot(is.character(strat), 
              any(strat==colnames(stratifications))
              )
    bal_fmla  <-  c("a20_34", "a35_44", "a45_54", "a55_64",
      "male", "white_race", "black_race", "other_race", "latino",
      "pov", "inc", "unemp", "unins", "mortAC_20_64") %>% 
        paste(collapse="+") %>%
        paste("mass_cnty ~", ., "-1+strata(", strat,")") %>%
        as.formula()
    resp_fmla  <- paste("deathsAC ~ race + sex + agegrp + pov + inc +",
               "unemp + pct_latino + year + stateFIPS +",#strat, "+",
               "offset(log(pop))") %>% as.formula()

    counties_  <- counties %>% # remove vars also carried in stratifications, since
        dplyr::select(-mass_cnty, -a20_64_cnt) # it's to be joined with that table

    stratifications[!is.na(stratifications[[strat]]),
                    c(strat, "stateFIPS", "cntyFIPS")
                    ] %>%
        left_join(yrly_cnty_subgrps, by=c("stateFIPS", "cntyFIPS")) -> 
        yrly_cnty_subgrps_
        
    nbmod0  <- glm.nb(resp_fmla, data=yrly_cnty_subgrps_)

    intercept_scores  <- sandwich::estfun(nbmod0)[,"(Intercept)", drop=F]
    colnames(intercept_scores)  <- "intercept_scores"
    stopifnot(is.null(na.action(nbmod0))) # (were they presented, NAs would call for more verbose code)
    strat_  <- rlang::syms(strat)
    yrly_cnty_subgrps_  %>% cbind(intercept_scores) %>%
        filter(year>2005) %>%
        group_by(!!!strat_, stateFIPS, cntyFIPS) %>%
        summarise(q=sum(intercept_scores)) ->
        q_table
    ## now mean-center by stratum.  (had we not subsetted to post-2005 period,
    ## stratum-mean centering would have been enforced by model fit.) 
    q_table %>% ungroup() %>%
        group_by(!!!strat_) %>%
        mutate(q_centered=(q-mean(q))) %>%
        ungroup()  -> q_table

    yrly_cnty_subgrps_  <-
        yrly_cnty_subgrps_[, -which(colnames(yrly_cnty_subgrps_)==strat)]
    
    theta0  <- nbmod0$theta
    coef0  <- coef(nbmod0)
    coef0[is.na(coef0)]  <- 0

    function(dat, indices) {
        dat[["mass_cnty"]]  <- dat[indices, 'mass_cnty', drop=TRUE]

        counties__ <-  counties_ %>%
        right_join(dat, by=c("stateFIPS", "cntyFIPS")) 
        bal  <-
            balanceTest(bal_fmla, data=counties__,
                        unit.weights=a20_64_cnt)$overall[1,]

        q_table  <- left_join(dat, q_table, by=c("stateFIPS", "cntyFIPS"))
        ztq  <- with(q_table, sum(mass_cnty * q_centered))
        ztq_over_l2zq  <- ztq/
            with(q_table, sqrt(sum(mass_cnty * q_centered^2)) )
        
        
        dat %>%  left_join(yrly_cnty_subgrps_, by=c("stateFIPS", "cntyFIPS")) %>%
        mutate(mass_reform= (mass_cnty & year>2005)
               ) -> yrly_cnty_subgrps__

        suppressWarnings(
            nb_1step  <- glm(update(resp_fmla, .~.+mass_reform),
                         data=yrly_cnty_subgrps__,
                         family=negative.binomial(theta=theta0),
                         start=c(coef0, "mass_reform"=0),
                         control=glm.control(maxit=1)
                         )
            )
        coef_1step  <- coef(nb_1step)["mass_reformTRUE"]
        vcov_nbmod  <- vcov(nb_1step)["mass_reformTRUE", "mass_reformTRUE"]
        vcov_state  <- sandwich::vcovCL(nb_1step, cluster=yrly_cnty_subgrps__$stateFIPS, type="HC1")
        vcov_cnty  <- sandwich::vcovCL(nb_1step, cluster=paste0(yrly_cnty_subgrps__$stateFIPS,
                                                                 yrly_cnty_subgrps__$cntyFIPS),
                                       type="HC1")
        tstat_nbmod  <- coef_1step/sqrt(vcov_nbmod)
        tstatHC1_state  <- coef_1step/sqrt(vcov_state["mass_reformTRUE","mass_reformTRUE"])
        tstatHC1_cnty  <- coef_1step/sqrt(vcov_cnty["mass_reformTRUE","mass_reformTRUE"])        
        tstat_nbmod  <- unname(tstat_nbmod)
        tstatHC1_state  <- unname(tstatHC1_state)
        tstatHC1_cnty  <- unname(tstatHC1_cnty)
        
        raotest  <- stats:::anova.glm(nbmod0, nb_1step, test="Rao")
        c(bal, ztq=ztq, ztq_over_l2zq=ztq_over_l2zq,
          coef_1step, tstat_nbmod=tstat_nbmod,
          tstatCL_state=tstatHC1_state, tstatCL_cnty=tstatHC1_cnty,
          rao.chisq=raotest[2,"Rao"],
          rao.pval=raotest[2,"Pr(>Chi)"]) %>% #shouldn't be nec., not
            unlist()                          #stopping to investigate
    }
}
make_negbin_refitter_statistic_fn  <- function(strat) {
    stopifnot(is.character(strat), 
              any(strat==colnames(stratifications)))
    resp_fmla  <- paste("deathsAC ~ race + sex + agegrp + pov + inc +",
               "unemp + pct_latino + year + stateFIPS +",#strat, "+",
               "offset(log(pop))") %>% as.formula()
    stratifications_  <- stratifications[!is.na(stratifications[[strat]]),]
    yrly_cnty_subgrps_  <- stratifications_ %>%
        left_join(yrly_cnty_subgrps, by=c("stateFIPS", "cntyFIPS")) 
    nbmod0  <- glm.nb(resp_fmla, data=yrly_cnty_subgrps_)

    function(dat, indices) {
        dat[['mass_cnty']]  <- dat[indices, 'mass_cnty']
        dat %>%  left_join(yrly_cnty_subgrps, by=c("stateFIPS", "cntyFIPS")) %>%
        mutate(mass_reform= (mass_cnty & year>2005),
               year=as.character(year)
               ) -> newdat
    
    nbmod_new  <- try(update(nbmod0,
                         formula=update(formula(nbmod0), .~.+mass_reform),
                         data=newdat
                         ),
                  silent=TRUE)

        if (inherits(nbmod_new, "try-error"))
            return(c(coef=NA_real_, tstatCL_state=NA_real_, tstatCL_cnty=NA_real_,
                     pseudo_mass=which(unlist(dat[["mass_cnty"]])))
                   )

        thecoef  <- coef(nbmod_new)["mass_reformTRUE"]
        vcov_state  <- sandwich::vcovCL(nbmod_new, cluster=newdat$stateFIPS, type="HC1")
        vcov_cnty  <- sandwich::vcovCL(nbmod_new, cluster=paste0(newdat$stateFIPS, newdat$cntyFIPS), type="HC1")
        tstatHC1_state  <- thecoef/sqrt(vcov_state["mass_reformTRUE","mass_reformTRUE"])        
        tstatHC1_cnty  <- thecoef/sqrt(vcov_cnty["mass_reformTRUE","mass_reformTRUE"])
        tstatHC1_state  <- unname(tstatHC1_state)
        tstatHC1_cnty  <- unname(tstatHC1_cnty)
        c(thecoef, tstatCL_state=tstatHC1_state, tstatCL_cnty=tstatHC1_cnty,
          pseudo_mass=which(unlist(dat[["mass_cnty"]]))
          )  %>%     #shouldn't be nec., not
            unlist() #stopping to investigate
        }
    }
```

Run simulations

With sample trimmed a la SLB:


```r
bootfuns$onestep_ps0_trim  <- make_negbin_null_estfun_statistic_fn("ps0_trim")
system.time(
perms1step$ps0_trim  <-
    boot::boot(stratifications[!is.na(stratifications$ps0_trim),],
               bootfuns$onestep_ps0_trim,
               R=nreps, 
               sim="permutation", parallel="multicore", ncpus=ncores)
)
```

```
##    user  system elapsed 
##   5.133   0.761  15.022
```




```r
bootfuns$refit_ps0_trim <- make_negbin_refitter_statistic_fn("ps0_trim")
system.time(
perms$ps0_trim  <- boot::boot(stratifications[!is.na(stratifications$ps0_trim),],
                     bootfuns$refit_ps0_trim,
               R=nreps, 
               sim="permutation", parallel="multicore", ncpus=ncores)
)
```

```
##    user  system elapsed 
##   138.3    10.6   104.9
```

With trimming and stratification per trimmed propensity score:


```r
bootfuns$onestep_ps0_strat2  <- make_negbin_null_estfun_statistic_fn("ps0_strat2")
system.time(
perms1step$ps0_strat2  <-
    boot::boot(stratifications[!is.na(stratifications$ps0_strat2),],
               bootfuns$onestep_ps0_strat2,
               R=nreps, strata=na.omit(stratifications$ps0_strat2),
               sim="permutation", parallel="multicore", ncpus=ncores)
)
```

```
##    user  system elapsed 
##    91.6    12.8    52.3
```




```r
bootfuns$refit_ps0_strat2 <- make_negbin_refitter_statistic_fn("ps0_strat2")
system.time(
perms$ps0_strat2  <- boot::boot(stratifications[!is.na(stratifications$ps0_strat2),],
                     bootfuns$refit_ps0_strat2,
               R=nreps, strata=na.omit(stratifications$ps0_strat2),
               sim="permutation", parallel="multicore", ncpus=ncores)
)
```

```
##    user  system elapsed 
##     324      21     368
```

Using a full match to define permutations, while
fitting same model to sample of matched observations. (Since `boot()` can't deal
with NAs in the stratifying variable, we define a convenience function
`na_to_singleton()`, code suppressed, to convert them to singleton strata.)











































