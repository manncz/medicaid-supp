---
output:
    html_document: 
        keep_md: true
    md_document:
        variant: gfm
---
# Setup







```r
set.seed(202104)
if (!exists('nreps')) nreps  <- 3
if (!exists("ncores")) ncores  <- 3
c(nreps=nreps, ncores=ncores)
```

```
##  nreps ncores 
##   2000      3
```

Private resource: county data with year specific mortality, `base_cnty`.


```r
read_csv(file.path("..", "extdata", "base_cnty.csv")) %>%
    mutate(mass_cnty = (stateFIPS == "25"),
           a20_44=a20_34+a35_44,
           a45_64=a45_54+a55_64) %>%
    mutate_at(c("adjcnt_White_M", "adjcnt_White_F",
                "adjcnt_Black_M", "adjcnt_Black_F",
                "adjcnt_other_M", "adjcnt_other_F"),
              ~ 100 * .x / adjcnt_a20_64) %>%
    mutate(mortAC01_03=mortAC2001+mortAC2002+mortAC2003,
           mortAC04_06=mortAC2004+mortAC2005+mortAC2006,
           mortAC02_04=mortAC2002+mortAC2003+mortAC2004,
           mortAC03_05=mortAC2003+mortAC2004+mortAC2005,
           mortAC01_02=mortAC2001+mortAC2002,
           mortAC03_04=mortAC2003+mortAC2004,
           mortAC05_06=mortAC2005+mortAC2006
           ) -> base_cnty
```

`base_cnty` is a private resource due to inclusion of years-specific
mortality. A version without those (not read in):


```r
counties <- read_csv(file.path("..", "extdata", "base_cnty0.csv")) %>%
    mutate(mass_cnty = (stateFIPS == "25")) %>%
    mutate_at(c("adjcnt_White_M", "adjcnt_White_F", "adjcnt_Black_M", "adjcnt_Black_F", "adjcnt_other_M", "adjcnt_other_F"), ~ 100 * .x / adjcnt_a20_64)
```

Private resource, propensity models fitted to these and some other data 
elements that I'm not permitted to share: 
<!-- from h-d-b-t/data/romneycare/baseline/R --> 


```r
load(file.path("..", "extdata", "baseline.RData"))
load(file.path("..", "extdata", "propensity_with_weights.RData"))
load("SLB_PS_variants.RData")# gives `stratifications`, `sglm{0,2}`, `pie_sglm{0,2}`
```




# PIC SE



```r
pie_sglm0
```

```
## pic_me_info object (a list) with `c(max_err, rms_err)`= c(8.57, 3.32)
```

Next we confirm that PIC SE comes out more or less the same
whether calculated by `ppse_via_qr()` vs directly from model artifacts. 


```r
vnms0  <- sglm0 %>% coef() %>%
    Filter(function(x) !is.na(x), .) %>%
    names() %>% setdiff("(Intercept)")
vnms2  <- sglm2 %>% coef() %>%
    Filter(function(x) !is.na(x), .) %>%
    names() %>% setdiff("(Intercept)")
base_cnty %>% dplyr::select(-stateFIPS, -cntyFIPS) %>%
    as.matrix() %>% cov() ->
    S_x
S_x_perp0  <- makeSperp(S_x[vnms0, vnms0], coef(sglm0)[vnms0])
all.equal(sqrt( sum( vcov(sglm0)[vnms0, vnms0] *
                     S_x_perp0 *
                     2 )
               ),
          pie_sglm0$rms_err
          )
```

```
## [1] "Mean relative difference: 0.000163"
```

```r
S_x_perp2  <- makeSperp(S_x[vnms2, vnms2], coef(sglm2)[vnms2])
all.equal(sqrt( sum( vcov(sglm2)[vnms2, vnms2] *
                     S_x_perp2 *
                     2 )
               ),
          pie_sglm2$rms_err
          )
```

```
## [1] "Mean relative difference: 0.00016"
```

## PIC SE-like quantity w/ paired covar diffs instead of \(S_x^\perp\)


For this we'll need the matrix of 14 paired differences on each of
the Xes.  Notation key:
  * `pm0__pdiffs` ~ differences within `pm_ppty0` pairs
  * `pm0e_pdiffs` ~ differences within `pm_ppty0_e` pairs


```r
pm0__pdiffs  <- stratifications[c("stateFIPS", "cntyFIPS", "pm_ppty0")] %>%
    left_join(base_cnty, by=c("stateFIPS", "cntyFIPS")) %>%
    dplyr::select(-stateFIPS, -cntyFIPS) %>%
    filter(!is.na(pm_ppty0)) %>%
    arrange(pm_ppty0, mass_cnty) %>%
    group_by(pm_ppty0) %>%
    summarise_all(diff) %>%
    column_to_rownames('pm_ppty0') %>%
    as.matrix()

pm0e_pdiffs  <- stratifications[c("stateFIPS", "cntyFIPS", "pm_ppty0_e")] %>%
    left_join(base_cnty, by=c("stateFIPS", "cntyFIPS")) %>%
    dplyr::select(-stateFIPS, -cntyFIPS) %>%
    filter(!is.na(pm_ppty0_e)) %>%
    arrange(pm_ppty0_e, mass_cnty) %>%
    group_by(pm_ppty0_e) %>%
    summarise_all(diff) %>%
    column_to_rownames('pm_ppty0_e') %>%
    as.matrix()

stopifnot( all(pm0__pdiffs[,"mass_cnty"]==1),
          all(pm0e_pdiffs[,"mass_cnty"]==1) )
```

We also save the analogue of cov(x) that only accounts for paired
(per `pm_ppty0`) differences in the xes. 


```r
S_x_pm <- 0.5 * crossprod(pm0__pdiffs)/nrow(pm0__pdiffs)
stopifnot(all(vnms0 %in% colnames(pm0__pdiffs)),
          all(vnms0 %in% colnames(pm0__pdiffs)))
```

PIC SE-like calculation using paired diffs instead of S-perp:


```r
sqrt( sum( vcov(sglm0)[vnms0, vnms0] *
           S_x_pm[vnms0, vnms0] *
           2 )
     )
```

```
## [1] 2.92
```

Compare to


```r
pie_sglm0$rms_err
```

```
## [1] 3.32
```

This says that the pairs selected by propensity pair matching
are a bit closer in X than randomly selected pairs would
have been.  (Despite X-differences of the randomly selected 
pair having been stripped of propensity score differences.)  
If they weren't, the discrepancy would be even larger:


```r
sqrt( sum( vcov(sglm0)[vnms0, vnms0] *
           S_x[vnms0, vnms0] *
           2 )
     )
```

```
## [1] 3.88
```


The same three calculations relative to `sglm2`, suppressing
code for space:


```
## paired  Sperp      S 
##   1.36   1.79   2.67
```

### Pooled s.d.'s in the scores

As scale for comparisons we calculate pooled sd's
of the two scores.  The calculations are made with 
weighting for county size. (Code suppressed in output.)


```r
c(s_p_ps0, s_p_ps2)
```

```
## [1] 2.37 2.00
```


## Simulations

In these simulations, the underlying propensity score is as
estimated with `sglm0`; there are two fixed pair matching
structures in the background, `pm_ppty0` and `pm_ppty0_e`. In 
each simulation the score is re-estimated on bootstrap samples, 
per the `sglm0` spec ("`ps0`") and also, separately, the spec 
of `sglm2` ("`ps2`").  Then we calculate l2 ("`rms_`") and 
l-inf ("`max_`") norms of bootstrap errors in paired propensity 
scores differences, across either the 14 `pm_ppty0` pairs or
the 14 `pm_ppty0_e` pairs.

### Helper functions

A bootstrap "statistic" function (code suppressed).



Some checks (code partly suppressed).


```r
index_pdiff_summary(base_cnty) %>% head(n=10)
```

```
## ps0_index_pm0__rms_ ps0_pic_e_pm0__rms_ ps0_index_pm0__max_ ps0_pic_e_pm0__max_ 
##              0.0487              0.0000              0.1278              0.0000 
## ps2_index_pm0__rms_ ps2_pic_e_pm0__rms_ ps2_index_pm0__max_ ps2_pic_e_pm0__max_ 
##              1.2583              0.0000              3.3792              0.0000 
## ps0_index_pm0e_rms_ ps0_pic_e_pm0e_rms_ 
##              0.1042              0.0000
```


Parametric simulator:


```r
make_parametric_sample_creator  <- function(a_glm) {

    resp_column  <- formula(a_glm)[[2]]
    resp_column  <- as.character(resp_column)
    a_glm_mf  <- model.frame(a_glm)
    stopifnot(resp_column %in% colnames(a_glm_mf),
              !is.factor(a_glm_mf[[resp_column]]),
              !is.matrix(a_glm_mf[[resp_column]])
              )
    tglm  <-  a_glm[c("coefficients", "family", "formula", "qr",
                      "rank", "terms", "xlevels")
                    ]
    function(data_, mle=NULL)
    {
        preds  <- suppressWarnings(predict.lm(tglm, newdata=data_))
        link_inv  <- tglm$family$linkinv
        preds  <- link_inv(preds)
        new_responses  <- rbinom(length(preds), 1,
                                 preds)
        data_[[resp_column]]  <- new_responses
        data_
        }
}
```

Define secondary helper utilities `add_colnames_to_boot()`, for
indexing of boot results, `paste_()` for `paste()` ops
with "`_`" as separator. (Code suppressed.)




### Simulation experiments



```r
param_smpl_creator  <- make_parametric_sample_creator(sglm0)
system.time(index_pdiff_boot  <-
                boot::boot(base_cnty, index_pdiff_summary, R=nreps, ncpus=ncores,
                           sim="parametric", ran.gen=param_smpl_creator
                           ) %>%
                add_colnames_to_boot()
            )
```

```
##    user  system elapsed 
##   153.0    12.7   171.6
```

### Inspecting simulation results

Bootstrap "truth":


```r
conditions  <- list(observation=c("index", "pic_e"),
                    metrics=c("rms_", "max_"),
                    pses=c("ps0", "ps2"),
                    match=c("pm0_", "pm0e")
                    )
K <- length(conditions)
index_pdiff_boot %>% .[['t0']] %>%
    head(n=2^K) %>%
    array(dim=sapply(conditions, length),
          dimnames=conditions) %>%
    ftable()
```

```
##                          match   pm0_   pm0e
## observation metrics pses                    
## index       rms_    ps0        0.0487 0.1042
##                     ps2        1.2583 0.9835
##             max_    ps0        0.1278 0.2451
##                     ps2        3.3792 2.6182
## pic_e       rms_    ps0        0.0000 0.0000
##                     ps2        0.0000 0.0000
##             max_    ps0        0.0000 0.0000
##                     ps2        0.0000 0.0000
```

```r
index_pdiff_boot %>% .[['t0']] %>% names() %>%
    str_subset("ps0_coef\\.")%>%
    index_pdiff_boot[['t0']][.] %>% head()
```

```
##     ps0_coef.a20_34     ps0_coef.a35_44     ps0_coef.a45_54       ps0_coef.male 
##             -0.2250             -0.2263             -0.8208             -1.8398 
## ps0_coef.white_race ps0_coef.black_race 
##             -0.0126             -0.1670
```

```r
index_pdiff_boot %>% .[['t0']] %>% names() %>%
    str_subset("ps2_coef\\.")%>%
    index_pdiff_boot[['t0']][.] %>% head()
```

```
##      ps2_coef.a45_54        ps2_coef.male  ps2_coef.black_race 
##              -0.3953              -1.8345              -0.1761 
##       ps2_coef.unins ps2_coef.mortAC02_04 ps2_coef.mortAC04_06 
##              -0.3906               0.0119              -0.0138
```

Calculate confidence intervals for simulation results (code suppressed)



Simulation RMS and maximum errors of paired differences
on propensity scores are as follows. 


```r
ftable(pdiff_bootmeans)
```

```
##                          match  pm0_  pm0e
## observation metrics pses                  
## index       rms_    ps0        2.846 1.559
##                     ps2        2.011 1.452
##             max_    ps0        8.250 3.409
##                     ps2        5.289 3.296
## pic_e       rms_    ps0        2.845 1.556
##                     ps2        1.493 0.979
##             max_    ps0        8.250 3.394
##                     ps2        3.895 2.279
```

```r
ftable(pdiff_bootmeans/s_p_ps0)
```

```
##                          match  pm0_  pm0e
## observation metrics pses                  
## index       rms_    ps0        1.202 0.658
##                     ps2        0.849 0.613
##             max_    ps0        3.483 1.439
##                     ps2        2.233 1.392
## pic_e       rms_    ps0        1.201 0.657
##                     ps2        0.630 0.413
##             max_    ps0        3.483 1.433
##                     ps2        1.645 0.962
```

```r
ftable(pdiff_bootmeanCIs/s_p_ps0)
```

```
##                                limit lower upper
## observation metrics pses match                  
## index       rms_    ps0  pm0_        1.175 1.228
##                          pm0e        0.648 0.669
##                     ps2  pm0_        0.837 0.861
##                          pm0e        0.606 0.620
##             max_    ps0  pm0_        3.382 3.585
##                          pm0e        1.414 1.465
##                     ps2  pm0_        2.187 2.279
##                          pm0e        1.371 1.412
## pic_e       rms_    ps0  pm0_        1.175 1.228
##                          pm0e        0.647 0.667
##                     ps2  pm0_        0.619 0.642
##                          pm0e        0.407 0.420
##             max_    ps0  pm0_        3.382 3.585
##                          pm0e        1.408 1.459
##                     ps2  pm0_        1.604 1.685
##                          pm0e        0.944 0.980
```

Cross-checks of rms_.  Using alternate route (details suppressed)
to same estimate of rms paired difference along ps0:


```
## estimate.mean of x          conf.int1          conf.int2 
##               2.85               2.78               2.91
```


## Standard PIC SE vs PIC SE w/ bootstrapped Cov(\(\hat\beta\))

First w/ sandwich estimation of Cov($\hat\beta$)
as per default, 


```r
pie_sglm0$rms_err ;
```

```
## [1] 3.32
```

and next using the bootstrap's Cov($\hat\beta$) estimate instead,



```r
( index_pdiff_boot %>% .[['t']] %>% .[,paste0("ps0_coef.", vnms0), drop=F] %>%
    cov() %>% '*'(S_x_perp0)%>%
    sum() %>% '*'(2) %>% sqrt() ->
    pie_sglm0$l2_boot )
```

```
## [1] 3.83
```

.  That is, bootstrapping the covariance imposed a factor of


```r
with(pie_sglm0, l2_boot / rms_err )
```

```
## [1] 1.16
```

.  This is for the PIC SE itself. Switching attn to
the calculation analogous to PIC SE using paired covariate
differences instead of all covariate differences, 
it misses the average of simulated rms paired
index differences by a factor of



```r
mean(index_pdiff_boot[['t']][, "ps0_pic_e_pm0__rms_", drop=T]) /
    sqrt( sum( vcov(sglm0)[vnms0, vnms0] * S_x_pm[vnms0, vnms0] * 2 ) )
```

```
## [1] 0.974
```

.






---
title: SLB_PS_sims.R
author: bbh
date: '2022-11-01'

---
