---
output:
    html_document: 
        keep_md: true
    md_document:
        variant: gfm
---
# Setup




Repetitions of simulation, when `pic_maxerr()` is applied to a factor


```r
if (!exists('nreps')) nreps <-100
nreps
```

```
## [1] 2000
```

```r
## The county data excluding year-specific mortality rates. 
```

```r
counties <- read_csv(file.path("..", "extdata", "base_cnty0.csv")) %>%
    mutate(mass_cnty = (stateFIPS == "25")) %>%
    mutate_at(c("adjcnt_White_M", "adjcnt_White_F", "adjcnt_Black_M", "adjcnt_Black_F", "adjcnt_other_M", "adjcnt_other_F"), ~ 100 * .x / adjcnt_a20_64)
```

Artifacts from script `SLB_PS_mod_variants.R`, some based on
restricted-use data resources.


```r
(load("SLB_PS_variants.RData"))
```

```
## [1] "sglm0"           "pie_sglm0"       "sglm2"           "pie_sglm2"      
## [5] "stratifications"
```

```r
stopifnot(all.equal(counties$stateFIPS, stratifications$stateFIPS),
          all.equal(counties$cntyFIPS, stratifications$cntyFIPS)
          )
```


Names of MA counties, per
https://en.wikipedia.org/wiki/List_of_counties_in_Massachusetts


```r
mass_counties  <-
    readr::read_tsv("../extdata/mass_cnty_fips.tsv",
                    col_types="ccc")
```

My abbreviations of MA county names


```r
mass_counties %>%
    mutate(cnty_abbrev=abbreviate(cnty_name, 2, method="both.sides")
           ) -> mass_counties
```


# Propensity scores

## SLB propensity score

One private resource that we've loaded in is a near-reproduction of the
SLB propensity score, `sglm0`.  The only difference, I think, has to do with the
origin of the `latino` variable: they took theirs from the AHRF, but the
more recent AHRF I was able to obtain didn't carry that variable in these 
years, so instead I took it from the county-level population data that NCHS
maintains alongside of the mortality data. 


```r
counties$ppty0 <- sglm0$linear.predictors
```

The PIC SE value of this score is:


```r
pie_sglm0
```

```
## pic_me_info object (a list) with `c(max_err, rms_err)`= c(8.57, 3.32)
```

The pooled s.d. of this score, calculated with weighting for county size:


```r
counties %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
  PISE:::standardization_scale(counties$ppty0, counties$mass_cnty, 
                               PISE:::svy_sd, .) -> s_p_sglm0 
s_p_sglm0
```

```
## [1] 2.37
```

quite a bit smaller than the PIC SE.  It reflects within-group
propensity dispersion as follows.
Ranges and medians of both groups:


```r
counties %>% group_by(mass_cnty) %>%
    dplyr::select(ppty0) %>%
        summarise(min=min(ppty0), med=median(ppty0), max=max(ppty0))
```

```
## # A tibble: 2 × 4
##   mass_cnty   min   med   max
##   <lgl>     <dbl> <dbl> <dbl>
## 1 FALSE     -61.8 -8.84 7.62 
## 2 TRUE      -13.6 -2.09 0.908
```

Treatment group mean and s.d. (weighted):


```r
counties %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    subset(!!mass_cnty) %>% survey::svymean(~ppty0, .) %>% 
  .[["ppty0"]]
```

```
## [1] -1.66
```

```r
counties %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    subset(!!mass_cnty) %>% survey::svyvar(~ppty0, .) %>% 
  .[["ppty0"]] %>% sqrt()
```

```
## [1] 1.42
```

Comparison reservoir mean and s.d. (weighted):


```r
counties %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    subset(!mass_cnty) %>% survey::svymean(~ppty0, .) %>% 
  .[["ppty0"]]
```

```
## [1] -7.76
```

```r
counties %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    subset(!mass_cnty) %>% survey::svyvar(~ppty0, .) %>% 
  .[["ppty0"]] %>% sqrt()
```

```
## [1] 4.4
```

Unweighted root-mean square of paired PS differences:


```r
with(counties, c(max_err=diff(range(ppty0)) , rms_err=sqrt(2*var(ppty0)))
)
```

```
## max_err rms_err 
##   69.45    9.96
```


... or, as a multiple of the pooled s.d., 


```r
with(counties, sqrt(2*var(ppty0))/s_p_sglm0)
```

```
## [1] 4.21
```

 RMS and max of paired index error, simulated


```r
( pie_ps0__sglm0  <-
      pic_maxerr(character(nrow(counties)), x=pie_sglm0, nreps=nreps) )
```

```
## pic_me_info object (a list) with `c(max_err, rms_err)`= c(34.3, 3.88)
```


### SLB propensity score subsetting

Per SLB,

> we used propensity scores to define a control group of counties
> in nonreform states that were most similar to prereform
> Massachusetts counties. We estimated propensity scores...
> The quartile of counties with the highest propensity scores,
> indicating the closest match to the overall population of
> Massachusetts's 14 counties, was used as the control group
> in the mortality analysis.

I take this to mean the following.


```r
counties %>% dplyr::filter(mass_cnty==0) %>% 
    survey::svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    survey::svyquantile(~ppty0,.,quantiles=0.75) %>%
    .[[1]] %>% .[1] -> 
    cutoff 
```

`ps0_trim` combines treatment counties with controls
falling above the cutoff.


```r
counties$ps0_trim  <- stratifications$ps0_trim
```

RMS and max of paired index error, simulated


```r
( pie_ps0_trim_sglm0  <-
      pic_maxerr(counties$ps0_trim, x=pie_sglm0, nreps=nreps) )
```

```
## pic_me_info object (a list) with `c(max_err, rms_err)`= c(22.6, 2.51)
```


### Balance check for SLB trim, and associated subclassifications

The subclassifications:


```r
counties$ps0_strat0  <- cut(counties$ppty0,
                            c(ppty0_median-pie_sglm0$max_err,
                              ppty0_median,
                              ppty0_median+pie_sglm0$max_err),
                            include.lowest=T)
counties$ps0_strat1  <- cut(log10(counties$a20_64_cnt),
                            c(0, logpop_1stdecile, 10)
                            ) %>% factor(labels=c("tiny", "_")) %>%
    interaction(counties$ps0_strat0, .)
with(counties, table(mass_cnty, ps0_strat1))
```

```
##          ps0_strat1
## mass_cnty [-15.7,-7.15].tiny (-7.15,1.41].tiny [-15.7,-7.15]._ (-7.15,1.41]._
##     FALSE                983               539             523            605
##     TRUE                   2                 0               0             12
```

```r
counties$ps0_strat2  <- cut(log10(counties$a20_64_cnt),
                            c(0, logpop_median, logpop_1stdecile, 10)
                            ) %>% factor(labels=c("sm", "med", "lg")) %>%
    interaction(counties$ps0_strat0, .)
with(counties, table(mass_cnty, ps0_strat2))
```

```
##          ps0_strat2
## mass_cnty [-15.7,-7.15].sm (-7.15,1.41].sm [-15.7,-7.15].med (-7.15,1.41].med
##     FALSE              983             539               438              492
##     TRUE                 2               0                 0                4
##          ps0_strat2
## mass_cnty [-15.7,-7.15].lg (-7.15,1.41].lg
##     FALSE               85             113
##     TRUE                 0               8
```

For each subclassification, identify subclasses that are "concordant", i.e. either
have no treatment group members or no controls; then set their subclass status to NA
(to encode leaving these observations out of the analysis).


```r
counties["ps0_strat0"]  <- concordant_to_NA("ps0_strat0")
counties["ps0_strat1"]  <- concordant_to_NA("ps0_strat1")
counties["ps0_strat2"]  <- concordant_to_NA("ps0_strat2")
```


The balance check.  


```r
covariates_SLB <-
    c("a20_34", "a35_44", "a45_54", "a55_64",
      "male", "white_race", "black_race", "other_race", "latino",
      "pov", "inc", "unemp", "unins", "mortAC_20_64")
covariates_SLB %>% 
    paste(collapse="+") %>% paste("mass_cnty ~", ., "-1+strata(ps0_trim)+strata(ps0_strat0)+strata(ps0_strat1)+strata(ps0_strat2)") %>%
    as.formula() %>%
    balanceTest(counties, unit.weights=a20_64_cnt) |>
                print(which.stats=c("Treatment", "Control"))
```

```
##              strata():  ps0_trim         ps0_strat0         ps0_strat1         ps0_strat2        
##              stat      Treatment Control  Treatment Control  Treatment Control  Treatment Control
## vars                                                                                             
## a20_34                     33      33         33      34         33      33         33      34   
## a35_44                     26      26         26      26         26      26         26      26   
## a45_54                     24      24         24      24         24      24         24      24   
## a55_64                     16      17         16      17         16      17         16      16   
## male                       49      49         49      49         49      49         49      49   
## white_race                 87      85         87      83         87      83         87      79   
## black_race                  7       9          7      10          7      10          7      12   
## other_race                 5.6     5.8        5.6     6.4        5.6     6.8        5.6     8.7  
## latino                      7.3     7.5        7.3     9.5        7.3     8.8        7.3    11.1 
## pov                         9.6    10.3        9.6    11.1        9.6    10.6        9.6    10.6 
## inc                        63290   59317      63290   57191      63290   59084      63290   61535
## unemp                      5.0     5.1        5.0     5.3        5.0     5.2        5.0     5.2  
## unins                      14      14         14      17         14      16         14      16   
## mortAC_20_64               283     299        283     318        283     308        283     297  
## ---Overall Test---
##            chisquare df p.value
## ps0_trim          86 13 8.7e-13
## ps0_strat0       144 13 3.0e-24
## ps0_strat1       100 13 2.0e-15
## ps0_strat2        29 13 6.7e-03
```

Differences of means as they appear here are consistent with what SLB
had reported, and are relatively small. Nonetheless, balance as the
*hypothesis* of indistinguishable propensity scores is squarely rejected. 

The overall test results are to be interpreted in light of that test's
also paying indirect attention to county population size, which is out
of balance. 



```r
counties %>% dplyr::filter(!is.na(ps0_trim)) %>% 
  group_by(mass_cnty) %>% summarise(mean(a20_64_cnt))
```

```
## # A tibble: 2 × 2
##   mass_cnty `mean(a20_64_cnt)`
##   <lgl>                  <dbl>
## 1 FALSE                 82997.
## 2 TRUE                 277764.
```

But as we've seen, paying basic attention to size helps but doesn't
fix the balance problem. Accordingly we'll consider some variations
on their propensity model as well.  But first, bring one more
factor into the stratification.

### sglm0 stratifications with PC1 of dilated cov matrix

The dilated cov matrix being $X \tilde{C}^{1/2}$, where
$\tilde{C}^{1/2}$ is a Cholesky factor of $\hat{C}_{\hat\beta}$.



```r
pie_sglm0$chol_cov_beta  <- chol(pie_sglm0$cov.betahat, pivot=TRUE)
pie_sglm0$chol_cov_beta  <-
    pie_sglm0$chol_cov_beta[,order(attr(pie_sglm0$chol_cov_beta, "pivot"))]
pie_sglm0$svd_dilated_X  <- with(pie_sglm0, svd(tcrossprod(X, chol_cov_beta)))
counties$ps0_pc1  <- pie_sglm0$svd_dilated_X$u[,1]
```


New subclassifications:

- 3_t is built on ps0_trim
- 3_0 is built on ps0_strat0 (trim + 2 ps subclasses)
- 3_2 is built on ps0_strat2 (ps0_strat0 crossed w/ 3 size levels)


```r
mass_range0  <- counties %>%
    filter(mass_cnty) %>%
    with(range(ps0_pc1)) %>%
    rbind(mass_range0, ps0_pc1=.)
ps0_pc1_cutpoints  <-
    seq(from=mass_range0["ps0_pc1", "min"]-0.0015,
            to=mass_range0["ps0_pc1", "max"]+0.0015,
            length.out=4)
counties$ps0_pc1_strat_  <-
    cut(counties$ps0_pc1,
       ps0_pc1_cutpoints,
       include.lowest=TRUE)
counties$ps0_strat3_t  <-  
    interaction(counties$ps0_trim, counties$ps0_pc1_strat_ )
counties$ps0_strat3_0  <-  
    interaction(counties$ps0_strat0, counties$ps0_pc1_strat_ )
counties$ps0_strat3_2  <-  
    interaction(counties$ps0_strat2, counties$ps0_pc1_strat_ )
```



![](SLB_PS_repro+pc1_files/figure-html/pc1_by_ppty0_scatter-1.png)<!-- -->


 RMS and max index errors for these stratifications.


```r
( pie_ps0_strat3_t_sglm0  <-
      pic_maxerr(counties$ps0_strat3_t, x=pie_sglm0, nreps=nreps) )
```

```
## pic_me_info object (a list) with `c(max_err, rms_err)`= c(7.49, 1.38)
```

```r
( pie_ps0_strat3_0_sglm0  <-
      pic_maxerr(counties$ps0_strat3_0, x=pie_sglm0, nreps=nreps) )
```

```
## pic_me_info object (a list) with `c(max_err, rms_err)`= c(11.1, 1.75)
```

```r
( pie_ps0_strat3_2_sglm0  <-
      pic_maxerr(counties$ps0_strat3_2, x=pie_sglm0, nreps=nreps) )
```

```
## pic_me_info object (a list) with `c(max_err, rms_err)`= c(11, 1.93)
```

For comparison purposes, RMS and max index errors for the
stratification those were built upon.


```r
pie_ps0_trim_sglm0
```

```
## pic_me_info object (a list) with `c(max_err, rms_err)`= c(22.6, 2.51)
```

```r
( pie_ps0_strat0_sglm0 <-
      pic_maxerr(counties$ps0_strat0, x=pie_sglm0, nreps=nreps) )
```

```
## pic_me_info object (a list) with `c(max_err, rms_err)`= c(25, 2.86)
```

```r
( pie_ps0_strat2_sglm0 <-
      pic_maxerr(counties$ps0_strat2, x=pie_sglm0, nreps=nreps) )
```

```
## pic_me_info object (a list) with `c(max_err, rms_err)`= c(20.2, 3.08)
```


Balance for the new stratifications


```r
covariates_SLB %>% 
    paste(collapse="+") %>%
    paste("mass_cnty ~", .,
          "-1+strata(ps0_trim)+strata(ps0_strat3_t)+strata(ps0_strat3_0)+strata(ps0_strat3_2)"
          ) %>%
    as.formula() %>%
    balanceTest(counties, unit.weights=a20_64_cnt) |>
                print(which.stats=c("Treatment", "Control"))
```

```
##              strata():  ps0_trim         ps0_strat3_t         ps0_strat3_0         ps0_strat3_2        
##              stat      Treatment Control    Treatment Control    Treatment Control    Treatment Control
## vars                                                                                                   
## a20_34                     33      33           33      32           33      32           33      32   
## a35_44                     26      26           26      26           26      26           26      26   
## a45_54                     24      24           24      25           24      25           24      25   
## a55_64                     16      17           16      17           16      17           16      17   
## male                       49      49           49      49           49      49           49      49   
## white_race                 87      85           87      90           87      87           87      84   
## black_race                 7.0     9.0          7.0     5.2          7.0     7.4          7.0     9.7  
## other_race                 5.6     5.8          5.6     4.3          5.6     5.3          5.6     6.6  
## latino                      7.3     7.5          7.3     6.5          7.3     9.5          7.3    10.7 
## pov                         9.6    10.3          9.6     9.0          9.6    10.2          9.6     9.5 
## inc                        63290   59317        63290   61643        63290   59387        63290   64913
## unemp                      5.0     5.1          5.0     4.9          5.0     5.2          5.0     5.1  
## unins                      14      14           14      14           14      16           14      16   
## mortAC_20_64               283     299          283     292          283     313          283     294  
## ---Overall Test---
##              chisquare df p.value
## ps0_trim            86 13 8.7e-13
## ps0_strat3_t        98 13 3.7e-15
## ps0_strat3_0       160 13 1.8e-27
## ps0_strat3_2        34 13 1.2e-03
```


# Propensity score pair matches

Convenience function


```r
lInf_and_l2 <- function(x) c(`lInf`=max(abs(x)), `l2`=sqrt(mean(x^2)))
```

## Matching on a single index

`pm_ppty0` is a pair match on the following distance.


```r
ppty0_dist  <- 
    match_on(counties$ppty0, z=counties$mass_cnty,
             data=counties)
counties$pm_ppty0  <- stratifications$pm_ppty0
counties$pm_ppty0 %>% matched.distances(ppty0_dist) %>% unlist() %>% 
  lInf_and_l2()
```

```
##   lInf     l2 
## 0.1278 0.0487
```

To interpret, recall that


```r
s_p_sglm0 ; pie_sglm0
```

```
## [1] 2.37
```

```
## pic_me_info object (a list) with `c(max_err, rms_err)`= c(8.57, 3.32)
```




```r
( pie_pm_ppty0  <- pic_maxerr(counties$pm_ppty0, x=pie_sglm0, nreps=nreps) )
```

```
## pic_me_info object (a list) with `c(max_err, rms_err)`= c(5.01, 2.92)
```

## Matching on index plus paired index SE

Pair match on ppty0, within calipers of
a PIC SE enhanced ppty0 distance, and also
± 1 in log base 10 of population.


```r
counties$pm_ppty0_e  <- stratifications$pm_ppty0_e
counties$pm_ppty0_e %>%
    matched.distances(ppty0_dist) %>%
    lInf_and_l2()
```

```
##  lInf    l2 
## 0.245 0.104
```

```r
( pie_pm_ppty0_e  <- pic_maxerr(counties$pm_ppty0_e, x=pie_sglm0, nreps=nreps) )
```

```
## pic_me_info object (a list) with `c(max_err, rms_err)`= c(2.49, 1.47)
```

Full matching on ppty0 within calipers
on `ppty0`, on corresponding pair-specific sglm0 SE's,
and logpop. 


```r
counties$fm_ppty0_e <- stratifications$fm_ppty0_e
```

Info about this match (NB: lInf and l2 are understated, 
only consider T-C pairs):


```r
summary(counties$fm_ppty0_e)
```

```
## Structure of matched sets:
##  1:1  1:2 1:5+  0:1 
##    2    1   11  250 
## Effective Sample Size:  24.5 
## (equivalent number of matched pairs).
```

```r
counties$fm_ppty0_e %>%
    matched.distances(ppty0_dist) %>% unlist() %>%
    lInf_and_l2()
```

```
## lInf   l2 
## 8.51 2.67
```

```r
( pie_fm_ppty0_e  <- pic_maxerr(counties$fm_ppty0_e, x=pie_sglm0, nreps=nreps) )
```

```
## pic_me_info object (a list) with `c(max_err, rms_err)`= c(17.1, 2.83)
```

Balance:


```r
covariates_SLB %>% 
    paste(collapse="+") %>%
    paste("mass_cnty ~", ., "-1+strata(pm_ppty0_e)+strata(fm_ppty0_e)") %>%
    as.formula() %>%
    balanceTest(counties, unit.weights=a20_64_cnt) |>
                print(which.stats=c("Treatment", "Control"))
```

```
##              strata(): pm_ppty0_e         fm_ppty0_e        
##              stat       Treatment Control  Treatment Control
## vars                                                        
## a20_34                      33      33         33      37   
## a35_44                      26      27         26      26   
## a45_54                      24      24         24      22   
## a55_64                      16      16         16      15   
## male                        49      49         49      50   
## white_race                  87      91         87      77   
## black_race                   7.0     4.9        7.0    10.0 
## other_race                   5.6     4.4        5.6    13.1 
## latino                       7.3     6.4        7.3    32.4 
## pov                          9.6     8.7        9.6    14.5 
## inc                         63290   64198      63290   54670
## unemp                       5.0     4.7        5.0     5.7  
## unins                       14      12         14      24   
## mortAC_20_64                283     262        283     279  
## ---Overall Test---
##            chisquare df p.value
## pm_ppty0_e        13 13    0.43
## fm_ppty0_e        19 13    0.13
```

(Covariate-level imbalances are made better or worse, depending on the covariate.  The p-value increases, but this is plausibly a function of the decrease in effective sample size.)

# Wrapup
Store generated artifacts for use elsewhere


```r
stratifications  <- counties %>%
    dplyr::select(stateFIPS, cntyFIPS, mass_cnty, a20_64_cnt,
           ppty0, 
           ps0_trim, ps0_strat2,
           ps0_strat3_t,
           ps0_strat3_0,
           ps0_strat3_2,
           pm_ppty0, 
           pm_ppty0_e, fm_ppty0_e)
save(sglm0, pie_sglm0,
     pie_ps0_strat3_t_sglm0,
     pie_ps0_strat3_0_sglm0,
     pie_ps0_strat3_2_sglm0,
     stratifications,  file="SLB_PS_repro+pc1.RData")
```




```r
sessionInfo()
```

```
## R version 4.2.1 (2022-06-23)
## Platform: x86_64-apple-darwin17.0 (64-bit)
## Running under: macOS Big Sur ... 10.16
## 
## Matrix products: default
## BLAS:   /Library/Frameworks/R.framework/Versions/4.2/Resources/lib/libRblas.0.dylib
## LAPACK: /Library/Frameworks/R.framework/Versions/4.2/Resources/lib/libRlapack.dylib
## 
## locale:
## [1] en_US.UTF-8/en_US.UTF-8/en_US.UTF-8/C/en_US.UTF-8/en_US.UTF-8
## 
## attached base packages:
## [1] grid      stats     graphics  grDevices utils     datasets  methods  
## [8] base     
## 
## other attached packages:
##  [1] forcats_0.5.1   stringr_1.4.0   dplyr_1.0.8     purrr_0.3.4    
##  [5] readr_2.1.2     tidyr_1.2.0     tibble_3.1.6    tidyverse_1.3.1
##  [9] survey_4.1-1    Matrix_1.4-1    optmatch_0.10.0 survival_3.3-1 
## [13] PISE_0.2.0.9004 RItools_0.3-1   ggplot2_3.3.5  
## 
## loaded via a namespace (and not attached):
##  [1] svd_0.5.1        httr_1.4.2       sass_0.4.1       bit64_4.0.5     
##  [5] vroom_1.5.7      jsonlite_1.8.0   splines_4.2.1    modelr_0.1.8    
##  [9] bslib_0.3.1      assertthat_0.2.1 rlemon_0.2.0     highr_0.9       
## [13] cellranger_1.1.0 yaml_2.3.5       pillar_1.7.0     backports_1.4.1 
## [17] lattice_0.20-45  glue_1.6.2       digest_0.6.29    rvest_1.0.2     
## [21] colorspace_2.0-3 sandwich_3.0-1   htmltools_0.5.2  pkgconfig_2.0.3 
## [25] broom_0.7.12     SparseM_1.81     haven_2.4.3      xtable_1.8-4    
## [29] scales_1.2.0     tzdb_0.3.0       generics_0.1.2   ellipsis_0.3.2  
## [33] withr_2.5.0      cli_3.2.0        magrittr_2.0.3   crayon_1.5.1    
## [37] readxl_1.4.0     evaluate_0.15    fs_1.5.2         fansi_1.0.3     
## [41] xml2_1.3.3       tools_4.2.1      hms_1.1.1        mitools_2.4     
## [45] lifecycle_1.0.1  munsell_0.5.0    reprex_2.0.1     compiler_4.2.1  
## [49] jquerylib_0.1.4  rlang_1.0.2      rstudioapi_0.13  rmarkdown_2.14  
## [53] gtable_0.3.0     abind_1.4-5      DBI_1.1.2        R6_2.5.1        
## [57] zoo_1.8-10       lubridate_1.8.0  knitr_1.38       bit_4.0.4       
## [61] fastmap_1.1.0    utf8_1.2.2       stringi_1.7.6    parallel_4.2.1  
## [65] Rcpp_1.0.8.3     vctrs_0.4.1      dbplyr_2.1.1     tidyselect_1.1.2
## [69] xfun_0.30
```


# Ancillary explorations
## Full matching not pair matching

Optimal full matching, excluding counties as necessary to 
ensure close matching everywhere. 


```r
fullmatch(ppty0_dist + caliper(ppty0_dist, width=0.25 * s_p_sglm0),
          data=counties, 
          ) -> counties$fm_ppty0
```


Excludes treatment group counties?


```r
summary(counties$fm_ppty0)
```

```
## Structure of matched sets:
##  1:1  1:2 1:5+  0:1 
##    1    1   12 2309 
## Effective Sample Size:  24.8 
## (equivalent number of matched pairs).
```

How close a caliper is possible without dropping treatment group members? It depends
on which score of course. The answer for `sglm0`:


```r
( ppty0_dist_summ  <- summary(ppty0_dist) )
```

```
## Membership: 14 treatment, 3127 control
## Total eligible potential matches: 43778 
## Total ineligible potential matches: 0 
## 
## Summary of minimum matchable distance per treatment member:
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
##  0.0000  0.0032  0.0113  0.0271  0.0233  0.1278
```

```r
ppty0_dist_summ$distances['Max.']/s_p_sglm0
```

```
##   Max. 
## 0.0539
```

```r
ppty0_dist %>% match_on(caliper= 0.05 * s_p_sglm0) %>%
    fullmatch( data=counties ) %>% summary()
```

```
## Structure of matched sets:
##  1:0  1:1  1:3  1:4 1:5+  0:1 
##    2    1    1    1    9 2889 
## Effective Sample Size:  21.1 
## (equivalent number of matched pairs).
```

```r
ppty0_dist %>% match_on(caliper= 0.06 * s_p_sglm0) %>%
    fullmatch( data=counties ) %>% summary()
```

```
## Structure of matched sets:
##  1:1  1:3  1:4 1:5+  0:1 
##    3    1    1    9 2855 
## Effective Sample Size:  23.1 
## (equivalent number of matched pairs).
```

```r
ppty0_dist %>% match_on(caliper= 0.06 * s_p_sglm0) %>%
    fullmatch( data=counties ) -> counties$fm_ppty0  
```



---
title: SLB_PS_repro+pc1.R
author: bbh
date: '2022-11-01'

---
