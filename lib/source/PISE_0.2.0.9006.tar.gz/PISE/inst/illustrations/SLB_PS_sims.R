##' ---
##' output:
##'     html_document: 
##'         keep_md: true
##'     md_document:
##'         variant: gfm
##' ---
##' # Setup
##' 
##+ setup, echo=FALSE, warning=FALSE, message=FALSE
knitr::opts_chunk$set(warning=FALSE, message=FALSE, error=FALSE, echo=TRUE)
libloc <- file.path("..", "..", ".local", 
                    R.Version()$platform, 
                    paste(R.Version()$major,
                          strsplit(R.Version()$minor, ".", 
                                   fixed=T)[[1]][1],
                          sep=".")
                    )
withr::with_libpaths(libloc, library("RItools"),
                     action="prefix")
stopifnot(packageVersion("RItools") >= '0.2.0.9004')
withr::with_libpaths(libloc, library("PISE"),
                     action="prefix")
stopifnot( packageVersion("PISE") >= '0.1.0.9004' )
library(optmatch)
library(tidyverse)
library(survey)
##'
##+ simsetup
set.seed(202104)
if (!exists('nreps')) nreps  <- 3
if (!exists("ncores")) ncores  <- 3
c(nreps=nreps, ncores=ncores)
##' Private resource: county data with year specific mortality, `base_cnty`.
##+ datasetup, echo=1, cache=2
read_csv(file.path("..", "extdata", "base_cnty.csv")) %>%
    mutate(mass_cnty = (stateFIPS == "25"),
           a20_44=a20_34+a35_44,
           a45_64=a45_54+a55_64) %>%
    mutate_at(c("adjcnt_White_M", "adjcnt_White_F",
                "adjcnt_Black_M", "adjcnt_Black_F",
                "adjcnt_other_M", "adjcnt_other_F"),
              ~ 100 * .x / adjcnt_a20_64) %>%
    mutate(mortAC01_03=mortAC2001+mortAC2002+mortAC2003,
           mortAC04_06=mortAC2004+mortAC2005+mortAC2006,
           mortAC02_04=mortAC2002+mortAC2003+mortAC2004,
           mortAC03_05=mortAC2003+mortAC2004+mortAC2005,
           mortAC01_02=mortAC2001+mortAC2002,
           mortAC03_04=mortAC2003+mortAC2004,
           mortAC05_06=mortAC2005+mortAC2006
           ) -> base_cnty
##' `base_cnty` is a private resource due to inclusion of years-specific
##' mortality. A version without those (not read in):
##+ eval=FALSE
counties <- read_csv(file.path("..", "extdata", "base_cnty0.csv")) %>%
    mutate(mass_cnty = (stateFIPS == "25")) %>%
    mutate_at(c("adjcnt_White_M", "adjcnt_White_F", "adjcnt_Black_M", "adjcnt_Black_F", "adjcnt_other_M", "adjcnt_other_F"), ~ 100 * .x / adjcnt_a20_64)
##' Private resource, propensity models fitted to these and some other data 
##' elements that I'm not permitted to share: 
##' <!-- from h-d-b-t/data/romneycare/baseline/R --> 
##+ 
load(file.path("..", "extdata", "baseline.RData"))
load(file.path("..", "extdata", "propensity_with_weights.RData"))
load("SLB_PS_variants.RData")# gives `stratifications`, `sglm{0,2}`, `pie_sglm{0,2}`
##' 
##' 
##'
##' # PIC SE
##'
##+
pie_sglm0
##' Next we confirm that PIC SE comes out more or less the same
##' whether calculated by `ppse_via_qr()` vs directly from model artifacts. 
##+
vnms0  <- sglm0 %>% coef() %>%
    Filter(function(x) !is.na(x), .) %>%
    names() %>% setdiff("(Intercept)")
vnms2  <- sglm2 %>% coef() %>%
    Filter(function(x) !is.na(x), .) %>%
    names() %>% setdiff("(Intercept)")
base_cnty %>% dplyr::select(-stateFIPS, -cntyFIPS) %>%
    as.matrix() %>% cov() ->
    S_x
S_x_perp0  <- makeSperp(S_x[vnms0, vnms0], coef(sglm0)[vnms0])
all.equal(sqrt( sum( vcov(sglm0)[vnms0, vnms0] *
                     S_x_perp0 *
                     2 )
               ),
          pie_sglm0$rms_err
          )
S_x_perp2  <- makeSperp(S_x[vnms2, vnms2], coef(sglm2)[vnms2])
all.equal(sqrt( sum( vcov(sglm2)[vnms2, vnms2] *
                     S_x_perp2 *
                     2 )
               ),
          pie_sglm2$rms_err
          )

##' ## PIC SE-like quantity w/ paired covar diffs instead of \(S_x^\perp\)
##'
##' 
##' For this we'll need the matrix of 14 paired differences on each of
##' the Xes.  Notation key:
##'   * `pm0__pdiffs` ~ differences within `pm_ppty0` pairs
##'   * `pm0e_pdiffs` ~ differences within `pm_ppty0_e` pairs
##+ echo=-1
stopifnot(all( setdiff(colnames(model.matrix(sglm0)),
                       "(Intercept)"
                       ) %in%
               colnames(base_cnty) ),
          all( setdiff(colnames(model.matrix(sglm2)),
                       "(Intercept)"
                       ) %in%
               colnames(base_cnty) )
          )
pm0__pdiffs  <- stratifications[c("stateFIPS", "cntyFIPS", "pm_ppty0")] %>%
    left_join(base_cnty, by=c("stateFIPS", "cntyFIPS")) %>%
    dplyr::select(-stateFIPS, -cntyFIPS) %>%
    filter(!is.na(pm_ppty0)) %>%
    arrange(pm_ppty0, mass_cnty) %>%
    group_by(pm_ppty0) %>%
    summarise_all(diff) %>%
    column_to_rownames('pm_ppty0') %>%
    as.matrix()

pm0e_pdiffs  <- stratifications[c("stateFIPS", "cntyFIPS", "pm_ppty0_e")] %>%
    left_join(base_cnty, by=c("stateFIPS", "cntyFIPS")) %>%
    dplyr::select(-stateFIPS, -cntyFIPS) %>%
    filter(!is.na(pm_ppty0_e)) %>%
    arrange(pm_ppty0_e, mass_cnty) %>%
    group_by(pm_ppty0_e) %>%
    summarise_all(diff) %>%
    column_to_rownames('pm_ppty0_e') %>%
    as.matrix()

stopifnot( all(pm0__pdiffs[,"mass_cnty"]==1),
          all(pm0e_pdiffs[,"mass_cnty"]==1) )

##' We also save the analogue of cov(x) that only accounts for paired
##' (per `pm_ppty0`) differences in the xes. 
S_x_pm <- 0.5 * crossprod(pm0__pdiffs)/nrow(pm0__pdiffs)
stopifnot(all(vnms0 %in% colnames(pm0__pdiffs)),
          all(vnms0 %in% colnames(pm0__pdiffs)))
##' PIC SE-like calculation using paired diffs instead of S-perp:
##+
sqrt( sum( vcov(sglm0)[vnms0, vnms0] *
           S_x_pm[vnms0, vnms0] *
           2 )
     )
##' Compare to
##+
pie_sglm0$rms_err
##' This says that the pairs selected by propensity pair matching
##' are a bit closer in X than randomly selected pairs would
##' have been.  (Despite X-differences of the randomly selected 
##' pair having been stripped of propensity score differences.)  
##' If they weren't, the discrepancy would be even larger:
##+
sqrt( sum( vcov(sglm0)[vnms0, vnms0] *
           S_x[vnms0, vnms0] *
           2 )
     )
##'
##' The same three calculations relative to `sglm2`, suppressing
##' code for space:
##+ echo=FALSE
c(paired=sqrt( sum( vcov(sglm2)[vnms2, vnms2] *
           S_x_pm[vnms2, vnms2] *
           2 )
           ),
  Sperp=pie_sglm2$rms_err,
  S=sqrt( sum( vcov(sglm2)[vnms2, vnms2] *
           S_x[vnms2, vnms2] *
           2 )
         )
  )
##' ### Pooled s.d.'s in the scores
##'
##' As scale for comparisons we calculate pooled sd's
##' of the two scores.  The calculations are made with 
##' weighting for county size. (Code suppressed in output.)
##+ echo=-(1:2)
s_p_ps0  <- stratifications %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    PISE:::standardization_scale(stratifications$ppty0,
                                 stratifications$mass_cnty, 
                                 PISE:::svy_sd, .)
s_p_ps2  <- stratifications %>% 
    svydesign(id=~1, weights=~a20_64_cnt, data=.) %>%
    PISE:::standardization_scale(stratifications$ppty2,
                                 stratifications$mass_cnty, 
                                 PISE:::svy_sd, .)

c(s_p_ps0, s_p_ps2)

##'
##' ## Simulations
##'
##' In these simulations, the underlying propensity score is as
##' estimated with `sglm0`; there are two fixed pair matching
##' structures in the background, `pm_ppty0` and `pm_ppty0_e`. In 
##' each simulation the score is re-estimated on bootstrap samples, 
##' per the `sglm0` spec ("`ps0`") and also, separately, the spec 
##' of `sglm2` ("`ps2`").  Then we calculate l2 ("`rms_`") and 
##' l-inf ("`max_`") norms of bootstrap errors in paired propensity 
##' scores differences, across either the 14 `pm_ppty0` pairs or
##' the 14 `pm_ppty0_e` pairs.
##'
##' ### Helper functions
##' 
##' A bootstrap "statistic" function (code suppressed).
##+ index_pdiff_summary, echo=FALSE, cache=2
index_pdiff_summary  <- function(cnties, indices=1L:nrow(cnties)) {
    coeffs0_t  <- coef(sglm0)
    coeffs2_t  <- coef(sglm2)
    coeffs0_t  <- coeffs0_t[names(coeffs0_t)!="(Intercept)"]
    coeffs2_t  <- coeffs2_t[names(coeffs2_t)!="(Intercept)"]
    ## paired differences on model 0 true score
    ps0_pm0__tdiffs  <- pm0__pdiffs[,names(coeffs0_t)] %*% coeffs0_t
    ps0_pm0__tdiffs  <- drop(ps0_pm0__tdiffs)
    ps0_pm0e_tdiffs  <- pm0e_pdiffs[,names(coeffs0_t)] %*% coeffs0_t
    ps0_pm0e_tdiffs  <- drop(ps0_pm0e_tdiffs)
    ## paired differences on model 2 true score
    ps2_pm0__tdiffs  <- pm0__pdiffs[,names(coeffs2_t)] %*% coeffs2_t
    ps2_pm0__tdiffs  <- drop(ps2_pm0__tdiffs)
    ps2_pm0e_tdiffs  <- pm0e_pdiffs[,names(coeffs2_t)] %*% coeffs2_t
    ps2_pm0e_tdiffs  <- drop(ps2_pm0e_tdiffs)

    dat  <- cnties[indices,]
    des <- survey::svydesign(id=~1, weights=~a20_64_cnt, data=dat)
    mod0  <- update(sglm0, design=des, data=dat)
    mod2  <- update(sglm2, design=des, data=dat)
    coeffs0  <- coef(mod0)
    coeffs2  <- coef(mod2)
    coeffs0  <- coeffs0[names(coeffs0)!="(Intercept)"]
    coeffs2  <- coeffs2[names(coeffs2)!="(Intercept)"]

    ## paired differences on model 0 est'd score
    ps0_pm0__idiffs  <- pm0__pdiffs[,names(coeffs0)] %*% coeffs0
    ps0_pm0__idiffs  <- drop(ps0_pm0__idiffs)
    ps0_pm0e_idiffs  <- pm0e_pdiffs[,names(coeffs0)] %*% coeffs0
    ps0_pm0e_idiffs  <- drop(ps0_pm0e_idiffs)
    ## paired differences on model 2 est'd score
    ps2_pm0__idiffs  <- pm0__pdiffs[,names(coeffs2)] %*% coeffs2
    ps2_pm0__idiffs  <- drop(ps2_pm0__idiffs)
    ps2_pm0e_idiffs  <- pm0e_pdiffs[,names(coeffs2)] %*% coeffs2
    ps2_pm0e_idiffs  <- drop(ps2_pm0e_idiffs)

    ## paired index errors
    ps0_pm0__pie <- ps0_pm0__idiffs - ps0_pm0__tdiffs
    ps2_pm0__pie <- ps2_pm0__idiffs - ps2_pm0__tdiffs
    ps0_pm0e_pie <- ps0_pm0e_idiffs - ps0_pm0e_tdiffs
    ps2_pm0e_pie <- ps2_pm0e_idiffs - ps2_pm0e_tdiffs

    c(ps0_index_pm0__rms_=sqrt(mean(ps0_pm0__idiffs^2)),
      ps0_pic_e_pm0__rms_=sqrt(mean(ps0_pm0__pie^2)),
      ps0_index_pm0__max_=max(abs(ps0_pm0__idiffs)),
      ps0_pic_e_pm0__max_=max(abs(ps0_pm0__pie)),
      ps2_index_pm0__rms_=sqrt(mean(ps2_pm0__idiffs^2)),
      ps2_pic_e_pm0__rms_=sqrt(mean(ps2_pm0__pie^2)),
      ps2_index_pm0__max_=max(abs(ps2_pm0__idiffs)),
      ps2_pic_e_pm0__max_=max(abs(ps2_pm0__pie)),
      ps0_index_pm0e_rms_=sqrt(mean(ps0_pm0e_idiffs^2)),
      ps0_pic_e_pm0e_rms_=sqrt(mean(ps0_pm0e_pie^2)),
      ps0_index_pm0e_max_=max(abs(ps0_pm0e_idiffs)),
      ps0_pic_e_pm0e_max_=max(abs(ps0_pm0e_pie)),
      ps2_index_pm0e_rms_=sqrt(mean(ps2_pm0e_idiffs^2)),
      ps2_pic_e_pm0e_rms_=sqrt(mean(ps2_pm0e_pie^2)),
      ps2_index_pm0e_max_=max(abs(ps2_pm0e_idiffs)),
      ps2_pic_e_pm0e_max_=max(abs(ps2_pm0e_pie)),
      ps0_coef=coeffs0, ps2_coef=coeffs2)
}
##' Some checks (code partly suppressed).
##+ echo=1
index_pdiff_summary(base_cnty) %>% head(n=10)
## Comparison to by-hand version:
crossprod(coef(sglm0)[vnms0],
          S_x_pm[vnms0, vnms0] %*% coef(sglm0)[vnms0]
          ) %>% .[1,1] %>% '*'(2) %>% sqrt() %>% 
    all.equal(index_pdiff_summary(base_cnty)['ps0_index_pm0__rms_'],
          check.attributes=FALSE) %>%
    isTRUE() %>% stopifnot()
##'
##' Parametric simulator:
##+ make_parametric_sample_creator, cache=2
make_parametric_sample_creator  <- function(a_glm) {

    resp_column  <- formula(a_glm)[[2]]
    resp_column  <- as.character(resp_column)
    a_glm_mf  <- model.frame(a_glm)
    stopifnot(resp_column %in% colnames(a_glm_mf),
              !is.factor(a_glm_mf[[resp_column]]),
              !is.matrix(a_glm_mf[[resp_column]])
              )
    tglm  <-  a_glm[c("coefficients", "family", "formula", "qr",
                      "rank", "terms", "xlevels")
                    ]
    function(data_, mle=NULL)
    {
        preds  <- suppressWarnings(predict.lm(tglm, newdata=data_))
        link_inv  <- tglm$family$linkinv
        preds  <- link_inv(preds)
        new_responses  <- rbinom(length(preds), 1,
                                 preds)
        data_[[resp_column]]  <- new_responses
        data_
        }
}
##' Define secondary helper utilities `add_colnames_to_boot()`, for
##' indexing of boot results, `paste_()` for `paste()` ops
##' with "`_`" as separator. (Code suppressed.)
##' 
##+ echo=FALSE
add_colnames_to_boot  <- function(theboot) {
    stopifnot(inherits(theboot, "boot"))
    colnames(theboot$t)  <- names(theboot$t0)
    theboot
}
paste_  <- function (..., collapse = NULL, recycle0 = FALSE) 
{
    if (isTRUE(recycle0)) 
        .Internal(paste(list(...), "_", collapse, recycle0))
    else .Internal(paste(list(...), "_", collapse))
}

##' ### Simulation experiments
##' 
##+ index_pdiff_boot, cache=2, warning=TRUE, dependson=c("index_pdiff_summary", "make_parametric_sample_creator", "datasetup")
param_smpl_creator  <- make_parametric_sample_creator(sglm0)
system.time(index_pdiff_boot  <-
                boot::boot(base_cnty, index_pdiff_summary, R=nreps, ncpus=ncores,
                           sim="parametric", ran.gen=param_smpl_creator
                           ) %>%
                add_colnames_to_boot()
            )
##' ### Inspecting simulation results
##' 
##' Bootstrap "truth":
##+ echo=-(3:4)
conditions  <- list(observation=c("index", "pic_e"),
                    metrics=c("rms_", "max_"),
                    pses=c("ps0", "ps2"),
                    match=c("pm0_", "pm0e")
                    )
K <- length(conditions)
index_pdiff_boot %>% .[['t0']] %>%
    head(n=2^K) %>% names() %>%
    all.equal(with(do.call(expand.grid, conditions),
                   paste_(pses, observation, match, metrics)
                   )
              ) %>% isTRUE() %>%
    stopifnot()

index_pdiff_boot %>% .[['t0']] %>%
    head(n=2^K) %>%
    array(dim=sapply(conditions, length),
          dimnames=conditions) %>%
    ftable()
index_pdiff_boot %>% .[['t0']] %>% names() %>%
    str_subset("ps0_coef\\.")%>%
    index_pdiff_boot[['t0']][.] %>% head()
index_pdiff_boot %>% .[['t0']] %>% names() %>%
    str_subset("ps2_coef\\.")%>%
    index_pdiff_boot[['t0']][.] %>% head()

##' Calculate confidence intervals for simulation results (code suppressed)
##+ echo=FALSE
pdiff_bootmeans  <-
    array(NA_real_, sapply(conditions, length))
pdiff_bootmeanCIs  <-
    array(NA_real_, dim=c(sapply(conditions, length), 2))
dimnames(pdiff_bootmeans)  <- conditions
dimnames(pdiff_bootmeanCIs)  <-
    c(conditions, list(limit=c("lower", "upper")))
for (theps in conditions$pses)
    for (themetric in conditions$metrics)
        for (theobs in conditions$observation)        
            for (thepairing in conditions$match)
    {
        pdiff_bootmeans[theobs, themetric, theps, thepairing]  <-
            index_pdiff_boot %>% .[['t']] %>%
            .[, paste_(theps, theobs, thepairing, themetric), drop=T] %>%
            mean()
        pdiff_bootmeanCIs[theobs, themetric, theps, thepairing, ]  <-
            index_pdiff_boot %>% .[['t']] %>%
            .[, paste_(theps, theobs, thepairing, themetric), drop=T] %>%
            t.test() %>%
            .[c('conf.int')] %>% unlist()
        }
##' Simulation RMS and maximum errors of paired differences
##' on propensity scores are as follows. 
ftable(pdiff_bootmeans)
ftable(pdiff_bootmeans/s_p_ps0)
ftable(pdiff_bootmeanCIs/s_p_ps0)
##' Cross-checks of rms_.  Using alternate route (details suppressed)
##' to same estimate of rms paired difference along ps0:
##+ echo=FALSE
index_pdiff_boot %>% .[['t0']] %>% names() %>%
    str_subset("ps0_coef\\.")%>%
    setdiff(paste0("ps0_coef.", colnames(pm0__pdiffs))) %>%
    identical(character(0)) %>%
    stopifnot() #confirm expectation about alignment
index_pdiff_boot %>% .[['t']] %>%
    .[, paste0("ps0_coef.", vnms0), drop=F] %>%
(function(beta_matrix)
    rowSums( (beta_matrix %*% S_x_pm[vnms0, vnms0]) * beta_matrix)
) %>%
    '*'(2) %>% sqrt() %>%
    t.test() %>% .[c('estimate', 'conf.int')] %>% unlist()
##' 
##' ## Standard PIC SE vs PIC SE w/ bootstrapped Cov(\(\hat\beta\))
##' 
##' First w/ sandwich estimation of Cov($\hat\beta$)
##' as per default, 
##+
pie_sglm0$rms_err ;
##' and next using the bootstrap's Cov($\hat\beta$) estimate instead,
##' 
##+
( index_pdiff_boot %>% .[['t']] %>% .[,paste0("ps0_coef.", vnms0), drop=F] %>%
    cov() %>% '*'(S_x_perp0)%>%
    sum() %>% '*'(2) %>% sqrt() ->
    pie_sglm0$l2_boot )
##' .  That is, bootstrapping the covariance imposed a factor of
##+
with(pie_sglm0, l2_boot / rms_err )
##' .  This is for the PIC SE itself. Switching attn to
##' the calculation analogous to PIC SE using paired covariate
##' differences instead of all covariate differences, 
##' it misses the average of simulated rms paired
##' index differences by a factor of
##' 
mean(index_pdiff_boot[['t']][, "ps0_pic_e_pm0__rms_", drop=T]) /
    sqrt( sum( vcov(sglm0)[vnms0, vnms0] * S_x_pm[vnms0, vnms0] * 2 ) )
##' .
##' 
##+ echo=FALSE, eval=FALSE
## scraps/remnants
