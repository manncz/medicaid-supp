---
title: PISEs for Gurm et al 2013 study
author: BH
output:
    html_document:
        keep_md: true
    md_document:
        variant: gfm
---

## Preliminaries












































