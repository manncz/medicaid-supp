---
output:
    html_document:
        keep_md: true
    md_document:
        variant: gfm
---
# Setup







```r
set.seed(202103)
bootfuns  <- list()
refit_nbmods  <- TRUE
```

How many replicates?


```r
if (!exists('nreps')) nreps  <- 3
if (!exists('ncores')) ncores  <- 3
c(nreps=nreps, ncores=ncores)
```

```
##  nreps ncores 
##   2000      3
```

```r
perms  <- perms1step  <- list()
```

Data readin (hidden in output)...




Function to make the function performing the calculations to be
permuted.  (That generated function will have to require its
first argument `dat` to have been stripped in advance of rows
that are NA for the stratifying variable.)


```r
make_negbin_null_estfun_statistic_fn  <- function(strat)
{
    stopifnot(is.character(strat), 
              any(strat==colnames(stratifications))
              )
    bal_fmla  <-  c("a20_34", "a35_44", "a45_54", "a55_64",
      "male", "white_race", "black_race", "other_race", "latino",
      "pov", "inc", "unemp", "unins", "mortAC_20_64") %>% 
        paste(collapse="+") %>%
        paste("mass_cnty ~", ., "-1+strata(", strat,")") %>%
        as.formula()
    resp_fmla  <- paste("deathsAC ~ race + sex + agegrp + pov + inc +",
               "unemp + pct_latino + year + stateFIPS +",
               strat, "+ offset(log(pop))") %>% as.formula()

    counties_  <- counties %>% # remove vars also carried in stratifications, since
        dplyr::select(-mass_cnty, -a20_64_cnt) # it's to be joined with that table

    stratifications[!is.na(stratifications[[strat]]),
                    c(strat, "stateFIPS", "cntyFIPS")
                    ] %>%
        left_join(yrly_cnty_subgrps, by=c("stateFIPS", "cntyFIPS")) -> 
        yrly_cnty_subgrps_
        
    nbmod0  <- glm.nb(resp_fmla, data=yrly_cnty_subgrps_)

    intercept_scores  <- sandwich::estfun(nbmod0)[,"(Intercept)", drop=F]
    colnames(intercept_scores)  <- "intercept_scores"
    stopifnot(is.null(na.action(nbmod0))) # (were they presented, NAs would call for more verbose code)
    strat_  <- rlang::syms(strat)
    yrly_cnty_subgrps_  %>% cbind(intercept_scores) %>%
        filter(year>2005) %>%
        group_by(!!!strat_, stateFIPS, cntyFIPS) %>%
        summarise(q=sum(intercept_scores)) ->
        q_table
    ## now mean-center by stratum.  (had we not subsetted to post-2005 period,
    ## stratum-mean centering would have been enforced by model fit.) 
    q_table %>% ungroup() %>%
        group_by(!!!strat_) %>%
        mutate(q_centered=(q-mean(q))) %>%
        ungroup()  -> q_table

    yrly_cnty_subgrps_  <-
        yrly_cnty_subgrps_[, -which(colnames(yrly_cnty_subgrps_)==strat)]
    
    theta0  <- nbmod0$theta
    coef0  <- coef(nbmod0)
    coef0[is.na(coef0)]  <- 0

    function(dat, indices) {
        dat[["mass_cnty"]]  <- dat[indices, 'mass_cnty', drop=TRUE]

        counties__ <-  counties_ %>%
        right_join(dat, by=c("stateFIPS", "cntyFIPS")) 
        balanceTest(bal_fmla, data=counties__,
                    unit.weights=a20_64_cnt,
                    report="chisq"
                    )$overall[1,] ->
                        bal

        q_table  <- left_join(dat, q_table, by=c("stateFIPS", "cntyFIPS"))
        ztq  <- with(q_table, sum(mass_cnty * q_centered))
        ztq_over_l2zq  <- ztq/
            with(q_table, sqrt(sum(mass_cnty * q_centered^2)) )
        
        
        dat %>%  left_join(yrly_cnty_subgrps_, by=c("stateFIPS", "cntyFIPS")) %>%
        mutate(mass_reform= (mass_cnty & year>2005)
               ) -> yrly_cnty_subgrps__

        suppressWarnings(
            nb_1step  <- glm(update(resp_fmla, .~.+mass_reform),
                         data=yrly_cnty_subgrps__,
                         family=negative.binomial(theta=theta0),
                         start=c(coef0, "mass_reform"=0),
                         control=glm.control(maxit=1)
                         )
            )
        coef_1step  <- coef(nb_1step)["mass_reformTRUE"]
        vcov_nbmod  <- vcov(nb_1step)["mass_reformTRUE", "mass_reformTRUE"]
        vcov_state  <- sandwich::vcovCL(nb_1step, cluster=yrly_cnty_subgrps__$stateFIPS, type="HC1")
        vcov_cnty  <- sandwich::vcovCL(nb_1step, cluster=paste0(yrly_cnty_subgrps__$stateFIPS,
                                                                 yrly_cnty_subgrps__$cntyFIPS),
                                       type="HC1")
        tstat_nbmod  <- coef_1step/sqrt(vcov_nbmod)
        tstatHC1_state  <- coef_1step/sqrt(vcov_state["mass_reformTRUE","mass_reformTRUE"])
        tstatHC1_cnty  <- coef_1step/sqrt(vcov_cnty["mass_reformTRUE","mass_reformTRUE"])        
        tstat_nbmod  <- unname(tstat_nbmod)
        tstatHC1_state  <- unname(tstatHC1_state)
        tstatHC1_cnty  <- unname(tstatHC1_cnty)
        
        raotest  <- stats:::anova.glm(nbmod0, nb_1step, test="Rao")
        c(bal, ztq=ztq, ztq_over_l2zq=ztq_over_l2zq,
          coef_1step, tstat_nbmod=tstat_nbmod,
          tstatCL_state=tstatHC1_state, tstatCL_cnty=tstatHC1_cnty,
          rao.chisq=raotest[2,"Rao"],
          rao.pval=raotest[2,"Pr(>Chi)"])
    }
}
make_negbin_refitter_statistic_fn  <- function(strat) {
    stopifnot(is.character(strat), 
              any(strat==colnames(stratifications)))
    resp_fmla  <- paste("deathsAC ~ race + sex + agegrp + pov + inc +",
               "unemp + pct_latino + year + stateFIPS +",
               strat, "+ offset(log(pop))") %>% as.formula()
    stratifications_  <- stratifications[!is.na(stratifications[[strat]]),]
    yrly_cnty_subgrps_  <- stratifications_ %>%
        left_join(yrly_cnty_subgrps, by=c("stateFIPS", "cntyFIPS")) 
    nbmod0  <- glm.nb(resp_fmla, data=yrly_cnty_subgrps_)

    function(dat, indices) {
        dat[['mass_cnty']]  <- dat[indices, 'mass_cnty']
        dat %>%  left_join(yrly_cnty_subgrps, by=c("stateFIPS", "cntyFIPS")) %>%
        mutate(mass_reform= (mass_cnty & year>2005),
               year=as.character(year)
               ) -> newdat
    
    nbmod_new  <- try(update(nbmod0,
                         formula=update(formula(nbmod0), .~.+mass_reform),
                         data=newdat
                         ),
                  silent=TRUE)

        if (inherits(nbmod_new, "try-error"))
            return(c(coef=NA_real_, tstatCL_state=NA_real_, tstatCL_cnty=NA_real_,
                     pseudo_mass=which(unlist(dat[["mass_cnty"]])))
                   )

        thecoef  <- coef(nbmod_new)["mass_reformTRUE"]
        vcov_state  <- sandwich::vcovCL(nbmod_new, cluster=newdat$stateFIPS, type="HC1")
        vcov_cnty  <- sandwich::vcovCL(nbmod_new, cluster=paste0(newdat$stateFIPS, newdat$cntyFIPS), type="HC1")
        tstatHC1_state  <- thecoef/sqrt(vcov_state["mass_reformTRUE","mass_reformTRUE"])        
        tstatHC1_cnty  <- thecoef/sqrt(vcov_cnty["mass_reformTRUE","mass_reformTRUE"])
        tstatHC1_state  <- unname(tstatHC1_state)
        tstatHC1_cnty  <- unname(tstatHC1_cnty)
        c(thecoef, tstatCL_state=tstatHC1_state, tstatCL_cnty=tstatHC1_cnty,
          pseudo_mass=which(unlist(dat[["mass_cnty"]]))
          )
        }
    }
```

Run simulations

With sample trimmed a la SLB:


```r
bootfuns$onestep_ps0_trim  <- make_negbin_null_estfun_statistic_fn("ps0_trim")
system.time(
perms1step$ps0_trim  <-
    boot::boot(stratifications[!is.na(stratifications$ps0_trim),],
               bootfuns$onestep_ps0_trim,
               R=nreps, 
               sim="permutation", parallel="multicore", ncpus=ncores)
)
```

```
##    user  system elapsed 
##   14155    5964    5500
```




```r
bootfuns$refit_ps0_trim <- make_negbin_refitter_statistic_fn("ps0_trim")
system.time(
perms$ps0_trim  <- boot::boot(stratifications[!is.na(stratifications$ps0_trim),],
                     bootfuns$refit_ps0_trim,
               R=nreps, 
               sim="permutation", parallel="multicore", ncpus=ncores)
)
```

```
##    user  system elapsed 
##  125454   36352   48134
```

With trimming and stratification per trimmed propensity score:


```r
bootfuns$onestep_ps2_strat2  <- make_negbin_null_estfun_statistic_fn("ps2_strat2")
system.time(
perms1step$ps2_strat2  <-
    boot::boot(stratifications[!is.na(stratifications$ps2_strat2),],
               bootfuns$onestep_ps2_strat2,
               R=nreps, strata=na.omit(stratifications$ps2_strat2),
               sim="permutation", parallel="multicore", ncpus=ncores)
)
```

```
##    user  system elapsed 
##   25155    9318    9472
```




```r
bootfuns$refit_ps2_strat2 <- make_negbin_refitter_statistic_fn("ps2_strat2")
system.time(
perms$ps2_strat2  <- boot::boot(stratifications[!is.na(stratifications$ps2_strat2),],
                     bootfuns$refit_ps2_strat2,
               R=nreps, strata=na.omit(stratifications$ps2_strat2),
               sim="permutation", parallel="multicore", ncpus=ncores)
)
```

```
##    user  system elapsed 
##  230790   63728   87509
```

Using a full match within `ps2_strat2` to define permutations, while
fitting same model to same sample as in `ps2_strat2`. (Since `boot()` can't deal
with NAs in the stratifying variable, we define a convenience function
`na_to_singleton()`, code suppressed, to convert them to singleton strata.)



```r
system.time(
perms1step$fm_ppty0_e  <-
    boot::boot(stratifications[!is.na(stratifications$ps2_strat2),],
               bootfuns$onestep_ps2_strat2,
               strata=na_to_singleton(stratifications[!is.na(stratifications$ps2_strat2),
                                                      "fm_ppty0_e", drop=TRUE]
                                      ),
               R=nreps, 
               sim="permutation", parallel="multicore", ncpus=ncores)
)
```

```
##    user  system elapsed 
##   24913    8984    9441
```

```r
system.time(
perms$fm_ppty0_e  <- boot::boot(stratifications[!is.na(stratifications$ps2_strat2),],
                     bootfuns$refit_ps2_strat2,
               R=nreps,
               strata=na_to_singleton(stratifications[!is.na(stratifications$ps2_strat2),
                                                      "fm_ppty0_e", drop=TRUE]
                                      ),
               sim="permutation", parallel="multicore", ncpus=ncores)
)
```

```
##    user  system elapsed 
##  226594   63025   85655
```

Save it


```r
save(perms, perms1step, file="SLB_PS_permutations.RData")
```

Back-translate saved county IDs from row numbers into FIPS codes.
Of necessity, coded with type numeric.
TO DO: fold this into bootstrap statistic function. 


```r
tmp <-
    with(stratifications[!is.na(stratifications$ps0_trim),],
         as.numeric(paste0(stateFIPS,cntyFIPS))
         )[perms$ps0_trim$t[,-(1:3)]]
perms$ps0_trim$t[,-(1:3)]   <- tmp
tmp <-
    with(stratifications[!is.na(stratifications$ps2_strat2),],
         as.numeric(paste0(stateFIPS,cntyFIPS))
         )[perms$ps2_strat2$t[,-(1:3)]]
perms$ps2_strat2$t[,-(1:3)]  <- tmp
rm(tmp)
```

I find it annoying that the matrix of bootstrapped statistics doesn't have column
names.


```r
add_colnames_boot  <- function(theboot) {
    stopifnot(inherits(theboot, "boot"))
    colnames(theboot$t)  <- names(theboot$t0)
    theboot
}
perms  <- lapply(perms, add_colnames_boot)
perms1step  <-  lapply(perms1step, add_colnames_boot)
```


Save it again:


```r
save(perms, perms1step, file="SLB_PS_permutations.RData")
```

## P values

### Permutation inference on null negbin fit & associated artifacts

#### SLB-style trimmed sample, no stratification

One-sided p-values:


```r
mean(is.na(perms1step$ps0_trim$t[,"mass_reformTRUE"])) -> na_rate_
if (na_rate_) na_rate_
mean(perms1step$ps0_trim$t[,"mass_reformTRUE"]
     <
     perms1step$ps0_trim$t0["mass_reformTRUE"],
     na.rm=na_rate_)
```

```
## [1] 0.24
```

```r
mean(is.na(perms1step$ps0_trim$t[,"tstatCL_cnty"])) -> na_rate_
if (na_rate_) na_rate_
mean(perms1step$ps0_trim$t[,"tstatCL_cnty"]
     <
     perms1step$ps0_trim$t0["tstatCL_cnty"],
     na.rm=na_rate_)
```

```
## [1] 0.0645
```

```r
mean(is.na(perms1step$ps0_trim$t[,"ztq"])) -> na_rate_
if (na_rate_) na_rate_
mean(perms1step$ps0_trim$t[,"ztq"]
     <
     perms1step$ps0_trim$t0["ztq"],
     na.rm=na_rate_)
```

```
## [1] 0.261
```

```r
mean(is.na(perms1step$ps0_trim$t[,"ztq_over_l2zq"])) -> na_rate_
if (na_rate_) na_rate_
mean(perms1step$ps0_trim$t[,"ztq_over_l2zq"]
     <
     perms1step$ps0_trim$t0["ztq_over_l2zq"],
     na.rm=na_rate_)
```

```
## [1] 0.316
```

... and a permutation version of the (2-sided) Rao test
p-value:


```r
mean(is.na(perms1step$ps0_trim$t[,"rao.chisq"])) -> na_rate_
if (na_rate_) na_rate_
mean(perms1step$ps0_trim$t[,"rao.chisq"]
     >
     perms1step$ps0_trim$t0["rao.chisq"],
     na.rm=na_rate_)
```

```
## [1] 0.496
```

#### Subclasses after trimming the SLB score

One-sided p-values:


```r
mean(is.na(perms1step$ps2_strat2$t[,"mass_reformTRUE"])) -> na_rate_
if (na_rate_) na_rate_
mean(perms1step$ps2_strat2$t[,"mass_reformTRUE"]
     <
     perms1step$ps2_strat2$t0["mass_reformTRUE"],
     na.rm=na_rate_)
```

```
## [1] 0.239
```

```r
mean(is.na(perms1step$ps2_strat2$t[,"tstatCL_cnty"])) -> na_rate_
if (na_rate_) na_rate_
mean(perms1step$ps2_strat2$t[,"tstatCL_cnty"]
     <
     perms1step$ps2_strat2$t0["tstatCL_cnty"],
     na.rm=na_rate_)
```

```
## [1] 0.0385
```

```r
mean(is.na(perms1step$ps2_strat2$t[,"ztq"])) -> na_rate_
if (na_rate_) na_rate_
mean(perms1step$ps2_strat2$t[,"ztq"]
     <
     perms1step$ps2_strat2$t0["ztq"],
     na.rm=na_rate_)
```

```
## [1] 0.39
```

```r
mean(is.na(perms1step$ps2_strat2$t[,"ztq_over_l2zq"])) -> na_rate_
if (na_rate_) na_rate_
mean(perms1step$ps2_strat2$t[,"ztq_over_l2zq"]
     <
     perms1step$ps2_strat2$t0["ztq_over_l2zq"],
     na.rm=na_rate_)
```

```
## [1] 0.322
```

... and a permutation version of the (2-sided) Rao test
p-value:


```r
mean(is.na(perms1step$ps2_strat2$t[,"rao.chisq"])) -> na_rate_
if (na_rate_) na_rate_
mean(perms1step$ps2_strat2$t[,"rao.chisq"]
     >
     perms1step$ps2_strat2$t0["rao.chisq"],
     na.rm=na_rate_)
```

```
## [1] 0.539
```


and using permutations within matched sets (within `ppty2`/size strata):


```r
mean(is.na(perms1step$fm_ppty0_e$t[,"mass_reformTRUE"])) -> na_rate_
if (na_rate_) na_rate_
mean(perms1step$fm_ppty0_e$t[,"mass_reformTRUE"]
     <
     perms1step$fm_ppty0_e$t0["mass_reformTRUE"],
     na.rm=na_rate_)
```

```
## [1] 0.258
```

```r
mean(is.na(perms1step$fm_ppty0_e$t[,"tstatCL_cnty"])) -> na_rate_
if (na_rate_) na_rate_
mean(perms1step$fm_ppty0_e$t[,"tstatCL_cnty"]
     <
     perms1step$fm_ppty0_e$t0["tstatCL_cnty"],
     na.rm=na_rate_)
```

```
## [1] 0.045
```


### With re-fitting of negbin model at each permutation

Thus one-sided p-values are, for the SLB sample trim,


```r
mean(perms$ps0_trim$t[,"mass_reformTRUE"]
     <
     perms$ps0_trim$t0["mass_reformTRUE"],
     na.rm=na_rate_)
```

```
## [1] 0.264
```

```r
mean(perms$ps0_trim$t[,"tstatCL_cnty"]
     <
     perms$ps0_trim$t0["tstatCL_cnty"],
     na.rm=na_rate_)
```

```
## [1] 0.076
```


and for the stratification based on `ppty2` and size, 


```r
mean(perms$ps2_strat2$t[,"mass_reformTRUE"]
     <
     perms$ps2_strat2$t0["mass_reformTRUE"],
     na.rm=na_rate_)
```

```
## [1] 0.213
```

```r
mean(perms$ps2_strat2$t[,"tstatCL_cnty"]
     <
     perms$ps2_strat2$t0["tstatCL_cnty"],
     na.rm=na_rate_)
```

```
## [1] 0.0445
```

and using permutations within matched sets (within `ppty2`/size strata):


```r
mean(perms$fm_ppty0_e$t[,"mass_reformTRUE"]
     <
     perms$fm_ppty0_e$t0["mass_reformTRUE"],
     na.rm=na_rate_)
```

```
## [1] 0.272
```

```r
mean(perms$fm_ppty0_e$t[,"tstatCL_cnty"]
     <
     perms$fm_ppty0_e$t0["tstatCL_cnty"],
     na.rm=na_rate_)
```

```
## [1] 0.0565
```

To address the puzzle of why it seems to be more difficult to 
achieve significance with the coefficient as test statistic 
as opposed to the corresponding t-statistic, let's look at a 
characteristics of pseudo-treatment group(s) associating 
with extreme coefficents but less extreme t-statistics. First
we identify such a group.


```r
min(perms1step$ps2_strat2$t[,"tstatCL_cnty"])
```

```
## [1] -4.93
```

```r
( t_stat_2.5tile  <-
      quantile(perms1step$ps2_strat2$t[,"tstatCL_cnty"], probs=0.025) )
```

```
##  2.5% 
## -2.76
```

```r
min_coef_moderate_tstat  <- which.min(
    (perms1step$ps2_strat2$t[,"tstatCL_cnty"] < t_stat_2.5tile)
    *
    perms1step$ps2_strat2$t[,"mass_reformTRUE"]
)
```

So the extreme coefficient accompanying a non-extreme t-statistic is:


```r
perms1step$ps2_strat2$t[min_coef_moderate_tstat,"mass_reformTRUE"]
```

```
## mass_reformTRUE 
##          -0.134
```

Balance associating with this group:


```r
perms1step$ps2_strat2$t[min_coef_moderate_tstat,
                       c("chisquare", "df", "p.value")
                       ]
```

```
## chisquare        df   p.value 
##   26.7662   13.0000    0.0134
```

Hmm.  To visualize on a plot, we repeat with the full-refit permutations.


```r
min(perms$ps2_strat2$t[,"tstatCL_cnty"])
```

```
## [1] -6.53
```

```r
( t_stat_2.5tile  <-
      quantile(perms$ps2_strat2$t[,"tstatCL_cnty"], probs=0.025) )
```

```
##  2.5% 
## -2.87
```

```r
min_coef_moderate_tstat  <- which.min(
    (perms$ps2_strat2$t[,"tstatCL_cnty"] < t_stat_2.5tile)
    *
    perms$ps2_strat2$t[,"mass_reformTRUE"]
)
perms$ps2_strat2$t[min_coef_moderate_tstat,"mass_reformTRUE"]
```

```
## mass_reformTRUE 
##          -0.135
```

The counties constituting that pseudo-treatment group:


```r
odd_pseudo_mass2.5  <-
    perms$ps2_strat2$t[min_coef_moderate_tstat,
    substr(names(perms$ps2_strat2$t0),1,11)=="pseudo_mass"
    ]  %>% stringr::str_pad(width=5)
```

Now let's look at it on a plot.  Preliminary calcs `mass_range2`, ...
are copied from SLB_PS_variant.R and suppressed from output.



(Basic plot also copied from SLB_PS_variant.R.)


```r
plot(log10(a20_64_cnt) ~ ppty2, type="n",
     xlim=c(min(qtiles2["ppty2",1], mass_range2["ppty2",1]),
            max(qtiles2["ppty2",2], mass_range2["ppty2",2])
            ),
     ylim=c(min(qtiles2["log10(a20_64_cnt)", 1], mass_range2["logpop", 1]),
            max(qtiles2["log10(a20_64_cnt)", 2], mass_range2["logpop", 2])
            ),
     data=stratifications,
     main="US Counties", xlab="trimmed propensity (ppty2)",  ylab="log10(pop. aged 20-64)"
     )
stratifications %>% filter(!mass_cnty) %>%
    with(points(ppty2, log10(a20_64_cnt), pch=3, col="red", cex=0.1))
stratifications %>% filter(mass_cnty) %>%
    with(points(ppty2, log10(a20_64_cnt), pch=21, col="blue", bg="blue"))
abline(v=ppty2_cutpoints, col="lightgray")
abline(h=c(logpop_median, logpop_1stdecile), col="lightgray")
## annotate pseudo-mass
stratifications %>% mutate(FIPS=paste0(stateFIPS, cntyFIPS)) %>%
    filter(FIPS %in% odd_pseudo_mass2.5) %>%
    with(points(ppty2, log10(a20_64_cnt), pch=21, col="red", bg="red"))
```

![](SLB_PS_permutations_files/figure-html/unnamed-chunk-22-1.png)<!-- -->



---
title: SLB_PS_permutations.R
author: bbh
date: '2021-08-02'

---
