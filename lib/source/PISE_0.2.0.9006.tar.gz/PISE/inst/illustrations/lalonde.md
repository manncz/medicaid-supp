Might get data from lalonde package, 
devtools::install_github("jjchern/lalonde")
https://github.com/jjchern/lalonde

