library(testthat)
library(PISE)

test_check("PISE")
