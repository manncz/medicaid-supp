context("Internals supporting pic_stderr sims")

test_that("Pairwise combinations within a block", {
    indices_all_pairs(c(1L,3L)) |>
    expect_is("data.frame")

    indices_all_pairs(c(1L,3L)) |>
    colnames() |>
    expect_equal(c("i", "j"))
    
    indices_all_pairs(c(1L,3L)) |>
    unlist() |> unname() |> sort() |> 
    expect_identical(c(1L,3L))

    indices_bipartite_pairs(c(1L,-3L)) |>
    expect_is("data.frame")

    indices_bipartite_pairs(c(1L,-3L)) |>
    colnames() |>
    expect_equal(c("i", "j"))
    
    indices_bipartite_pairs(c(1L,-3L)) |>
    unlist() |> sort() |>
    expect_identical(c(i=1L, j=3L))
    
    indices_bipartite_pairs(c(1L:2L,-3L)) |>
    nrow() |> expect_equal(2)

    indices_bipartite_pairs(c(1L:2L,-3L:-4L)) |>
    nrow() |> expect_equal(4)

    indices_bipartite_pairs(c(1L:2L,0L, -3L)) |>
    expect_identical(indices_bipartite_pairs(c(1L:2L,-3L)))

    indices_bipartite_pairs(c(1L:2L,0L)) |>
    nrow() |> expect_equal(0)
})

test_that("Pairwise combinations from a factor",{
    afac  <- factor(rep(c('a', 'b'), c(2,3)))
    atrt  <- rep_len(c(TRUE, FALSE), 5)

    doubletons_within_strata_of(afac) |>
    expect_is("data.frame")

    doubletons_within_strata_of(afac) |>
    nrow() |> expect_equal(4)

    comparisons_within_strata_of(afac, atrt) |>
    expect_is("data.frame")

    comparisons_within_strata_of(afac, atrt) |>
    nrow() |> expect_equal(3)
})
