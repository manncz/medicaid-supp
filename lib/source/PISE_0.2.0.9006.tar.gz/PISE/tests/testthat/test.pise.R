#source("../../R/ppse.R")
#stopifnot(require("testthat"))

data(nuclearplants, package="optmatch")
aglm <- glm(pr~.-cost, data=nuclearplants, family=binomial)

context("expectations regarding functions external to this package")

test_that("glm output", {
    expect_false(is.null(aglm$qr))
})

test_that("glm.fit's non-update of weights at last stage",
### this documents the reason for `pic_stderr.qr` not to just pull weights from the fitted model object
          {
              expect_false(isTRUE(all.equal(getglmQweights(aglm$linear.predictor,family=aglm$family),
                                            aglm$weights, check.attributes=FALSE)))
              expect_true(all(abs(getglmQweights(aglm$linear.predictor,family=aglm$family) - aglm$weights) < 1e-5))
          })


test_that("Expectations re arm:bayesglm() handling of pseudo-observations",
### in the odd event that arm:bayesglm.fit() should be revised
### to put the pseudo-observations somewhere other than at the
### end, this test ought to flag it.   
{
    expect_true(require("arm"))
    set.seed(12345)
    ## example borrowed from arm:bayesglm docs
    n <- 100
    x1 <- rnorm (n)
    x2 <- rbinom (n, 1, .5)
    b0 <- 1
    b1 <- 1.5
    b2 <- 2
    y <- rbinom (n, 1, invlogit(b0+b1*x1+b2*x2))     
    M1 <- glm (y ~ x1 + x2, family=binomial(link="logit"))
    M2 <- bayesglm (y ~ x1 + x2, family=binomial(link="logit"),
                    prior.scale=Inf, prior.df=Inf)
    M1_qs  <- qr.Q(M1[['qr']])
    M2_qs  <- qr.Q(M2[['qr']])
    diffs_initrows  <- as.vector(M1_qs - M2_qs[seq_len(n),])
    diffs_finalrows  <-
        as.vector(M1_qs - M2_qs[seq(to=nrow(qr.Q(M2$qr)), by=1,len=n),])
    ## too busy/lazy to take the time to figure out how really
    ## the observations should be aligned, so settling for this:
    expect_lt(100*median(abs(diffs_initrows)),
              median(abs(diffs_finalrows)))
})

context("pic_stderr() calculations regression tests")

test_that("Gives same answer as original version", {
gpsc <- function(propensity.glm, covariance.extractor=vcov) {

  stopifnot(inherits(propensity.glm, "glm"))

  data <- model.matrix(propensity.glm)
  data <- data[,!colnames(data) == "(Intercept)", drop = FALSE]

  covx <- cov(data)

  covb <- covariance.extractor(propensity.glm)

  covb <- covb[,!colnames(covb) == "(Intercept)", drop = FALSE]
  covb <- covb[!rownames(covb) == "(Intercept)",, drop = FALSE]

  # calculate the correction for the expected difference in propensity scores
  ps <- predict(propensity.glm)
  rho.beta <- apply(data, 2, function(xi) { cor(xi, ps) })
  sd.x <- sqrt(diag(covx))

  srb <- sd.x * rho.beta
 
  sqrt(2 * sum(covx * covb) - 2 * (t(srb) %*% covb %*% srb)[1,1]) 
}
## here are the regression tests
expect_equal(ppse_notstabilized(aglm), gpsc(aglm))
expect_true( abs(pic_stderr(aglm)[['rms_err']] - gpsc(aglm)) < 1e-5 )
} )

test_that("legacy fct ppse_notstabilized() behavior",
          {
            expect_true(inherits(ppse_notstabilized(aglm, simplify=FALSE), "list"))
            expect_true(!inherits(ppse_notstabilized(aglm, simplify=TRUE), "list"))
          })

test_that("Crude agreement between ppse_notstabilized & ppse_via_qr",{
    expect_true(ppse_notstabilized(aglm)!=pic_stderr(aglm, coeffs.from.fitted.model=F)[['rms_err']])
    expect_equivalent(ppse_notstabilized(aglm),pic_stderr(aglm, coeffs.from.fitted.model=T)[['rms_err']])
    expect_true(abs(ppse_notstabilized(aglm) - pic_stderr(aglm, coeffs.from.fitted.model=F)[['rms_err']])<1e-5)
    expect_true(abs(ppse_notstabilized(aglm) - pic_stderr(aglm, coeffs.from.fitted.model=T)[['rms_err']])<1e-5)
    expect_true(abs(ppse_notstabilized(aglm, covariance.estimator="sandwich") -
                        pic_stderr(aglm, covariance.estimator="sandwich")[['rms_err']]) <1e-5)
})

context("pic_stderr() API")
test_that("structure of pic_se_info objects",{
    a_pic_se_info <- pic_stderr(aglm)
    expect_s3_class(a_pic_se_info, "pic_se_info")
    expect_type(a_pic_se_info, "list")
    expect_named(a_pic_se_info,
                 c("rms_err", "idim_scaled_cov",
                   "cov.betahat", "betahat", "X", "y"),
                 ignore.order=TRUE, ignore.case=FALSE)
})
test_that("print.pic_se_info",{
    a_pic_se_info <- pic_stderr(aglm)
    expect_output(print(a_pic_se_info), "pic_se_info object")
    expect_type(l2  <- a_pic_se_info[['rms_err']], "double")
    expect_output(print(a_pic_se_info), as.character(trunc(l2)))
})

test_that("pic_stderr$X has row names",
{
    expect_false(is.null(row.names(pic_stderr(aglm)[['X']])))
})

test_that("appropriately handles NA coefs",
          {
              aglm.alt <- update(aglm, formula=update(formula(aglm), .~.+factor(ne)))
              expect_true(any(is.na(coef(aglm.alt))))
              expect_equal(ppse_notstabilized(aglm), ppse_notstabilized(aglm.alt))
              expect_equal(pic_stderr(aglm, coeffs.from.fitted.model=F)[['rms_err']],
                           pic_stderr(aglm.alt, coeffs.from.fitted.model=F)[['rms_err']])
              expect_equal(pic_stderr(aglm, coeffs.from.fitted.model=T)[['rms_err']],
                           pic_stderr(aglm.alt, coeffs.from.fitted.model=T)[['rms_err']])
           })

test_that("ppse_notstabilized appropriately handles strata in formula", {
    expect_true(require("survival"))
    aglm.s <- update(aglm, formula=update(formula(aglm),
                                        #.~.-ne+survival:::strata(ne))) # pic_stderr doesn't recognize now;
                               .~.-ne+strata(ne))) #thus the `require("survival")` above.  Oughta fix that...
    expect_true(ppse_notstabilized(aglm.s) < ppse_notstabilized(aglm))
    expect_equal(ppse_notstabilized(aglm.s, terms.to.sweep.out=NULL),
                 ppse_notstabilized(aglm))
} )

test_that("pic_stderr() handles strata() terms *if* placed next to Intercept", {
    expect_true(require("survival"))
    aglm.s <- update(aglm, formula=update(formula(aglm),
                               .~.-ne+strata(ne))) 
    expect_warning(pic_stderr(aglm.s), "ignored")
    expect_equal(suppressWarnings(pic_stderr(aglm.s)[['rms_err']]), pic_stderr(aglm)[['rms_err']] )
    aglm.s2 <- update(aglm, formula=update(formula(aglm),
                               .~strata(ne)+.-ne)) 
    expect_equivalent(pic_stderr(aglm.s2, terms.to.sweep.out=NULL)[['rms_err']],
                 pic_stderr(aglm)[['rms_err']] )
    expect_true(pic_stderr(aglm.s2)[['rms_err']] < pic_stderr(aglm)[['rms_err']])
} )

test_that("accepts arm::bayesglm fits", {
    expect_true(require("arm"))
    bglm <- bayesglm(pr~.-cost, data=nuclearplants, family=binomial)
    expect_false(is.null(bglm$qr))
    expect_that(ppse_notstabilized(bglm), is_a("numeric"))
    expect_true(inherits(ppse_notstabilized(bglm, simplify=FALSE), "list"))
    expect_error(pic_stderr(bglm, # have yet to teach it how to rebuild coefs 
                      coeffs.from.fitted.model=FALSE)) # from QR
    expect_true(inherits(pic_stderr(bglm,
                              coeffs.from.fitted.model=TRUE), ## with this it ought to go through
                         "list"))
    expect_equivalent(pic_stderr(bglm), pic_stderr(bglm, coeffs.from.fitted.model=TRUE))
    expect_true(inherits(pic_stderr(bglm, covariance.estimator="sandwich",
                              coeffs.from.fitted.model=TRUE), 
                         "list"))
})

context("Internal pic_stderr() dependencies")

test_that("makeXperp()/makeSperp() agreement", {
    n <- 5
    d <- data.frame(x1=rnorm(n),
                    x2=rnorm(n))
    d  <- as.matrix(d)
    covd  <- cov(d)
    dperp1  <- makeXperp(d, 1:2)
    expect_equivalent(cov(dperp1), makeSperp(covd, 1:2))
})

context("pic_stderr() calculations")

test_that("`getglmQweights()` mimics `glm.fit()`'s creation of quadratic weights", {
    aglm0 <- suppressWarnings(update(aglm, control=list(maxit=(aglm$iter-1))))
    expect_false(aglm0$converged)
    aglm1 <- suppressWarnings(update(aglm0, etastart=aglm0$linear.predictors, control=list(maxit=1)))
    expect_true(aglm1$converged)
    expect_true(isTRUE(all.equal(getglmQweights(aglm0$linear.predictor,family=aglm0$family),
                                 aglm1$weights, check.attributes=FALSE))
                )
### But it doesn't work out if you take weights and coeff's from the same iteration (even the last one)
    expect_false(isTRUE(all.equal(getglmQweights(aglm1$linear.predictor,family=aglm1$family),
                                 aglm1$weights, check.attributes=FALSE))
                 )
})

test_that("updating a converged glm makes no discernible change to its linear predictors",
          {
              expect_true(isTRUE(all.equal(predict(aglm),predict(update(aglm,etastart=predict(aglm))) )))
              ## Numerically speaking, coefficients converge before the weight vector does.
              ## Not sure I should have been surprised to find this, but I was;
              ## so I'll digress briefly to document it.
              aglm2 <- update(aglm, etastart=aglm$linear.predictors)
              expect_true(isTRUE(all.equal(coef(aglm2), coef(aglm)))) #so coeff's have converged,
              expect_true(isTRUE(all.equal(predict(aglm2), predict(aglm)))) # as have the eta's...
              expect_false(isTRUE(all.equal(aglm2$weights, aglm$weights))) #but fitting weights have not
              expect_false(isTRUE(all.equal(vcov(aglm2), vcov(aglm)))) #nor has the information matrix.
              expect_true((aglm2$deviance-aglm$deviance)^2 < #Differences may show up in 
                          .Machine$double.eps)               # deviances -- but just barely.
          })

test_that("Crude alignment between QR decomp-based calcs and coeffs, cov-hats associated with fitted glms",
          {
              ## the `C_Cdqrls`-based coefficent estimates don't align precisely w/ QR-based reconstruction
              expect_error(pic_stderr(aglm,
                                tol.coeff.alignment=1e-7), "reported coefficients differ by up to")
              ## but with fuzzy goggles they do look the same
              expect_that(pic_stderr(aglm, tol.coeff.alignment=1e-5)[['rms_err']], is_a("numeric"))
              ## On the other hand, nominal cov-hat's do line up to within numerical tolerance
              expect_true(isTRUE(all.equal(qr.R(stats:::qr.lm(aglm)) %*%
                                           vcov(aglm) %*% # this is basically `chol2inv(qr.R(aglm$qr))`, via summary.glm
                                           t(qr.R(stats:::qr.lm(aglm))),
                                           diag(stats:::qr.lm(aglm)$rank), # under the Q basis, C-hat is the identity
                                           check.attributes=FALSE))
                          )
          })


test_that("Numerical stabilization from ppse_via_qr",{
    ## Josh E example in which ppse_notstabilized doesn't work.
    set.seed(201510)
    n <- 100
    d <- data.frame(y=sample(0:1, n, TRUE),
                    x1=rnorm(n),
                    x2=rnorm(n))
    d$x3 <- d$x1+d$x2+rnorm(n,sd=.0000001)
    mod1 <- glm(y~., data=d, family=binomial)
    ppse1_nostab <- ppse_notstabilized(mod1, "sandwich", simplify=FALSE)
    ppse1_nostab_ <- sum(ppse1_nostab$cov.betahat *
                         ppse1_nostab$S
                         )
    expect_true(ppse1_nostab_^2 >1e3 | # I see this on R 3.6.1 x86_64-apple-darwin15.6.0 (64-bit)
                ppse1_nostab_^2 < -1e3 # I see this on R 3.5.3 x86_64-pc-linux-gnu (64-bit)
                ) 
    ppse1_qr <- pic_stderr(mod1, "sandwich")
    expect_gt(ppse1_qr[['rms_err']], 0)
    expect_lt(ppse1_qr[['rms_err']], 1)    
})


test_that("|Sperp^{1/2} C_beta Sperp^{t/2}|_F = <Sperp, C_beta>_F^{1/2}",
          {
            aglm_pic_se <- pic_stderr(aglm, tol.coeff.alignment=1)
            expect_equivalent(aglm_pic_se$rms_err, aglm_pic_se$rms_err_alt)
          })

test_that("pic_maxerr() methods' inputs and return values",{
    pie_aglm  <- pic_maxerr(x=aglm)
    pie_aglm_fac1  <- pic_maxerr(as.factor(nuclearplants$pt), x=aglm)
##    pie_aglm_pairm  <- pic_maxerr(pairm_aglm, x=aglm)
    stable_components   <- setdiff(names(pie_aglm_fac1),
                                  c("max_err", "max_err_simerr"))
    pic_maxerr(x=aglm,
               pairings=as.factor(nuclearplants$pt)
               )[stable_components] |>
    expect_identical(pie_aglm_fac1[stable_components])
    expect_is(pie_aglm_fac1[['max_err_simerr']], 'numeric')
})
test_that("comparisons of pic_maxerr() methods' return values",{
    pie_aglm  <- pic_maxerr(x=aglm)
    ns_aglm  <- c('0'=sum(nuclearplants$pr==0),
                  '1'=sum(nuclearplants$pr==1)
                  )
    pie_aglm2  <- pic_maxerr(min(ns_aglm)-1L, x=aglm)
    expect_lt(pie_aglm2[['max_err']], pie_aglm[['max_err']])
    
    pie_aglm_fac_no_trt  <- pic_maxerr(as.factor(nuclearplants$pt), x=aglm)

    pie_aglm_fac_w_trt  <- with(nuclearplants,
                           pic_maxerr(as.factor(pt),
                                      x=aglm,
                                      treatment=as.logical(pr)
                                      )
                           )
    expect_lt(pie_aglm_fac_w_trt[['max_err']],
              pie_aglm_fac_no_trt[['max_err']])

    
    amo  <- optmatch::match_on(aglm, data=nuclearplants) +
        optmatch::exactMatch(pr~pt, data=nuclearplants)
    fullm_aglm  <- 
    optmatch::pairmatch(amo, data=nuclearplants)

    pie_aglm_fullm_no_trt  <- pic_maxerr(fullm_aglm, x=aglm)
    expect_lt(pie_aglm_fullm_no_trt[['max_err']],
              pie_aglm_fac_no_trt[['max_err']])

    pie_aglm_fullm_with_trt  <-
        pic_maxerr(fullm_aglm,
                   x=aglm,
                   treatment=(nuclearplants$pr==1)
                   )
    expect_lt(pie_aglm_fullm_with_trt[['max_err']],
              pie_aglm_fullm_no_trt[['max_err']])
})

