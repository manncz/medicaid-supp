library('magrittr')
data(nuclearplants, package="optmatch")
aglm <- glm(pr~.-cost, data=nuclearplants, family=binomial)
aglm_vcov  <- vcov(aglm)
aglm_swch  <- sandwich::vcovHC(aglm, type="HC0")
mm  <- model.matrix(aglm)
n  <- nrow(mm)
mm_d  <- mm[rep(1L:nrow(mm), nrow(mm)),]  -
    mm[rep(1L:nrow(mm), each=nrow(mm)),]
var_swch_d  <- rowSums((mm_d %*% aglm_swch) * mm_d)
var_vcov_d  <- rowSums((mm_d %*% aglm_vcov) * mm_d)
pses_swch <- sqrt(var_swch_d)
pses_vcov  <- sqrt(var_vcov_d)    
dim(pses_swch)   <- dim(pses_vcov) <- rep(nrow(mm), 2)
dimnames(pses_swch)  <- dimnames(pses_vcov)  <-
    rep(list(rownames(nuclearplants)), 2)
names(dimnames(pses_swch))  <- # following match_on()`
    names(dimnames(pses_vcov))  <-
    c("treatment","control")
unms  <- split(rownames(nuclearplants), nuclearplants$pr)
names(unms)  <- c('t', 'c')[match(names(unms), c('1', '0'))]

context("`paired_se_dist()` against ref calcs, using nuclearplants data")

test_that("separate & averaged pse's align",
{
expect_equivalent(sum(var_swch_d)/(n * (n-1)), 
                  2 * sum(cov(mm) * aglm_swch)
                  )
}
)

test_that("by-hand PIC SE same as `pic_stderr()`'s",{
expect_equivalent(2 * sum(makeSperp(cov(mm), coef(aglm)) * aglm_swch),
                  pic_stderr(aglm, covariance.estimator="sandwich")$rms_err^2,
                  tolerance=1e-5
                  )
expect_equivalent(2 * sum(makeSperp(cov(mm), coef(aglm)) * aglm_vcov),
                  pic_stderr(aglm, covariance.estimator="vcov")$rms_err^2,
                  tolerance=1e-5
                  )
})

test_that("agreement with ref calcs",
{
    paired_se_dist(aglm, covariance.estimator="sandwich") %>%
        as.matrix() %>% 
    expect_equal(pses_swch[unms$t, unms$c],
                      tolerance=1e-5 )
    paired_se_dist(aglm, covariance.estimator="vcov") %>%
        as.matrix() %>% 
    expect_equal(pses_vcov[unms$t, unms$c],
                      tolerance=1e-5 )    
})

test_that("data argument is understood",{
    expect_equivalent(paired_se_dist(aglm, data=nuclearplants),
                 paired_se_dist(aglm))
})
test_that("compatible w/ `lm()`-type handling of singular design matrices",
{
    bglm  <- nuclearplants %>% transform(pt_dup=pt) %>%
        update(aglm,
               formula=update(formula(aglm), .~.+pt_dup),
               data=.)
    expect_equivalent(paired_se_dist(aglm, covariance.estimator="vcov"),
                      paired_se_dist(bglm, covariance.estimator="vcov")
                      )
    expect_equivalent(paired_se_dist(aglm, covariance.estimator="sandwich"),
                      paired_se_dist(bglm, covariance.estimator="sandwich")
                      )
})
###test_that("caliper and exclude arguments are understood",
###{    
###})
