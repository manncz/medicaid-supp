Medellin data. This version excludes a few neighborhoods from the
treatment group in order to dodge data availability complications.

``` r
system.file("extdata", "meddat.csv",
            package = "PISE", mustWork = TRUE) %>%
read.csv(., row.names=1) -> meddat
```

# Propensity score models

## The PS model used in Cerda et al

(In Ben’s Medellin analysis scripts, a very similar model is called
`m.brps`.)

``` r
ps_mods  <- list('glm'=NULL, 'brglm'=NULL, 'bayesglm'=NULL)
ps_mods[['brglm']] <-
    brglm::brglm(nhTrt ~ nhLogHom+nhClass+nhSisben+nhPopD+nhQP03+nhPV03+nhTP03+
                nhBI03+nhCE03+nhNB03+nhMale+nhAgeYoung+nhAgeMid+
                nhMarDom+nhSepDiv+nhOwn+nhRent+nhEmp+nhAboveHS+nhHS, data=meddat,
                family="binomial")
```

Let’s compare this to other flavors of glm fitting in terms of spectral
condition numbers of associated information matrices.

``` r
ps_calls  <- rep(list(ps_mods[['brglm']]$call), 3)
names(ps_calls)  <- names(ps_mods)
ps_calls[['glm']][[1L]]  <- quote(stats::glm)
ps_calls[['bayesglm']][[1L]]  <- quote(arm::bayesglm)
ps_mods[['glm']]  <- eval(ps_calls[['glm']])
ps_mods[['bayesglm']]  <- eval(ps_calls[['bayesglm']])
```

Condition numbers, with and without regularization.

``` r
sapply(ps_mods, function(x) kappa(x$qr))
```

    ##      glm    brglm bayesglm 
    ##  1689266    11078     7443

Based on these results, we’ll depart for what Cerda et al did & instead
used the bayesglm fit.

``` r
ps_mod  <- ps_mods[['bayesglm']]
```

## Overlap

``` r
boxplot(ps_mod, horizontal=TRUE)
```

![](medellin_files/figure-gfm/unnamed-chunk-4-1.png)<!-- -->

The picture strongly suggests limited overlap, but in actuality it’s
equivocal. The following demonstrates why. Here the left panel depicts
separation on the actually fitted propensity score, whereas remaining
panels depict pseudo propensity scores fitted after random permutations
of treatment labels. I.e. every neighborhood has the same propensity
score by design.

![](medellin_files/figure-gfm/psboxplots-1.png)<!-- -->

Isolation of individual units on propensity score (in logit units, not
“standard” units)

``` r
summary(mo_ps  <-
            match_on(setNames(predict(ps_mod),
                              row.names(model.frame(ps_mod))),
                     z=model.response(model.frame(ps_mod)))
        )
```

    ## Membership: 25 treatment, 23 control
    ## Total eligible potential matches: 575 
    ## Total ineligible potential matches: 0 
    ## 
    ## Summary of minimum matchable distance per treatment member:
    ##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
    ##    0.02    0.12    0.53    0.84    0.87    4.37

## Smallest calipers that don’t exclude Tx units from matches

``` r
stratumStructure(fullmatch(mo_ps + caliper(mo_ps, 4.0), data=meddat))
```

    ##  1:0 14:1  5:1  2:1  1:1 1:17  0:1 
    ##    1    1    1    1    2    1    1

``` r
stratumStructure(fm4.5  <- fullmatch(mo_ps + caliper(mo_ps, 4.5), data=meddat))
```

    ## 15:1  5:1  2:1  1:1 1:17  0:1 
    ##    1    1    1    2    1    1

## PISE

``` r
ps_SEs  <- lapply(ps_mods, pise, covariance.estimator = 'sandwich')
names(ps_SEs)  <- names(ps_mods)
ps_se <- ps_SEs[['brglm']]
ps_se
```

    ## PISE_info object (a list) with `width`= 1.61

So the least feasible caliper shown above is within a few paired SEs of
the propensity score. In fact, it’s also consistent with 4-group split
on the propensity
score.

``` r
( brkpts  <- seq(from=min(predict(ps_mod)), to=max(predict(ps_mod)), len=5) )
```

    ## [1] -8.00 -4.34 -0.68  2.98  6.64

``` r
quarters  <- cut(predict(ps_mod), breaks=brkpts, include.lowest=T)
table (quarters, meddat$nhTrt) 
```

    ##                
    ## quarters         0  1
    ##   [-8,-4.34]     2  0
    ##   (-4.34,-0.68] 16  1
    ##   (-0.68,2.98]   5 17
    ##   (2.98,6.64]    0  7

``` r
optmatch:::effectiveSampleSize (quarters, meddat$nhTrt)
```

    ## [1] 9.61

To minimize the reduction in the effective sample size, we can try a
matching with symmetric restrictions that respects a caliper of 2.5
paired SEs of the score.

``` r
summary( mo_ps + caliper(mo_ps, 2.5*ps_se[['width']]) )
```

    ## Membership: 25 treatment, 23 control
    ## Total eligible potential matches: 296 
    ## Total ineligible potential matches: 279 
    ## 
    ## 1 unmatchable treatment member:
    ##  25
    ## 
    ## 1 unmatchable control member:
    ##  31
    ## 
    ## Summary of minimum matchable distance per treatment member:
    ##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
    ##    0.02    0.11    0.45    0.70    0.86    3.16

``` r
fm_sr  <- fullmatch(mo_ps + caliper(mo_ps, 2.5*ps_se[['width']]),
                    min.c=.5, max.c=2 ,
                    data=meddat)
summary(fm_sr)
```

    ## Structure of matched sets:
    ## 1:0 2:1 1:1 1:2 0:1 
    ##   1   4  14   2   1 
    ## Effective Sample Size:  22 
    ## (equivalent number of matched pairs).

## x-differences

How about within-matched-set differences on Xes, are they within norms
for leverages?

``` r
hvs_fm4.5  <- hatvalues(ps_se, fm4.5)
stopifnot( all.equal(mean(hvs_fm4.5), ncol(ps_se$X)/nrow(ps_se$X) ) )
cut( hvs_fm4.5/mean(hvs_fm4.5) ,
    breaks=c(0:3, Inf),
    include.lowest=T) %>% table(meddat$nhTrt)
```

    ##          
    ## .          0  1
    ##   [0,1]   14 13
    ##   (1,2]    8 12
    ##   (2,3]    1  0
    ##   (3,Inf]  0  0

``` r
hvs_quarters <- hatvalues(ps_se, quarters)
cut(hvs_quarters/mean(hvs_quarters),
    breaks=c(0:3, Inf),
    include.lowest=T) %>% table(meddat$nhTrt)
```

    ##          
    ## .          0  1
    ##   [0,1]   14 10
    ##   (1,2]    9 15
    ##   (2,3]    0  0
    ##   (3,Inf]  0  0

``` r
hvs_fm_sr  <- hatvalues(ps_se, fm_sr)
cut(hvs_fm_sr/mean(hvs_fm_sr),
    breaks=c(0:3, Inf),
    include.lowest=T) %>% table(meddat$nhTrt)
```

    ##          
    ## .          0  1
    ##   [0,1]   14 14
    ##   (1,2]    8 10
    ##   (2,3]    1  1
    ##   (3,Inf]  0  0

## matching within a leverage radius as well as PS calipers

If we had observed a leverage issue among the x-differences, one remedy
would be to add a leverage radius requirement to the matching exercise.

``` r
leverage_computefn <-
    make_paired_leverage_computor(ps_se)
mo_lvg  <-
    match_on(leverage_computefn[['FUN']],
             data=leverage_computefn[['Xperp']], z=ps_se$z
             )
mo_lvg  <- mo_lvg/sqrt(leverage_computefn[['rank']])
summary(match_on(mo_lvg, caliper=sqrt(2.5)))
```

    ## Membership: 25 treatment, 23 control
    ## Total eligible potential matches: 460 
    ## Total ineligible potential matches: 115 
    ## 
    ## Summary of minimum matchable distance per treatment member:
    ##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
    ##   0.772   0.906   1.105   1.076   1.174   1.513

``` r
mo_ps_lvgradius  <- mo_ps + caliper(mo_lvg, width=sqrt(2.5))
summary(match_on(mo_ps_lvgradius, caliper = 2.5 * ps_se[['width']]))
```

    ## Membership: 25 treatment, 23 control
    ## Total eligible potential matches: 261 
    ## Total ineligible potential matches: 314 
    ## 
    ## 3 unmatchable treatment members:
    ##  10, 13, 25
    ## 
    ## 2 unmatchable control members:
    ##  31, 33
    ## 
    ## Summary of minimum matchable distance per treatment member:
    ##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
    ##   0.017   0.094   0.361   0.630   0.801   2.947

``` r
fm_sr_lr  <- update(fm_sr,
                    x = match_on(mo_ps_lvgradius,
                                 caliper = 2.5 * ps_se[['width']])
                    )
summary(fm_sr_lr)
```

    ## Structure of matched sets:
    ## 1:0 2:1 1:1 1:2 0:1 
    ##   3   3  14   2   2 
    ## Effective Sample Size:  20.7 
    ## (equivalent number of matched pairs).

comparing to prev. results:

``` r
data.frame(row.names=c("fm_sr", "fm_sr_lr"), 
           eff_n=sapply(list(fm_sr, fm_sr_lr), effectiveSampleSize), 
           max_leverage=sapply(list(fm_sr, fm_sr_lr), function(x) max(hatvalues(ps_se, x)))
           ) %>% knitr::kable()
```

|            | eff\_n | max\_leverage |
| ---------- | -----: | ------------: |
| fm\_sr     |   22.0 |         0.945 |
| fm\_sr\_lr |   20.7 |         0.914 |

``` r
cut(hatvalues(ps_se, fm_sr_lr)/mean(hvs_fm_sr),
    breaks=c(0:3, Inf),
    include.lowest=T) %>% table(meddat$nhTrt)
```

    ##          
    ## .          0  1
    ##   [0,1]   16 15
    ##   (1,2]    5  8
    ##   (2,3]    2  2
    ##   (3,Inf]  0  0

## How well do orthocomplement M-distances approximate post matching M-distances?

make\_paired\_leverage\_computor.factor() is used to assemble paired
leverage distances as they occur in an actual match, using
non-orthogonalized Xes. make\_paired\_leverage\_computor.PISE\_info()
computes the pre-matching approximation to post-matching leverages based
on X orthgonalized for X’beta. Then it’s used to figure those
approximate leverages by actual pairing.

``` r
thematches  <- list(fm4.5, fm_sr, fm_sr_lr)
names(thematches)  <- c('fm4.5', 'fm_sr', 'fm_sr_lr')
post_strat_dists  <- thematches %>%
    sapply(make_paired_leverage_computor,
           y=ps_se[['X']],
           simplify=FALSE, USE.NAMES=TRUE) %>%
    mapply(function(bdl, thematch){
        match_on(bdl[['FUN']],
                 within=exactMatch(thematch, ps_se[['z']]),
                 data=bdl[['Xperp']], z=ps_se[['z']])/
            sqrt(bdl[['rank']]) },
    bdl=.,
    thematch = thematches,
    SIMPLIFY=FALSE, USE.NAMES=TRUE)
post_strat_paired_levs  <-
    mapply(matched.distances,
           thematches,
           post_strat_dists,
           MoreArgs=list(preserve.unit.names=FALSE),
           SIMPLIFY=FALSE, USE.NAMES=TRUE)
pre_strat_paired_levs  <-
    sapply(thematches,
           matched.distances,
           distance=mo_lvg,
           preserve.unit.names=FALSE,
           simplify=FALSE, USE.NAMES=TRUE)
rbind(pre=sapply(pre_strat_paired_levs, function(x) mean(unlist(x)^2) ),
      post=sapply(post_strat_paired_levs, function(x) mean(unlist(x)^2) )
      ) %>% knitr::kable()
```

|      | fm4.5 | fm\_sr | fm\_sr\_lr |
| ---- | ----: | -----: | ---------: |
| pre  |  2.09 |   1.94 |       1.83 |
| post |  2.35 |   3.31 |       3.15 |

## What’s the effect of regularization on the PISE?

Condition numbers versus PISEs.

``` r
data.frame(row.names=names(ps_mods),
           kappa=sapply(ps_mods, function(x) kappa(x$qr)),
           PISE=sapply(ps_SEs, getElement, name="width")
           ) %>% signif(digits=3) %>% knitr::kable()
```

|          |   kappa | PISE |
| -------- | ------: | ---: |
| glm      | 1690000 | 2.45 |
| brglm    |   11100 | 1.61 |
| bayesglm |    7440 | 1.59 |
