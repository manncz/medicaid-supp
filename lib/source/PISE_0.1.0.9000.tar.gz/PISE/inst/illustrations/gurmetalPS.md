Preliminaries
-------------

data setup
----------

Flag subjects lacking treatment data or age data.

``` r
msng_tx_or_age <- !cdat.has.txinfo | is.na(cdat_red$AgeCat)
table(msng_tx_or_age)
```

    ## msng_tx_or_age
    ## FALSE  TRUE 
    ## 85048     2

Impute missings on remaining covariates. Most of the missingness appears to be height, weight and similar.

``` r
psdata <- optmatch::fill.NAs(pr_vcd~. -(AgeCat + hosp.code + ih_v_c+ih_tx+ih_death), 
                          data = cdat_red[!msng_tx_or_age,])
psdata <- data.frame(psdata, cdat_red[!msng_tx_or_age,][c("AgeCat", "hosp.code")])
formula_psdata = formula(psdata)
psdata$pi_race1 <- with(psdata, (pi_race2+pi_race3+ pi_race4+ pi_race5+ pi_race9)==0)

round(
sapply(grep(".NA", names(psdata), fixed=TRUE, value=TRUE), 
       function(nm) mean(psdata[[nm]])
       ), 
      3)
```

    ##          wt_kg.NA          ht_cm.NA        pi_race.NA       mi_lytic.NA 
    ##             0.025             0.017             0.006             0.000 
    ## mi_1st_ecg_pos.NA       l_pre_cr.NA      l_pre_hgb.NA            gfr.NA 
    ##             0.000             0.014             0.016             0.040 
    ##      caf_ndv_b.NA         pr_n_v.NA         pr_flt.NA          pr_tc.NA 
    ##             0.000             0.000             0.007             0.006 
    ##        pr_shth.NA         pr_dur.NA 
    ##             0.002             0.007

Variables that lead author identified as most important for propensity adjustment:

``` r
main_PSvars <- pr_vcd ~ Age + gender1 + wt_kg + bmi_catLean + 
  pi_race1 + pi_race2+
hx_smk + hx_hyp + hx_iddm + hx_niddm + hx_chf + hx_pvd + hx_copd +
  hx_cva + hx_rfd + l_pre_cr + l_pre_hgb + gfr + ci_ang + ci_ua +
  ci_tdsrg+ci_stgd+mi_pptca + mi_present + mi_lytic + hep_pre +
  nitr_pre + vaso_pre + vaso_dur + 
  coum_pre + reo_pre + int_pre + plvx_pre + angi_dur +
  intg_pre + intg_dur + dur_2b3a + caf_lmst + caf_ef + caf_ndv_b +
  pr_n_v + pr_flt + pr_tc + pr_shth + calc_1 + thrm_1 + cto_1 + 
  pr_st_1 + dissection_yn_1
```

Subclasses selected to facilitate subgroup analyses:

``` r
psdata$prognostic.subclasses <- 
    with(psdata, 
       interaction(gender1, 
                   bmi_catLean,
                   mi_present, inhib, 
                   angi_dur, 
                   hx_pvd,
                   drop=TRUE)
       )
```

Procedure volume at treating hospitals
--------------------------------------

Divide patients according to whether they were treated at hospitals with high, medium or low volume of indicated procedures.

``` r
tb <- sort(table(psdata$hosp.code))
 sum(tb)/3
```

    ## [1] 28349

``` r
sum( cumsum(tb)<(sum(tb)/3) )
```

    ## [1] 18

``` r
cumsum(tb)[sum(cumsum(tb)<(sum(tb)/3)) + -2:2]
```

    ##    15     2    41     3    36 
    ## 21279 23763 26262 28980 31831

``` r
volgroups <- list()
volgroups$i <- c(0, sum( cumsum(tb)<(sum(tb)/3) ), sum( cumsum(tb)<(2*sum(tb)/3) ), length(tb))
volgroups <- within(volgroups, 
                    {low = names(tb)[(i[1]+1):i[2] ]
                    med = names(tb)[(i[2]+1):i[3] ]
                    high = names(tb)[(i[3]+1):i[4] ]
                   }
                    ) 
volgroups <- volgroups[names(volgroups)!="i"]
psdata$hosp.volume <- factor(numeric(nrow(psdata)), levels=c("low", "med", "high"))
for (nm in names(volgroups)) psdata$hosp.volume[psdata$hosp.code %in% volgroups[[nm]] ] <- nm
table(psdata$hosp.volume)
```

    ## 
    ##   low   med  high 
    ## 26262 27875 30911

``` r
with(psdata, setequal(levels(hosp.code[hosp.volume=="low", drop=TRUE]), volgroups$low))
```

    ## [1] TRUE

Propensity scores
-----------------

the statistical appendix of Gurm et al refers to the PS below as \`\`Matching within hospital groups, on inclusive score only''.

``` r
ps_big <- 
  glm(update(formula_psdata, 
             pr_vcd~strata(prognostic.subclasses, hosp.volume)+.-hosp.code),
      family=binomial, data=psdata)
```

(I forget how Gurm et al referenced this smaller model.)

``` r
ps_small <- glm(update(main_PSvars, 
                       .~strata(prognostic.subclasses, hosp.volume)+.),
            family=binomial, data=psdata
               )
```

The PISEs
=========

2015 edition
------------

``` r
ppse_big_unstabilized <- ppse_notstabilized(ps_big, covariance.estimator='sandwich', simplify=T) 
ppse_big_unstabilized
```

    ## [1] 0.15

2017 edition
------------

Calcs using these data appeared in a presentation from 2016, not 2017. But it appears that those calcs may have inadvertently neglected to factor out strata columns, b/c they were declared at end rather than beginning of model formula. Or maybe the code I was using then pulled them out, but incorrectly. Either way, that particular error is fixed here.

``` r
ppse_big <-
    PISE:::ppse_via_qr(ps_big, covariance.estimator = 'sandwich')
ppse_big
```

    ## PISE_info object (a list) with `width`= 26

If the two above were to differ greatly, I'd take the latter one. (The former one tries to take into account our intention to match exactly within classes.)

These answers are expressed in the units of the linear predictor (here, logits). The matching function also expects them to be expressed in terms of the linear predictor (as opposed to on the probability scale) but in standard units, ie as multiples of a pooled sd. Accordingly,

``` r
ppse_big_unstabilized/optmatch:::szn.scale(predict(ps_big), ps_big$y, standardizer=sd) 
```

    ## [1] 0.226

``` r
ps_small_se <-
    PISE:::ppse_via_qr(ps_small, covariance.estimator = 'sandwich')
psscale_sm <- optmatch:::szn.scale(predict(ps_small), ps_small$y, standardizer=mad) 
ps_small_se[['width']]/psscale_sm
```

    ## [1] 4.47

Save it.

``` r
save(ps_big, ps_small, ppse_big, ppse_big_unstabilized, ps_small_se, 
     file="~/Documents/caches/Gurm-pci2007/gurmetalPS.RData")
```

What's the effect of regularization?
------------------------------------

Non-regularized propensity model fit.

``` r
calls <- list(ps_small_bayesglm=ps_small$call,
              ps_big_bayesglm=ps_big$call)
calls[['ps_small_bayesglm']][[1L]]  <- quote(arm::bayesglm)
calls[['ps_big_bayesglm']][[1L]]  <- quote(arm::bayesglm)
ps_small_bayesglm_mod  <- eval(calls$ps_small_bayesglm)
ps_big_bayesglm_mod  <- eval(calls$ps_big_bayesglm)
ps_small_bayesglm_se  <- pise(ps_small_bayesglm_mod)
ps_big_bayesglm_se  <- pise(ps_big_bayesglm_mod)
```

L2 regularization done another way.

``` r
calls  <- c(calls, list(ps_small_brglm=ps_small$call))
calls[['ps_small_brglm']][[1L]]  <- quote(brglm::brglm)
ps_small_brglm_mod  <- eval(calls$ps_small_brglm)
ps_small_brglm_se  <- pise(ps_small_brglm_mod)
```

scale

``` r
pooled_sds  <-
    list(glm_sm=optmatch:::szn.scale(predict(ps_small),
                                  ps_small$y, standardizer=sd), 
         bayesglm_sm=optmatch:::szn.scale(predict(ps_small_bayesglm_mod),
                                       ps_small_bayesglm_mod$y,
                                       standardizer=sd),
         brglm=optmatch:::szn.scale(predict(ps_small_brglm_mod),
                                    ps_small_brglm_mod$y,
                                    standardizer=sd),
         glm_big=optmatch:::szn.scale(predict(ps_big),
                                  ps_big$y, standardizer=sd), 
         bayesglm_big=optmatch:::szn.scale(predict(ps_big_bayesglm_mod),
                                       ps_big_bayesglm_mod$y,
                                       standardizer=sd)         
         ) %>% unlist()
pooled_mads  <-
    list(glm_sm=psscale_sm, 
         bayesglm_sm=optmatch:::szn.scale(predict(ps_small_bayesglm_mod),
                                       ps_small_bayesglm_mod$y,
                                       standardizer=mad),
         brglm=optmatch:::szn.scale(predict(ps_small_brglm_mod),
                                    ps_small_brglm_mod$y,
                                    standardizer=mad),
         glm_big=optmatch:::szn.scale(predict(ps_big),
                                  ps_big$y, standardizer=mad), 
         bayesglm_big=optmatch:::szn.scale(predict(ps_big_bayesglm_mod),
                                       ps_big_bayesglm_mod$y,
                                       standardizer=mad)
         ) %>% unlist()
```

Condition numbers, with and without regularization.

``` r
data.frame(fitter=c('glm_sm', 'bayesglm_sm', 'brglm', 'glm_big', 'bayesglm_big'),
           kappa=sapply(list(ps_small, ps_small_bayesglm_mod,
                                   ps_small_brglm_mod, ps_big,
                                   ps_big_bayesglm_mod),
                         function(x) kappa(x$qr)),
           PISE=sapply(list(ps_small_se, ps_small_bayesglm_se,
                            ps_small_brglm_se, ppse_big,
                            ps_big_bayesglm_se),
                        getElement, name="width")
           
           ) %>%
    mutate(PISE.over.mad_p=PISE/pooled_mads,
           PISE.over.sd_p=PISE/pooled_sds) %>%
    knitr::kable(digits=3)
```

| fitter        |     kappa|    PISE|  PISE.over.mad\_p|  PISE.over.sd\_p|
|:--------------|---------:|-------:|-----------------:|----------------:|
| glm\_sm       |  5.15e+19|   2.125|             4.470|            3.934|
| bayesglm\_sm  |  2.54e+05|   0.070|             0.147|            0.131|
| brglm         |  5.84e+19|   2.119|             4.471|            0.000|
| glm\_big      |       Inf|  25.973|            43.058|           39.040|
| bayesglm\_big |  2.34e+05|   0.149|             0.247|            0.232|

Wrapup
======

``` r
sessionInfo()
```

    ## R version 3.4.3 (2017-11-30)
    ## Platform: x86_64-pc-linux-gnu (64-bit)
    ## Running under: Red Hat Enterprise Linux Workstation 7.7 (Maipo)
    ## 
    ## Matrix products: default
    ## BLAS/LAPACK: /usr/lib64/atlas/libsatlas.so.3.10
    ## 
    ## locale:
    ##  [1] LC_CTYPE=en_US.UTF-8       LC_NUMERIC=C              
    ##  [3] LC_TIME=en_US.UTF-8        LC_COLLATE=en_US.UTF-8    
    ##  [5] LC_MONETARY=en_US.UTF-8    LC_MESSAGES=en_US.UTF-8   
    ##  [7] LC_PAPER=en_US.UTF-8       LC_NAME=C                 
    ##  [9] LC_ADDRESS=C               LC_TELEPHONE=C            
    ## [11] LC_MEASUREMENT=en_US.UTF-8 LC_IDENTIFICATION=C       
    ## 
    ## attached base packages:
    ## [1] stats     graphics  grDevices utils     datasets  methods   base     
    ## 
    ## other attached packages:
    ## [1] bindrcpp_0.2.2  sandwich_2.4-0  PISE_0.1.0.9000 optmatch_0.9-10
    ## [5] survival_2.41-3 RItools_0.1-16  SparseM_1.77    dplyr_0.7.6    
    ## 
    ## loaded via a namespace (and not attached):
    ##  [1] Rcpp_1.0.1         highr_0.7          nloptr_1.0.4      
    ##  [4] pillar_1.2.3       compiler_3.4.3     bindr_0.1.1       
    ##  [7] tools_3.4.3        lme4_1.1-17        digest_0.6.15     
    ## [10] evaluate_0.10.1    tibble_1.4.2       nlme_3.1-131      
    ## [13] lattice_0.20-35    pkgconfig_2.0.1    rlang_0.2.1       
    ## [16] Matrix_1.2-12      yaml_2.2.0         brglm_0.6.1       
    ## [19] coda_0.19-1        stringr_1.3.1      knitr_1.20        
    ## [22] rprojroot_1.3-2    grid_3.4.3         tidyselect_0.2.4  
    ## [25] glue_1.2.0         R6_2.2.2           profileModel_0.5-9
    ## [28] arm_1.10-1         rmarkdown_1.10     minqa_1.2.4       
    ## [31] purrr_0.2.5        magrittr_1.5       codetools_0.2-15  
    ## [34] backports_1.1.2    htmltools_0.3.6    splines_3.4.3     
    ## [37] MASS_7.3-47        svd_0.4.1          assertthat_0.2.0  
    ## [40] abind_1.4-5        xtable_1.8-2       stringi_1.2.3     
    ## [43] zoo_1.8-3
