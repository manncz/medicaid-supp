##' ---
##' output:
##'     md_document:
##'         variant: gfm
##' ---
##'
#+ setup, include=FALSE
knitr::opts_chunk$set(echo = TRUE, warning = FALSE)
library(devtools)
library(dplyr)
library(optmatch)
library(glmnet)
stopifnot(requireNamespace("brglm") & requireNamespace("arm"))
tmp_libs  <- '~/tmp/Rlibs'
withr::with_libpaths(tmp_libs, library('PISE'), "prefix")
##' Medellin data.  This version excludes a few neighborhoods
##' from the treatment group in order to dodge data availability
##' complications.  
##+
system.file("extdata", "meddat.csv",
            package = "PISE", mustWork = TRUE) %>%
read.csv(., row.names=1) -> meddat
##' # Propensity score models
##'
##' ## The PS model used in Cerda et al
##' 
##' (In Ben's Medellin analysis scripts, a very similar model is called `m.brps`.)
##' 
#+ psmodfit0, cache=0
ps_mods  <- list('glm'=NULL, 'brglm'=NULL, 'bayesglm'=NULL)
ps_mods[['brglm']] <-
    brglm::brglm(nhTrt ~ nhLogHom+nhClass+nhSisben+nhPopD+nhQP03+nhPV03+nhTP03+
                nhBI03+nhCE03+nhNB03+nhMale+nhAgeYoung+nhAgeMid+
                nhMarDom+nhSepDiv+nhOwn+nhRent+nhEmp+nhAboveHS+nhHS, data=meddat,
                family="binomial")
##' Let's compare this to other flavors of glm fitting in terms of
##' spectral condition numbers of associated information matrices.
##'
#+ psmodfit1, cache=0
ps_calls  <- rep(list(ps_mods[['brglm']]$call), 3)
names(ps_calls)  <- names(ps_mods)
ps_calls[['glm']][[1L]]  <- quote(stats::glm)
ps_calls[['bayesglm']][[1L]]  <- quote(arm::bayesglm)
ps_mods[['glm']]  <- eval(ps_calls[['glm']])
ps_mods[['bayesglm']]  <- eval(ps_calls[['bayesglm']])

##' Condition numbers, with and without regularization.
#+
sapply(ps_mods, function(x) kappa(x$qr))
##' Based on these results, we'll depart for what Cerda
##' et al did & instead used the bayesglm fit.
ps_mod  <- ps_mods[['bayesglm']]
##' 
##' ## Overlap 
 
#+ fig.width=6, fig.height=3 
boxplot(ps_mod, horizontal=TRUE)
##' The picture strongly suggests limited overlap, but in actuality it's
##' equivocal.  The following demonstrates why.
##' Here the left panel depicts separation on the actually fitted propensity
##' score, whereas remaining panels depict pseudo
##' propensity scores fitted after random permutations of treatment labels.
##' I.e. every neighborhood has the same propensity score by design.
#+ psboxplots, echo=FALSE, fig.width=6, fig.height=3
set.seed(201905)
psmods <- 
    replicate(3, 
              {
                  tmp <- model.frame(ps_mod)
                  tmp[[as.character(formula(ps_mod)[[2]])]]  <-
                      sample(model.response(tmp))
                  update(ps_mod, data=tmp)
              }, simplify=FALSE
              )
names(psmods) <- paste0("random", 1L:3L)
PSrescale <- function(x,standardization.scale=NULL,...)
  {
      stopifnot(inherits(x, "glm"), 
                is.null(standardization.scale) | class(standardization.scale)=="function")   
      theps <- predict(x,...) #admittedly brittle
      tx <- as.logical(x$y) # here too
      thesd <- if (is.null(standardization.scale)) 1 else {
          try(optmatch:::szn.scale(theps, tx, standardization.scale), silent=TRUE) }
    if (inherits(thesd, "try-error")) 
      stop("Couldn't use supplied standardization.scale function to calculate sd's.")
    theps <- theps/thesd
  }
therange <- 
    c(min=min(sapply(psmods, function(x) min(PSrescale(x)))),
      max=max(sapply(psmods, function(x) max(PSrescale(x))))
      )
par(mfrow=c(1,4))
boxplot(ps_mod, main="Actual" , ylim=therange)
for (mod in psmods) boxplot(mod, main="Shuffled", ylim=therange)
par(mfrow=c(1,1))

##' Isolation of individual units on propensity score
##' (in logit units, not "standard" units)
##' 
summary(mo_ps  <-
            match_on(setNames(predict(ps_mod),
                              row.names(model.frame(ps_mod))),
                     z=model.response(model.frame(ps_mod)))
        )

##' ## Smallest calipers that don't exclude Tx units from matches
##'
stratumStructure(fullmatch(mo_ps + caliper(mo_ps, 4.0), data=meddat))
stratumStructure(fm4.5  <- fullmatch(mo_ps + caliper(mo_ps, 4.5), data=meddat))
##' ## PISE
##'
ps_SEs  <- lapply(ps_mods, pise, covariance.estimator = 'sandwich')
names(ps_SEs)  <- names(ps_mods)
ps_se <- ps_SEs[['brglm']]
ps_se
##' So the least feasible caliper shown above is within a few paired
##' SEs of the propensity score. In fact, it's also consistent
##' with 4-group split on the propensity score.
( brkpts  <- seq(from=min(predict(ps_mod)), to=max(predict(ps_mod)), len=5) )

quarters  <- cut(predict(ps_mod), breaks=brkpts, include.lowest=T)
table (quarters, meddat$nhTrt) 
optmatch:::effectiveSampleSize (quarters, meddat$nhTrt)
##' To minimize the reduction in the effective sample size, we
##' can try a matching with symmetric restrictions that respects
##' a caliper of 2.5 paired SEs of the score.
summary( mo_ps + caliper(mo_ps, 2.5*ps_se[['width']]) )
fm_sr  <- fullmatch(mo_ps + caliper(mo_ps, 2.5*ps_se[['width']]),
                    min.c=.5, max.c=2 ,
                    data=meddat)
summary(fm_sr)
##' 
##' ## x-differences  
##' How about within-matched-set differences
##' on Xes, are they within norms for leverages?
hvs_fm4.5  <- hatvalues(ps_se, fm4.5)
stopifnot( all.equal(mean(hvs_fm4.5), ncol(ps_se$X)/nrow(ps_se$X) ) )
cut( hvs_fm4.5/mean(hvs_fm4.5) ,
    breaks=c(0:3, Inf),
    include.lowest=T) %>% table(meddat$nhTrt)
hvs_quarters <- hatvalues(ps_se, quarters)
cut(hvs_quarters/mean(hvs_quarters),
    breaks=c(0:3, Inf),
    include.lowest=T) %>% table(meddat$nhTrt)
hvs_fm_sr  <- hatvalues(ps_se, fm_sr)
cut(hvs_fm_sr/mean(hvs_fm_sr),
    breaks=c(0:3, Inf),
    include.lowest=T) %>% table(meddat$nhTrt)
##'
##' ## matching within a leverage radius as well as PS calipers
##'
##' If we had observed a leverage issue among the x-differences,
##' one remedy would be to add a leverage radius requirement to the
##' matching exercise. 
leverage_computefn <-
    make_paired_leverage_computor(ps_se)
mo_lvg  <-
    match_on(leverage_computefn[['FUN']],
             data=leverage_computefn[['Xperp']], z=ps_se$z
             )
mo_lvg  <- mo_lvg/sqrt(leverage_computefn[['rank']])
summary(match_on(mo_lvg, caliper=sqrt(2.5)))
mo_ps_lvgradius  <- mo_ps + caliper(mo_lvg, width=sqrt(2.5))
summary(match_on(mo_ps_lvgradius, caliper = 2.5 * ps_se[['width']]))
fm_sr_lr  <- update(fm_sr,
                    x = match_on(mo_ps_lvgradius,
                                 caliper = 2.5 * ps_se[['width']])
                    )
summary(fm_sr_lr)
##' comparing to prev. results:
data.frame(row.names=c("fm_sr", "fm_sr_lr"), 
           eff_n=sapply(list(fm_sr, fm_sr_lr), effectiveSampleSize), 
           max_leverage=sapply(list(fm_sr, fm_sr_lr), function(x) max(hatvalues(ps_se, x)))
           ) %>% knitr::kable()
cut(hatvalues(ps_se, fm_sr_lr)/mean(hvs_fm_sr),
    breaks=c(0:3, Inf),
    include.lowest=T) %>% table(meddat$nhTrt)

##' ## How well do orthocomplement M-distances approximate post matching M-distances?
##'
##' make_paired_leverage_computor.factor() is used to assemble
##' paired leverage distances as they occur in an actual match,
##' using non-orthogonalized Xes.
##' make_paired_leverage_computor.PISE_info()
##' computes the pre-matching approximation to post-matching
##' leverages based on X orthgonalized for X'beta. Then it's
##' used to figure those approximate leverages by actual pairing.

thematches  <- list(fm4.5, fm_sr, fm_sr_lr)
names(thematches)  <- c('fm4.5', 'fm_sr', 'fm_sr_lr')
post_strat_dists  <- thematches %>%
    sapply(make_paired_leverage_computor,
           y=ps_se[['X']],
           simplify=FALSE, USE.NAMES=TRUE) %>%
    mapply(function(bdl, thematch){
        match_on(bdl[['FUN']],
                 within=exactMatch(thematch, ps_se[['z']]),
                 data=bdl[['Xperp']], z=ps_se[['z']])/
            sqrt(bdl[['rank']]) },
    bdl=.,
    thematch = thematches,
    SIMPLIFY=FALSE, USE.NAMES=TRUE)
post_strat_paired_levs  <-
    mapply(matched.distances,
           thematches,
           post_strat_dists,
           MoreArgs=list(preserve.unit.names=FALSE),
           SIMPLIFY=FALSE, USE.NAMES=TRUE)
pre_strat_paired_levs  <-
    sapply(thematches,
           matched.distances,
           distance=mo_lvg,
           preserve.unit.names=FALSE,
           simplify=FALSE, USE.NAMES=TRUE)
rbind(pre=sapply(pre_strat_paired_levs, function(x) mean(unlist(x)^2) ),
      post=sapply(post_strat_paired_levs, function(x) mean(unlist(x)^2) )
      ) %>% knitr::kable()
##'
##' ## What's the effect of regularization on the PISE?
##'
##' Condition numbers versus PISEs.
data.frame(row.names=names(ps_mods),
           kappa=sapply(ps_mods, function(x) kappa(x$qr)),
           PISE=sapply(ps_SEs, getElement, name="width")
           ) %>% signif(digits=3) %>% knitr::kable()




