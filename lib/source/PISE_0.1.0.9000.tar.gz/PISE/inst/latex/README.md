Notes:

- Personal macros in `pise-notation.sty`
- You can do `pdflatex pise-notation.sty` to build a cheat sheet for the personal macros
- Some of these macros rely on the delimset latex package, which isn't in the standard
   distributions that I use.  So I've checked into the repo the version that I'm using.  To set it
   up, navigate into src/ and  do `pdflatex delimset.ins`.  This should create delimset.sty,
   which you should then move into this directory.
- For citations there's a dependency on personal bibtex files -- contact BH for access.
